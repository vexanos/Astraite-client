package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Per-module keybinds, set from the Astraite GUI (right click a module > Bind). Default: none. */
public final class Binds {
    private static List<Module> modules;
    private static final Map<String, Boolean> prev = new HashMap<>();

    private Binds() {
    }

    public static int get(String module) {
        Integer k = Config.binds.get(module);
        return k == null ? -1 : k;
    }

    public static void set(String module, int key) {
        if (key < 0) Config.binds.remove(module);
        else Config.binds.put(module, key);
        Config.save();
    }

    public static String label(String module) {
        int k = get(module);
        if (k < 0) return "None";
        try {
            return InputUtil.Type.KEYSYM.createFromCode(k).getLocalizedText().getString();
        } catch (Exception e) {
            return "Key " + k;
        }
    }

    private static boolean down(MinecraftClient mc, int key) {
        return key >= 0 && InputUtil.isKeyPressed(mc.getWindow().getHandle(), key);
    }

    /** True while the module's key is held (used by Free Look "hold key only"). */
    public static boolean isDown(String module) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc != null && mc.currentScreen == null && down(mc, get(module));
    }

    public static void tick(MinecraftClient mc) {
        if (modules == null) modules = Modules.all();
        for (Module m : modules) {
            int key = get(m.name);
            boolean now = down(mc, key);
            boolean was = prev.getOrDefault(m.name, false);
            prev.put(m.name, now);
            if (!now || was || key < 0) continue;
            if (mc.player == null || mc.currentScreen != null) continue;
            if (m.name.equals("Free Look") && Config.freelookHold) continue; // hold mode: key is polled, not toggled
            m.click();
            if (m.isToggle()) {
                Config.save();
                mc.inGameHud.setOverlayMessage(Text.literal(m.name + (m.isOn() ? " ON" : " OFF")), false);
            }
        }
    }
}
