package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * Full brightness. Gamma mode (default) works like Brightness Plus / Meteor: the brightness
 * option is read as a huge value, no potion effect involved. Potion mode uses client-side night vision.
 */
public final class Fullbright {
    /** Gamma value used while Fullbright is on. */
    public static final double GAMMA = 1000.0;
    /** True while options.txt is being written, so the fake gamma never gets saved. */
    public static volatile boolean writingOptions;

    private static boolean potionApplied;

    private Fullbright() {
    }

    public static boolean gammaActive() {
        return Config.fullbright && Config.fullbrightMode == 0 && !writingOptions;
    }

    static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            potionApplied = false;
            return;
        }
        if (Config.fullbright && Config.fullbrightMode == 1) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 600) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            }
            potionApplied = true;
        } else if (potionApplied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            potionApplied = false;
        }
    }
}
