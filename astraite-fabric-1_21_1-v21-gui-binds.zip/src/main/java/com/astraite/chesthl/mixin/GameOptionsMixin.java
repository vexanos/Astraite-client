package com.astraite.chesthl.mixin;

import com.astraite.chesthl.Fullbright;
import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameOptions.class)
public abstract class GameOptionsMixin {
    @Inject(method = "write", at = @At("HEAD"))
    private void chesthl_writeStart(CallbackInfo ci) {
        Fullbright.writingOptions = true;
    }

    @Inject(method = "write", at = @At("RETURN"))
    private void chesthl_writeEnd(CallbackInfo ci) {
        Fullbright.writingOptions = false;
    }
}
