package com.astraite.chesthl;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ChestHighlightClient implements ClientModInitializer {
    public static KeyBinding openKey;
    public static boolean pendingOpen = false;


    @Override
    public void onInitializeClient() {
        Config.load();
        AccountManager.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chesthl.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.chesthl"));

        // /chesthl opens the menu (useful on mobile where keybinds are awkward)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("chesthl").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("astraite").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("basefinder").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) pendingOpen = true;
            Binds.tick(client);
            AccountManager.tick(client);
            AutoTotem.tick(client);
            AutoArmor.tick(client);
            AutoEat.tick(client);
            KillAura.tick(client);
            CrystalAura.tick(client);
            AutoAnchor.tick(client);
            Fullbright.tick(client);
            Freelook.tick(client);
            EntityEsp.tick(client);
            BlockEsp.tick(client);
            if (pendingOpen && client.player != null && client.currentScreen == null) {
                pendingOpen = false;
                client.setScreen(new ClickGui(null));
            }
        });

        WorldRenderEvents.LAST.register(EntityEsp::render);
        WorldRenderEvents.LAST.register(BlockEsp::render);

        // small status lines (why crystal/anchor is or is not doing something)
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!Config.hudStatus || mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;
            int y = 4;
            if (Config.crystalAura && !CrystalAura.status.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "CrystalAura: " + CrystalAura.status, 4, y, 0xFFFFFF);
                y += 10;
            }
            if (Config.autoAnchor && !AutoAnchor.status.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "Anchor: " + AutoAnchor.status, 4, y, 0xFFFFFF);
            }
        });

        // Button on the title screen so the menu (and account switch) is reachable outside a world
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Astraite"),
                        b -> client.setScreen(new ClickGui(screen))).dimensions(4, 4, 80, 20).build());
            }
        });
    }
}
