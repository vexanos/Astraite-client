package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/** On-screen list of every module that is currently switched on. */
final class Hud {
    private static List<Module> modules;

    private static final class Row {
        final String name;
        final String info;
        final int nameW;
        final int totalW;

        Row(String name, String info, MinecraftClient mc) {
            this.name = name;
            this.info = info;
            this.nameW = mc.textRenderer.getWidth(name);
            this.totalW = info.isEmpty() ? nameW : nameW + mc.textRenderer.getWidth(" " + info);
        }
    }

    private Hud() {
    }

    private static String info(String module) {
        return switch (module) {
            case "Crystal Aura" -> CrystalAura.status;
            case "Auto Anchor" -> AutoAnchor.status;
            case "Auto MLG" -> AutoMlg.status;
            default -> "";
        };
    }

    static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.hud || mc.player == null || mc.options.hudHidden) return;
        if (modules == null) modules = Modules.all();

        List<Row> rows = new ArrayList<>();
        for (Module m : modules) {
            if (!m.isToggle() || !m.isOn() || m.name.equals("HUD")) continue;
            String inf = Config.hudInfo ? info(m.name) : "";
            rows.add(new Row(m.name, inf == null ? "" : inf, mc));
        }
        if (rows.isEmpty()) return;

        if (Config.hudSort == 1) rows.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        else rows.sort((a, b) -> Integer.compare(b.totalW, a.totalW));

        int screenW = ctx.getScaledWindowWidth();
        int y = 4;
        int i = 0;
        for (Row r : rows) {
            float hue = (((System.currentTimeMillis() % 6000L) / 6000f) + i * 0.06f) % 1f;
            int color = 0xFF000000 | MathHelper.hsvToRgb(hue, 0.55f, 1.0f);
            int x = Config.hudCorner == 1 ? screenW - 4 - r.totalW : 4;
            ctx.drawTextWithShadow(mc.textRenderer, r.name, x, y, color);
            if (!r.info.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, " " + r.info, x + r.nameW, y, 0xFFAAAAAA);
            }
            y += 10;
            i++;
        }
    }
}
