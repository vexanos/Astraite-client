package com.astraite.chesthl;

import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Anchor aura: puts ONE respawn anchor directly above the target's head, charges it with glowstone and
 * detonates it. Everything runs from the hotbar and the slots are detected automatically
 * (anchor, glowstone, and any other slot to blast with).
 * Works in mid-air too: when there is no block to place against it air-places (like Meteor).
 * If the block above the head is blocked or out of range, it falls back to the blocks next to the target's head,
 * then next to its feet.
 * Anchors only explode outside the Nether. Do not sneak (sneaking skips the block's right-click).
 */
public final class AutoAnchor {
    public static String status = "";
    private static int cd = 0;
    private static int prevSlot = -1;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.autoAnchor) {
            status = "";
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) {
            status = "Paused (eating)";
            return;
        }
        if (w.getDimension().respawnAnchorWorks()) {
            status = "Anchors do not explode in the Nether";
            return;
        }
        if (p.isSneaking()) {
            status = "Stop sneaking";
            return;
        }
        if (cd > 0) {
            cd--;
            return;
        }

        LivingEntity target = PlaceUtil.target(w, p, Config.anchorTargetRange, Config.anchorMobs);
        if (target == null) {
            status = "No target within " + Config.anchorTargetRange + " blocks";
            return;
        }
        status = "Target: " + target.getName().getString();

        Vec3d eye = p.getEyePos();
        double r = Config.anchorRange;
        List<BlockPos> spots = spots(target);

        // an anchor that already sits on one of the spots?
        BlockPos anchor = null;
        for (BlockPos s : spots) {
            if (!w.getBlockState(s).isOf(Blocks.RESPAWN_ANCHOR)) continue;
            Vec3d c = Vec3d.ofCenter(s);
            if (eye.squaredDistanceTo(c) > r * r) continue;
            anchor = s;
            break;
        }

        boolean acted = false;
        int wait = Config.anchorDelay;
        if (anchor != null) {
            int charges = w.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
            if (charges == 0) {
                acted = charge(mc, p, anchor);
                wait = Math.max(wait, 3); // give the server time to update the charge
            } else {
                acted = explode(mc, p, anchor);
            }
        } else if (Config.anchorPlace) {
            acted = placeAnchor(mc, w, p, target, eye, r, spots);
        } else {
            status = "No anchor near target";
        }
        if (acted) cd = wait;

        if (Config.anchorSwitchBack && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
        }
        prevSlot = -1;
    }

    /** Candidate anchor positions, best first: above the head, beside the head, above beside, beside the feet. */
    private static List<BlockPos> spots(LivingEntity t) {
        BlockPos feet = t.getBlockPos();
        Direction[] sides = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        List<BlockPos> l = new ArrayList<>();
        l.add(feet.up(2));
        int[] levels = {1, 2, 0};
        for (int dy : levels) {
            for (Direction d : sides) l.add(feet.up(dy).offset(d));
        }
        return l;
    }

    private static boolean placeAnchor(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target,
                                       Vec3d eye, double r, List<BlockPos> spots) {
        int slot = findSlot(p, Items.RESPAWN_ANCHOR);
        if (slot < 0) {
            status = "No respawn anchor in hotbar";
            return false;
        }
        for (BlockPos s : spots) {
            if (!w.getBlockState(s).isAir()) continue;
            Vec3d c = Vec3d.ofCenter(s);
            if (eye.squaredDistanceTo(c) > r * r) continue;
            if (!w.getOtherEntities(null, new Box(s)).isEmpty()) continue;
            // normal placement against a neighbour if there is one, otherwise air-place (click the empty spot itself)
            BlockHitResult hit = PlaceUtil.hitFor(w, s);
            if (hit == null) hit = new BlockHitResult(Vec3d.ofCenter(s), Direction.UP, s, false);
            select(p, slot);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
            p.swingHand(Hand.MAIN_HAND);
            status = "Placed anchor";
            return true;
        }
        status = "No spot for an anchor (out of Range, or something is in the way)";
        return false;
    }

    private static boolean charge(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        int slot = findSlot(p, Items.GLOWSTONE);
        if (slot < 0) {
            status = "No glowstone in hotbar";
            return false;
        }
        select(p, slot);
        click(mc, p, anchor);
        status = "Charging anchor";
        return true;
    }

    private static boolean explode(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        if (p.getOffHandStack().isOf(Items.GLOWSTONE)) {
            status = "Remove glowstone from offhand";
            return false;
        }
        // must NOT hold glowstone, otherwise it just charges again
        int slot = blastSlot(p);
        if (slot < 0) {
            status = "No safe slot to blast with";
            return false;
        }
        select(p, slot);
        click(mc, p, anchor);
        status = "Blasting anchor";
        return true;
    }

    private static void click(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(anchor.getX() + 0.5, anchor.getY() + 1.0, anchor.getZ() + 0.5), Direction.UP, anchor, false);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
    }

    /** First hotbar slot (0-8) that holds the item, or -1. The slot you already hold wins if it matches. */
    private static int findSlot(ClientPlayerEntity p, net.minecraft.item.Item item) {
        int cur = p.getInventory().selectedSlot;
        if (p.getInventory().getStack(cur).isOf(item)) return cur;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /**
     * Slot to detonate with: anything that is not glowstone. Prefers the slot you hold, then a slot that is not an
     * anchor (so a failed click can never place another anchor), then any non-glowstone slot.
     */
    private static int blastSlot(ClientPlayerEntity p) {
        int cur = p.getInventory().selectedSlot;
        if (okBlast(p, cur, false)) return cur;
        for (int i = 0; i < 9; i++) {
            if (okBlast(p, i, false)) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (okBlast(p, i, true)) return i;
        }
        return -1;
    }

    private static boolean okBlast(ClientPlayerEntity p, int slot, boolean allowAnchor) {
        var st = p.getInventory().getStack(slot);
        if (st.isOf(Items.GLOWSTONE)) return false;
        return allowAnchor || !st.isOf(Items.RESPAWN_ANCHOR);
    }

    private static void select(ClientPlayerEntity p, int slot) {
        if (p.getInventory().selectedSlot != slot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
        }
    }
}
