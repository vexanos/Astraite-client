package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Meteor-style entity ESP: Box / Glow modes, per-group colors, distance colors, fade. */
public final class EntityEsp {
    public static final String[] COLOR_NAMES = {"White", "Gray", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink"};
    public static final int[] COLORS = {0xFFFFFF, 0xAAAAAA, 0xFF3B30, 0xFF9F0A, 0xFFE600, 0x34D959, 0x00E5FF, 0x3B82F6, 0xB44CFF, 0xFF69B4};
    private static final int TARGET_COLOR = 0xFF2D55;

    private static volatile Map<Integer, Integer> glow = Map.of();

    private EntityEsp() {
    }

    // ---------------- selection / colors ----------------
    private static volatile Set<EntityType<?>> types = Set.of();

    private static void refreshTypes() {
        Set<EntityType<?>> s = new HashSet<>();
        for (String id : Config.espEntityTypes) {
            Identifier ident = Identifier.tryParse(id);
            if (ident != null) Registries.ENTITY_TYPE.getOrEmpty(ident).ifPresent(s::add);
        }
        types = s;
    }

    private static boolean selected(MinecraftClient mc, Entity e) {
        if (Config.espIgnoreSelf && e == mc.player) return false;
        return types.contains(e.getType());
    }

    private static int groupColor(Entity e) {
        int idx;
        if (e instanceof PlayerEntity) idx = Config.espColPlayers;
        else {
            switch (e.getType().getSpawnGroup()) {
                case CREATURE -> idx = Config.espColAnimals;
                case WATER_CREATURE, WATER_AMBIENT, UNDERGROUND_WATER_CREATURE, AXOLOTLS -> idx = Config.espColWater;
                case MONSTER -> idx = Config.espColMonsters;
                case AMBIENT -> idx = Config.espColAmbient;
                default -> idx = Config.espColMisc;
            }
        }
        return COLORS[MathHelper.clamp(idx, 0, COLORS.length - 1)];
    }

    private static int color(MinecraftClient mc, Entity e, double dist) {
        if (Config.espTarget && mc.crosshairTarget instanceof EntityHitResult h && h.getEntity() == e) return TARGET_COLOR;
        if (Config.espDistColors) {
            double pct = MathHelper.clamp(dist / 60.0, 0.0, 1.0);
            return ((int) (255 * pct) << 16) | ((int) (255 * (1 - pct)) << 8);
        }
        return groupColor(e);
    }

    private static int fadeAlpha(double dist) {
        if (Config.espFade <= 0) return 255;
        return (int) (255 * MathHelper.clamp(dist / Config.espFade, 0.0, 1.0));
    }

    // ---------------- glow mode (read by EntityMixin) ----------------
    public static int glowColor(Entity e) {
        Map<Integer, Integer> m = glow;
        if (m.isEmpty()) return -1;
        Integer c = m.get(e.getId());
        return c == null ? -1 : c;
    }

    public static void tick(MinecraftClient mc) {
        if (Config.espEnabled) refreshTypes();
        if (!Config.espEnabled || Config.espMode != 1 || mc.world == null || mc.player == null) {
            if (!glow.isEmpty()) glow = Map.of();
            return;
        }
        Map<Integer, Integer> m = new HashMap<>();
        Vec3d eye = mc.player.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (!selected(mc, e)) continue;
            m.put(e.getId(), color(mc, e, eye.distanceTo(e.getPos())));
        }
        glow = m;
    }

    // ---------------- box ----------------
    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.espEnabled || Config.espMode == 1 || mc.world == null || mc.player == null) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        float delta = mc.getRenderTickCounter().getTickDelta(false);
        Matrix4f mv = stack.peek().getPositionMatrix();

        List<Box> boxes = new ArrayList<>();
        List<int[]> cols = new ArrayList<>(); // {rgb, alpha}

        for (Entity e : mc.world.getEntities()) {
            if (!selected(mc, e)) continue;
            Vec3d lp = e.getLerpedPos(delta);
            Box b = e.getBoundingBox().offset(lp.x - e.getX(), lp.y - e.getY(), lp.z - e.getZ())
                    .offset(-cam.x, -cam.y, -cam.z);
            double dist = cam.distanceTo(b.getCenter().add(cam));
            int rgb = color(mc, e, dist) & 0xFFFFFF;
            int alpha = fadeAlpha(dist);
            if (alpha <= 0) continue;

            boxes.add(b);
            cols.add(new int[]{rgb, alpha});
        }
        if (boxes.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // Meteor ESP is always visible through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.espShape != 0 && Config.espFill > 0) {
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) {
                int a = (int) (cols.get(i)[1] * Config.espFill / 100.0);
                fill(bb, mv, boxes.get(i), (a << 24) | cols.get(i)[0]);
            }
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.espShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) {
                lines(lb, mv, boxes.get(i), (cols.get(i)[1] << 24) | cols.get(i)[0]);
            }
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ---------------- box drawing ----------------
    private static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int c) {
        b.vertex(m, (float) x, (float) y, (float) z).color(c);
    }

    static void fill(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        v(b, m, x0, y0, z0, c); v(b, m, x1, y0, z0, c); v(b, m, x1, y0, z1, c); v(b, m, x0, y0, z1, c);
        v(b, m, x0, y1, z0, c); v(b, m, x0, y1, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z0, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y1, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y0, z0, c);
        v(b, m, x0, y0, z1, c); v(b, m, x1, y0, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x0, y1, z1, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y0, z1, c); v(b, m, x0, y1, z1, c); v(b, m, x0, y1, z0, c);
        v(b, m, x1, y0, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y0, z1, c);
    }

    private static void edge(BufferBuilder b, Matrix4f m, double ax, double ay, double az,
                             double bx, double by, double bz, int c) {
        v(b, m, ax, ay, az, c);
        v(b, m, bx, by, bz, c);
    }

    static void lines(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        edge(b, m, x0, y0, z0, x1, y0, z0, c);
        edge(b, m, x1, y0, z0, x1, y0, z1, c);
        edge(b, m, x1, y0, z1, x0, y0, z1, c);
        edge(b, m, x0, y0, z1, x0, y0, z0, c);
        edge(b, m, x0, y1, z0, x1, y1, z0, c);
        edge(b, m, x1, y1, z0, x1, y1, z1, c);
        edge(b, m, x1, y1, z1, x0, y1, z1, c);
        edge(b, m, x0, y1, z1, x0, y1, z0, c);
        edge(b, m, x0, y0, z0, x0, y1, z0, c);
        edge(b, m, x1, y0, z0, x1, y1, z0, c);
        edge(b, m, x1, y0, z1, x1, y1, z1, c);
        edge(b, m, x0, y0, z1, x0, y1, z1, c);
    }
}
