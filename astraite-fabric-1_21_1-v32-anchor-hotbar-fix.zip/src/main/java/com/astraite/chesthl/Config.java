package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class Config {

    // combat
    public static boolean autoTotem = false;
    public static int totemDelay = 1;
    public static boolean killAura = false;
    // Block ESP
    public static boolean blockEspEnabled = false;
    public static int blockEspShape = 2;
    public static int blockEspFill = 30;
    public static int blockEspRange = 64;
    public static boolean blockEspByBlock = true;
    public static int blockEspColor = 6;
    public static final Set<String> blockEspBlocks = new LinkedHashSet<>(List.of(
            "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore", "minecraft:ancient_debris"));

    public static boolean espEnabled = false;
    public static int espMode = 0; // 0 = Box, 1 = Glow
    public static int espShape = 2;
    public static int espFill = 30;
    public static boolean espIgnoreSelf = true;
    public static int espFade = 3;
    public static boolean espTarget = false;
    public static boolean espDistColors = false;
    public static int espColPlayers = 0;
    public static int espColAnimals = 5;
    public static int espColWater = 7;
    public static int espColMonsters = 2;
    public static int espColAmbient = 1;
    public static int espColMisc = 1;
    public static final Set<String> espEntityTypes = new LinkedHashSet<>(List.of("minecraft:player"));
    public static final Set<String> auraEntityTypes = new LinkedHashSet<>();
    public static boolean auraEntitiesInit = false;
    public static int auraRange10 = 40;
    public static int auraWalls10 = 35;
    public static boolean auraIgnorePassive = true;
    public static boolean auraPauseBaritone = true;
    public static boolean auraPauseLag = true;
    public static boolean auraTpsSync = true;
    public static int auraWeapon = 0;
    public static int auraRotateMode = 0;
    public static boolean auraAutoSwitch = false;
    public static boolean auraOnlyClick = false;
    public static boolean auraOnlyLook = false;
    public static int auraPriority = 0;
    public static int auraMaxTargets = 1;
    public static int auraAge = 0;
    public static boolean auraIgnoreNamed = false;
    public static boolean auraIgnoreTamed = false;
    public static boolean auraPauseUse = false;
    public static boolean auraPauseCA = true;
    public static boolean auraCustomDelay = false;
    public static int auraHitDelay = 10;
    public static int auraSwitchDelay = 0;
    public static int auraShield = 0;

    // auto crystal
    public static boolean crystalAura = false;
    public static int crystalSlot = 1;          // hotbar slot 1-9
    public static boolean crystalPlace = true;
    public static boolean crystalBreak = true;
    public static int crystalPlaceRange = 4;
    public static int crystalBreakRange = 4;
    public static int crystalMinDmg = 2;
    public static int crystalMaxSelf = 20;
    public static int crystalTargetRange = 8;
    public static int crystalPlaceDelay = 2;
    public static int crystalBreakDelay = 1;
    public static boolean crystalSwitchBack = true;
    public static boolean crystalObsidian = true;   // place obsidian when there is no base block
    public static int obsidianSlot = 2;             // hotbar slot 1-9
    public static boolean crystalMobs = false;      // also target hostile mobs
    public static boolean crystalIdle = true;       // no target: put crystals on every free obsidian

    // auto anchor
    public static boolean autoAnchor = false;
    public static int anchorSlot = 3;               // respawn anchors, hotbar slot 1-9
    public static int glowSlot = 4;                 // glowstone, hotbar slot 1-9
    public static boolean anchorPlace = true;
    public static int anchorRange = 4;
    public static int anchorMinDmg = 4;
    public static int anchorMaxSelf = 10;
    public static int anchorTargetRange = 8;
    public static int anchorDelay = 2;
    public static boolean anchorSwitchBack = true;
    public static boolean anchorMobs = false;
    public static boolean anchorRotate = true;      // send a silent look packet at the anchor before every click
    public static boolean anchorFloor = false;      // place the anchor on the floor next to the enemy instead of above its head

    // auto anchor extras
    public static int anchorBlastSlot = 5;          // hotbar slot used to detonate (must not be glowstone)

    // HUD (active module list)
    public static boolean hud = true;
    public static int hudCorner = 1;                // 0 top left, 1 top right, 2 bottom left, 3 bottom right
    public static int hudScale10 = 10;              // text scale in tenths (10 = 1.0x)
    public static int hudOffX = 4;                  // distance from the screen edge
    public static int hudOffY = 4;
    public static int hudSpacing = 0;               // extra pixels between rows
    public static int hudColor = 0;                 // 0 rainbow, 1 by category, 2+ fixed colours
    public static int hudRainbowSpeed = 3;
    public static int hudBg = 0;                    // background opacity 0-100 (0 = off)
    public static boolean hudBar = false;           // coloured bar on the screen-edge side
    public static boolean hudShadow = true;
    public static int hudSort = 0;                  // 0 = by length, 1 = A-Z
    public static boolean hudInfo = true;           // show status text next to a module

    // auto MLG
    public static boolean mlg = false;
    public static int mlgRange10 = 40;              // reach in tenths of a block
    public static boolean mlgPickup = true;         // pick the water back up after landing
    public static boolean mlgSwitchBack = true;

    // render extras
    public static final java.util.Map<String, Integer> binds = new java.util.HashMap<>(); // module name -> GLFW key
    public static boolean fullbright = false;
    public static int fullbrightMode = 0;    // 0 = gamma (like Brightness Plus), 1 = night vision potion
    public static boolean freelook = false;
    public static boolean freelookHold = false; // true: only active while the Free Look key is held
    public static boolean freecam = false;   // never saved: always starts off
    public static int freecamSpeed = 12;     // blocks per second

    // auto eat / armor
    public static boolean autoEat = false;
    public static int eatMode = 2;              // 0 hunger, 1 health, 2 any
    public static int eatHunger = 16;
    public static int eatHealth = 10;
    public static boolean pauseAuras = true;
    public static boolean autoArmor = false;
    public static int armorDelay = 2;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl.json");

    private static class Data {
        boolean autoTotem = false;
        int totemDelay = 1;
        boolean killAura = false;
        boolean blockEspEnabled = false;
        int blockEspShape = 2;
        int blockEspFill = 30;
        int blockEspRange = 64;
        boolean blockEspByBlock = true;
        int blockEspColor = 6;
        List<String> blockEspBlocks = null;
        boolean espEnabled = false;
        int espMode = 0;
        int espShape = 2;
        int espFill = 30;
        boolean espIgnoreSelf = true;
        int espFade = 3;
        boolean espTarget = false;
        boolean espDistColors = false;
        int espColPlayers = 0;
        int espColAnimals = 5;
        int espColWater = 7;
        int espColMonsters = 2;
        int espColAmbient = 1;
        int espColMisc = 1;
        List<String> espEntityTypes = null;
        List<String> auraEntityTypes = new ArrayList<>();
        boolean auraEntitiesInit = false;
        int auraRange10 = 40;
        int auraWalls10 = 35;
        boolean auraIgnorePassive = true;
        boolean auraPauseBaritone = true;
        boolean auraPauseLag = true;
        boolean auraTpsSync = true;
        int auraWeapon = 0;
        int auraRotateMode = 0;
        boolean auraAutoSwitch = false;
        boolean auraOnlyClick = false;
        boolean auraOnlyLook = false;
        int auraPriority = 0;
        int auraMaxTargets = 1;
        int auraAge = 0;
        boolean auraIgnoreNamed = false;
        boolean auraIgnoreTamed = false;
        boolean auraPauseUse = false;
        boolean auraPauseCA = true;
        boolean auraCustomDelay = false;
        int auraHitDelay = 10;
        int auraSwitchDelay = 0;
        int auraShield = 0;
        boolean crystalAura = false;
        int crystalSlot = 1;
        boolean crystalPlace = true;
        boolean crystalBreak = true;
        int crystalPlaceRange = 4;
        int crystalBreakRange = 4;
        int crystalMinDmg = 2;
        int crystalMaxSelf = 20;
        int crystalTargetRange = 8;
        int crystalPlaceDelay = 2;
        int crystalBreakDelay = 1;
        boolean crystalSwitchBack = true;
        boolean crystalObsidian = true;
        int obsidianSlot = 2;
        boolean crystalMobs = false;
        boolean crystalIdle = true;
        boolean autoAnchor = false;
        int anchorSlot = 3;
        int glowSlot = 4;
        boolean anchorPlace = true;
        int anchorRange = 4;
        int anchorMinDmg = 4;
        int anchorMaxSelf = 10;
        int anchorTargetRange = 8;
        int anchorDelay = 2;
        boolean anchorSwitchBack = true;
        boolean anchorMobs = false;
        boolean anchorFloor = false;
        boolean anchorRotate = true;
        int anchorBlastSlot = 5;
        boolean hud = true;
        int hudCorner = 1;
        int hudScale10 = 10;
        int hudOffX = 4;
        int hudOffY = 4;
        int hudSpacing = 0;
        int hudColor = 0;
        int hudRainbowSpeed = 3;
        int hudBg = 0;
        boolean hudBar = false;
        boolean hudShadow = true;
        int hudSort = 0;
        boolean hudInfo = true;
        boolean mlg = false;
        int mlgRange10 = 40;
        boolean mlgPickup = true;
        boolean mlgSwitchBack = true;
        boolean fullbright = false;
        java.util.Map<String, Integer> binds = new java.util.HashMap<>();
        int fullbrightMode = 0;
        int freecamSpeed = 12;
        int ver = 0;
        boolean autoEat = false;
        int eatMode = 2;
        int eatHunger = 16;
        int eatHealth = 10;
        boolean pauseAuras = true;
        boolean autoArmor = false;
        int armorDelay = 2;
    }

    private static int c(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            autoTotem = d.autoTotem;
            totemDelay = c(d.totemDelay, 0, 10);
            killAura = d.killAura;
            espEnabled = d.espEnabled;
            blockEspEnabled = d.blockEspEnabled;
            blockEspShape = c(d.blockEspShape, 0, 2);
            blockEspFill = c(d.blockEspFill, 0, 100);
            blockEspRange = c(d.blockEspRange, 16, 128);
            blockEspByBlock = d.blockEspByBlock;
            blockEspColor = c(d.blockEspColor, 0, 9);
            if (d.blockEspBlocks != null) {
                blockEspBlocks.clear();
                blockEspBlocks.addAll(d.blockEspBlocks);
            }
            // v4 removed the 2D mode: Box stays 0, Glow moved from 2 to 1
            espMode = d.ver < 4 ? (d.espMode == 2 ? 1 : 0) : c(d.espMode, 0, 1);
            espShape = c(d.espShape, 0, 2);
            espFill = c(d.espFill, 0, 100);
            espIgnoreSelf = d.espIgnoreSelf;
            espFade = c(d.espFade, 0, 10);
            espTarget = d.espTarget;
            espDistColors = d.espDistColors;
            espColPlayers = c(d.espColPlayers, 0, 9);
            espColAnimals = c(d.espColAnimals, 0, 9);
            espColWater = c(d.espColWater, 0, 9);
            espColMonsters = c(d.espColMonsters, 0, 9);
            espColAmbient = c(d.espColAmbient, 0, 9);
            espColMisc = c(d.espColMisc, 0, 9);
            if (d.espEntityTypes != null) {
                espEntityTypes.clear();
                espEntityTypes.addAll(d.espEntityTypes);
            }
            auraEntityTypes.clear();
            if (d.auraEntityTypes != null) auraEntityTypes.addAll(d.auraEntityTypes);
            auraEntitiesInit = d.auraEntitiesInit;
            auraRange10 = c(d.auraRange10, 10, 60);
            auraWalls10 = c(d.auraWalls10, 0, 60);
            auraIgnorePassive = d.auraIgnorePassive;
            auraPauseBaritone = d.auraPauseBaritone;
            auraPauseLag = d.auraPauseLag;
            auraTpsSync = d.auraTpsSync;
            auraWeapon = c(d.auraWeapon, 0, 5);
            auraRotateMode = c(d.auraRotateMode, 0, 2);
            auraAutoSwitch = d.auraAutoSwitch;
            auraOnlyClick = d.auraOnlyClick;
            auraOnlyLook = d.auraOnlyLook;
            auraPriority = c(d.auraPriority, 0, 4);
            auraMaxTargets = c(d.auraMaxTargets, 1, 5);
            auraAge = c(d.auraAge, 0, 2);
            auraIgnoreNamed = d.auraIgnoreNamed;
            auraIgnoreTamed = d.auraIgnoreTamed;
            auraPauseUse = d.auraPauseUse;
            auraPauseCA = d.auraPauseCA;
            auraCustomDelay = d.auraCustomDelay;
            auraHitDelay = c(d.auraHitDelay, 0, 60);
            auraSwitchDelay = c(d.auraSwitchDelay, 0, 10);
            auraShield = c(d.auraShield, 0, 2);
            crystalAura = d.crystalAura;
            crystalSlot = c(d.crystalSlot, 1, 9);
            crystalPlace = d.crystalPlace;
            crystalBreak = d.crystalBreak;
            crystalPlaceRange = c(d.crystalPlaceRange, 2, 6);
            crystalBreakRange = c(d.crystalBreakRange, 2, 6);
            // older configs had too strict damage limits -> reset them once
            crystalMinDmg = d.ver < 3 ? 2 : c(d.crystalMinDmg, 0, 36);
            crystalMaxSelf = d.ver < 3 ? 20 : c(d.crystalMaxSelf, 1, 36);
            crystalTargetRange = c(d.crystalTargetRange, 4, 12);
            crystalPlaceDelay = c(d.crystalPlaceDelay, 0, 10);
            crystalBreakDelay = c(d.crystalBreakDelay, 0, 10);
            crystalSwitchBack = d.crystalSwitchBack;
            crystalObsidian = d.crystalObsidian;
            obsidianSlot = c(d.obsidianSlot, 1, 9);
            crystalMobs = d.crystalMobs;
            crystalIdle = d.ver < 3 || d.crystalIdle;
            autoAnchor = d.autoAnchor;
            anchorSlot = c(d.anchorSlot, 1, 9);
            glowSlot = c(d.glowSlot, 1, 9);
            anchorPlace = d.anchorPlace;
            anchorRange = c(d.anchorRange, 2, 6);
            anchorMinDmg = c(d.anchorMinDmg, 1, 36);
            anchorMaxSelf = c(d.anchorMaxSelf, 1, 36);
            anchorTargetRange = c(d.anchorTargetRange, 4, 12);
            anchorDelay = c(d.anchorDelay, 0, 10);
            anchorSwitchBack = d.anchorSwitchBack;
            anchorMobs = d.anchorMobs;
            anchorFloor = d.anchorFloor;
            anchorRotate = d.ver < 7 || d.anchorRotate;
            anchorBlastSlot = d.ver < 5 ? 5 : c(d.anchorBlastSlot, 1, 9);
            hud = d.ver < 5 || d.hud;
            hudCorner = d.ver < 5 ? 1 : c(d.hudCorner, 0, 3);
            hudScale10 = d.ver < 6 ? 10 : c(d.hudScale10, 5, 30);
            hudOffX = d.ver < 6 ? 4 : c(d.hudOffX, 0, 300);
            hudOffY = d.ver < 6 ? 4 : c(d.hudOffY, 0, 300);
            hudSpacing = c(d.hudSpacing, 0, 10);
            hudColor = c(d.hudColor, 0, 9);
            hudRainbowSpeed = d.ver < 6 ? 3 : c(d.hudRainbowSpeed, 1, 10);
            hudBg = c(d.hudBg, 0, 100);
            hudBar = d.hudBar;
            hudShadow = d.ver < 6 || d.hudShadow;
            hudSort = c(d.hudSort, 0, 1);
            hudInfo = d.ver < 5 || d.hudInfo;
            mlg = d.mlg;
            mlgRange10 = d.mlgRange10 == 0 ? 40 : c(d.mlgRange10, 20, 45);
            mlgPickup = d.ver < 5 || d.mlgPickup;
            mlgSwitchBack = d.ver < 5 || d.mlgSwitchBack;
            fullbright = d.fullbright;
            binds.clear();
            if (d.binds != null) binds.putAll(d.binds);
            fullbrightMode = c(d.fullbrightMode, 0, 1);
            freecamSpeed = c(d.freecamSpeed == 0 ? 12 : d.freecamSpeed, 2, 60);
            autoEat = d.autoEat;
            eatMode = c(d.eatMode, 0, 2);
            eatHunger = c(d.eatHunger, 1, 19);
            eatHealth = c(d.eatHealth, 1, 19);
            pauseAuras = d.pauseAuras;
            autoArmor = d.autoArmor;
            armorDelay = c(d.armorDelay, 0, 10);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.autoTotem = autoTotem;
            d.totemDelay = totemDelay;
            d.killAura = killAura;
            d.espEnabled = espEnabled;
            d.blockEspEnabled = blockEspEnabled;
            d.blockEspShape = blockEspShape;
            d.blockEspFill = blockEspFill;
            d.blockEspRange = blockEspRange;
            d.blockEspByBlock = blockEspByBlock;
            d.blockEspColor = blockEspColor;
            d.blockEspBlocks = new ArrayList<>(blockEspBlocks);
            d.espMode = espMode;
            d.espShape = espShape;
            d.espFill = espFill;
            d.espIgnoreSelf = espIgnoreSelf;
            d.espFade = espFade;
            d.espTarget = espTarget;
            d.espDistColors = espDistColors;
            d.espColPlayers = espColPlayers;
            d.espColAnimals = espColAnimals;
            d.espColWater = espColWater;
            d.espColMonsters = espColMonsters;
            d.espColAmbient = espColAmbient;
            d.espColMisc = espColMisc;
            d.espEntityTypes = new ArrayList<>(espEntityTypes);
            d.auraEntityTypes = new ArrayList<>(auraEntityTypes);
            d.auraEntitiesInit = auraEntitiesInit;
            d.auraRange10 = auraRange10;
            d.auraWalls10 = auraWalls10;
            d.auraIgnorePassive = auraIgnorePassive;
            d.auraPauseBaritone = auraPauseBaritone;
            d.auraPauseLag = auraPauseLag;
            d.auraTpsSync = auraTpsSync;
            d.auraWeapon = auraWeapon;
            d.auraRotateMode = auraRotateMode;
            d.auraAutoSwitch = auraAutoSwitch;
            d.auraOnlyClick = auraOnlyClick;
            d.auraOnlyLook = auraOnlyLook;
            d.auraPriority = auraPriority;
            d.auraMaxTargets = auraMaxTargets;
            d.auraAge = auraAge;
            d.auraIgnoreNamed = auraIgnoreNamed;
            d.auraIgnoreTamed = auraIgnoreTamed;
            d.auraPauseUse = auraPauseUse;
            d.auraPauseCA = auraPauseCA;
            d.auraCustomDelay = auraCustomDelay;
            d.auraHitDelay = auraHitDelay;
            d.auraSwitchDelay = auraSwitchDelay;
            d.auraShield = auraShield;
            d.crystalAura = crystalAura;
            d.crystalSlot = crystalSlot;
            d.crystalPlace = crystalPlace;
            d.crystalBreak = crystalBreak;
            d.crystalPlaceRange = crystalPlaceRange;
            d.crystalBreakRange = crystalBreakRange;
            d.crystalMinDmg = crystalMinDmg;
            d.crystalMaxSelf = crystalMaxSelf;
            d.crystalTargetRange = crystalTargetRange;
            d.crystalPlaceDelay = crystalPlaceDelay;
            d.crystalBreakDelay = crystalBreakDelay;
            d.crystalSwitchBack = crystalSwitchBack;
            d.crystalObsidian = crystalObsidian;
            d.obsidianSlot = obsidianSlot;
            d.crystalMobs = crystalMobs;
            d.crystalIdle = crystalIdle;
            d.autoAnchor = autoAnchor;
            d.anchorSlot = anchorSlot;
            d.glowSlot = glowSlot;
            d.anchorPlace = anchorPlace;
            d.anchorRange = anchorRange;
            d.anchorMinDmg = anchorMinDmg;
            d.anchorMaxSelf = anchorMaxSelf;
            d.anchorTargetRange = anchorTargetRange;
            d.anchorDelay = anchorDelay;
            d.anchorSwitchBack = anchorSwitchBack;
            d.anchorMobs = anchorMobs;
            d.anchorFloor = anchorFloor;
            d.anchorRotate = anchorRotate;
            d.anchorBlastSlot = anchorBlastSlot;
            d.hud = hud;
            d.hudCorner = hudCorner;
            d.hudScale10 = hudScale10;
            d.hudOffX = hudOffX;
            d.hudOffY = hudOffY;
            d.hudSpacing = hudSpacing;
            d.hudColor = hudColor;
            d.hudRainbowSpeed = hudRainbowSpeed;
            d.hudBg = hudBg;
            d.hudBar = hudBar;
            d.hudShadow = hudShadow;
            d.hudSort = hudSort;
            d.hudInfo = hudInfo;
            d.mlg = mlg;
            d.mlgRange10 = mlgRange10;
            d.mlgPickup = mlgPickup;
            d.mlgSwitchBack = mlgSwitchBack;
            d.fullbright = fullbright;
            d.binds = new java.util.HashMap<>(binds);
            d.fullbrightMode = fullbrightMode;
            d.freecamSpeed = freecamSpeed;
            d.ver = 7;
            d.autoEat = autoEat;
            d.eatMode = eatMode;
            d.eatHunger = eatHunger;
            d.eatHealth = eatHealth;
            d.pauseAuras = pauseAuras;
            d.autoArmor = autoArmor;
            d.armorDelay = armorDelay;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }
}
