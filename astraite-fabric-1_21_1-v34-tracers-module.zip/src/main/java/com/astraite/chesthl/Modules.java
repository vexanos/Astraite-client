package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/** Registry of every module shown in the click GUI, bound to the Config fields. */
final class Modules {
    private Modules() {
    }

    static List<Module> all() {
        List<Module> l = new ArrayList<>();
        Module.Category combat = Module.Category.COMBAT;
        Module.Category player = Module.Category.PLAYER;
        Module.Category render = Module.Category.RENDER;
        Module.Category misc = Module.Category.MISC;

        // ---------------- Combat ----------------
        l.add(Module.toggle("Kill Aura", combat, () -> Config.killAura, v -> Config.killAura = v, null)
                // General
                .choice("Weapon", new String[]{"Any", "Sword", "Axe", "Mace", "Trident", "All"}, () -> Config.auraWeapon, v -> Config.auraWeapon = v)
                .choice("Rotate", new String[]{"Always", "On Hit", "None"}, () -> Config.auraRotateMode, v -> Config.auraRotateMode = v)
                .bool("Auto Switch", () -> Config.auraAutoSwitch, v -> Config.auraAutoSwitch = v, null)
                .bool("Only On Click", () -> Config.auraOnlyClick, v -> Config.auraOnlyClick = v, null)
                .bool("Only On Look", () -> Config.auraOnlyLook, v -> Config.auraOnlyLook = v, null)
                .bool("Pause Baritone", () -> Config.auraPauseBaritone, v -> Config.auraPauseBaritone = v, null)
                .choice("Shield Mode", new String[]{"Ignore", "Break", "None"}, () -> Config.auraShield, v -> Config.auraShield = v)
                // Targeting
                .button("Entities", () -> "Select (" + Config.auraEntityTypes.size() + ")",
                        () -> MinecraftClient.getInstance().setScreen(new EntityListScreen(MinecraftClient.getInstance().currentScreen, Config.auraEntityTypes)))
                .choice("Priority", new String[]{"ClosestAngle", "LowestDistance", "HighestDistance", "LowestHealth", "HighestHealth"}, () -> Config.auraPriority, v -> Config.auraPriority = v)
                .num("Max Targets", 1, 5, () -> Config.auraMaxTargets, v -> Config.auraMaxTargets = v, null)
                .dec("Range", 10, 60, () -> Config.auraRange10, v -> Config.auraRange10 = v, null)
                .dec("Walls Range", 0, 60, () -> Config.auraWalls10, v -> Config.auraWalls10 = v, null)
                .choice("Mob Age Filter", new String[]{"Both", "Baby", "Adult"}, () -> Config.auraAge, v -> Config.auraAge = v)
                .bool("Ignore Named", () -> Config.auraIgnoreNamed, v -> Config.auraIgnoreNamed = v, null)
                .bool("Ignore Passive", () -> Config.auraIgnorePassive, v -> Config.auraIgnorePassive = v, null)
                .bool("Ignore Tamed", () -> Config.auraIgnoreTamed, v -> Config.auraIgnoreTamed = v, null)
                // Timing
                .bool("Pause On Lag", () -> Config.auraPauseLag, v -> Config.auraPauseLag = v, null)
                .bool("Pause On Use", () -> Config.auraPauseUse, v -> Config.auraPauseUse = v, null)
                .bool("Pause On CA", () -> Config.auraPauseCA, v -> Config.auraPauseCA = v, null)
                .bool("TPS Sync", () -> Config.auraTpsSync, v -> Config.auraTpsSync = v, null)
                .bool("Custom Delay", () -> Config.auraCustomDelay, v -> Config.auraCustomDelay = v, null)
                .num("Hit Delay", 0, 60, () -> Config.auraHitDelay, v -> Config.auraHitDelay = v, null)
                .num("Switch Delay", 0, 10, () -> Config.auraSwitchDelay, v -> Config.auraSwitchDelay = v, null));

        l.add(Module.toggle("Crystal Aura", combat, () -> Config.crystalAura, v -> Config.crystalAura = v, null)
                .bool("Place", () -> Config.crystalPlace, v -> Config.crystalPlace = v, null)
                .bool("Break", () -> Config.crystalBreak, v -> Config.crystalBreak = v, null)
                .bool("Idle place", () -> Config.crystalIdle, v -> Config.crystalIdle = v, null)
                .bool("Auto obsidian", () -> Config.crystalObsidian, v -> Config.crystalObsidian = v, null)
                .bool("Target mobs", () -> Config.crystalMobs, v -> Config.crystalMobs = v, null)
                .num("Crystal slot", 1, 9, () -> Config.crystalSlot, v -> Config.crystalSlot = v, null)
                .num("Obsidian slot", 1, 9, () -> Config.obsidianSlot, v -> Config.obsidianSlot = v, null)
                .num("Place range", 2, 6, () -> Config.crystalPlaceRange, v -> Config.crystalPlaceRange = v, null)
                .num("Break range", 2, 6, () -> Config.crystalBreakRange, v -> Config.crystalBreakRange = v, null)
                .num("Min dmg", 0, 36, () -> Config.crystalMinDmg, v -> Config.crystalMinDmg = v, null)
                .num("Max self", 1, 36, () -> Config.crystalMaxSelf, v -> Config.crystalMaxSelf = v, null)
                .num("Target range", 4, 12, () -> Config.crystalTargetRange, v -> Config.crystalTargetRange = v, null)
                .num("Place delay", 0, 10, () -> Config.crystalPlaceDelay, v -> Config.crystalPlaceDelay = v, null)
                .num("Break delay", 0, 10, () -> Config.crystalBreakDelay, v -> Config.crystalBreakDelay = v, null));

        l.add(Module.toggle("Auto Anchor", combat, () -> Config.autoAnchor, v -> Config.autoAnchor = v, null)
                .bool("Place anchor", () -> Config.anchorPlace, v -> Config.anchorPlace = v, null)
                .bool("Switch back", () -> Config.anchorSwitchBack, v -> Config.anchorSwitchBack = v, null)
                .bool("Look at anchor", () -> Config.anchorRotate, v -> Config.anchorRotate = v, null)
                .bool("Floor place", () -> Config.anchorFloor, v -> Config.anchorFloor = v, null)
                .bool("Target mobs", () -> Config.anchorMobs, v -> Config.anchorMobs = v, null)
                .num("Range", 2, 6, () -> Config.anchorRange, v -> Config.anchorRange = v, null)
                .num("Target range", 4, 12, () -> Config.anchorTargetRange, v -> Config.anchorTargetRange = v, null)
                .num("Delay", 0, 10, () -> Config.anchorDelay, v -> Config.anchorDelay = v, null));

        l.add(Module.toggle("Auto Totem", combat, () -> Config.autoTotem, v -> Config.autoTotem = v, null)
                .num("Delay", 0, 10, () -> Config.totemDelay, v -> Config.totemDelay = v, null));

        l.add(Module.toggle("Auto Armor", combat, () -> Config.autoArmor, v -> Config.autoArmor = v, null)
                .num("Delay", 0, 10, () -> Config.armorDelay, v -> Config.armorDelay = v, null));

        // ---------------- Player ----------------
        l.add(Module.toggle("Auto Eat", player, () -> Config.autoEat, v -> Config.autoEat = v, null)
                .choice("Mode", new String[]{"Hunger", "Health", "Any"}, () -> Config.eatMode, v -> Config.eatMode = v)
                .num("Hunger <=", 1, 19, () -> Config.eatHunger, v -> Config.eatHunger = v, null)
                .num("Health <=", 1, 19, () -> Config.eatHealth, v -> Config.eatHealth = v, null)
                .bool("Pause auras", () -> Config.pauseAuras, v -> Config.pauseAuras = v, null));

        l.add(Module.toggle("Auto MLG", player, () -> Config.mlg, v -> Config.mlg = v, null)
                .dec("Range", 20, 45, () -> Config.mlgRange10, v -> Config.mlgRange10 = v, null)
                .bool("Pick up water", () -> Config.mlgPickup, v -> Config.mlgPickup = v, null)
                .bool("Switch back", () -> Config.mlgSwitchBack, v -> Config.mlgSwitchBack = v, null));

        // ---------------- Render ----------------
        l.add(Module.toggle("ESP", render, () -> Config.espEnabled, v -> Config.espEnabled = v, null)
                .choice("Mode", new String[]{"Box", "Glow"}, () -> Config.espMode, v -> Config.espMode = v)
                .choice("Shape Mode", new String[]{"Lines", "Sides", "Both"}, () -> Config.espShape, v -> Config.espShape = v)
                .num("Fill Opacity", 0, 100, () -> Config.espFill, v -> Config.espFill = v, null)
                .bool("Ignore Self", () -> Config.espIgnoreSelf, v -> Config.espIgnoreSelf = v, null)
                .num("Fade Distance", 0, 10, () -> Config.espFade, v -> Config.espFade = v, null)
                .bool("Highlight Target", () -> Config.espTarget, v -> Config.espTarget = v, null)
                .button("Entities", () -> "Select (" + Config.espEntityTypes.size() + ")",
                        () -> MinecraftClient.getInstance().setScreen(new EntityListScreen(MinecraftClient.getInstance().currentScreen, Config.espEntityTypes)))
                .bool("Distance Colors", () -> Config.espDistColors, v -> Config.espDistColors = v, null)
                .choice("Players Color", EntityEsp.COLOR_NAMES, () -> Config.espColPlayers, v -> Config.espColPlayers = v)
                .choice("Animals Color", EntityEsp.COLOR_NAMES, () -> Config.espColAnimals, v -> Config.espColAnimals = v)
                .choice("Water Animals Color", EntityEsp.COLOR_NAMES, () -> Config.espColWater, v -> Config.espColWater = v)
                .choice("Monsters Color", EntityEsp.COLOR_NAMES, () -> Config.espColMonsters, v -> Config.espColMonsters = v)
                .choice("Ambient Color", EntityEsp.COLOR_NAMES, () -> Config.espColAmbient, v -> Config.espColAmbient = v)
                .choice("Misc Color", EntityEsp.COLOR_NAMES, () -> Config.espColMisc, v -> Config.espColMisc = v));

        l.add(Module.toggle("Block ESP", render, () -> Config.blockEspEnabled, v -> Config.blockEspEnabled = v, null)
                .choice("Shape Mode", new String[]{"Lines", "Sides", "Both"}, () -> Config.blockEspShape, v -> Config.blockEspShape = v)
                .num("Fill Opacity", 0, 100, () -> Config.blockEspFill, v -> Config.blockEspFill = v, null)
                .num("Range", 16, 128, () -> Config.blockEspRange, v -> Config.blockEspRange = v, null)
                .bool("Color By Block", () -> Config.blockEspByBlock, v -> Config.blockEspByBlock = v, null)
                .choice("Color", EntityEsp.COLOR_NAMES, () -> Config.blockEspColor, v -> Config.blockEspColor = v)
                .button("Blocks", () -> "Select (" + Config.blockEspBlocks.size() + ")",
                        () -> MinecraftClient.getInstance().setScreen(new BlockListScreen(MinecraftClient.getInstance().currentScreen, Config.blockEspBlocks))));

        l.add(Module.toggle("Item ESP", render, () -> Config.itemEspEnabled, v -> Config.itemEspEnabled = v, null)
                .choice("Shape Mode", new String[]{"Lines", "Sides", "Both"}, () -> Config.itemEspShape, v -> Config.itemEspShape = v)
                .num("Fill Opacity", 0, 100, () -> Config.itemEspFill, v -> Config.itemEspFill = v, null)
                .num("Range", 8, 128, () -> Config.itemEspRange, v -> Config.itemEspRange = v, null)
                .bool("Names", () -> Config.itemEspNames, v -> Config.itemEspNames = v, null)
                .bool("Show Count", () -> Config.itemEspCount, v -> Config.itemEspCount = v, null)
                .dec("Name Scale", 5, 30, () -> Config.itemEspScale10, v -> Config.itemEspScale10 = v, null)
                .bool("Color By Rarity", () -> Config.itemEspRarity, v -> Config.itemEspRarity = v, null)
                .choice("Color", EntityEsp.COLOR_NAMES, () -> Config.itemEspColor, v -> Config.itemEspColor = v));

        l.add(Module.toggle("Tracers", render, () -> Config.tracers, v -> Config.tracers = v, null)
                .bool("Players", () -> Config.tracerPlayers, v -> Config.tracerPlayers = v, null)
                .bool("Monsters", () -> Config.tracerMonsters, v -> Config.tracerMonsters = v, null)
                .bool("Animals", () -> Config.tracerAnimals, v -> Config.tracerAnimals = v, null)
                .bool("Dropped Items", () -> Config.tracerItems, v -> Config.tracerItems = v, null)
                .bool("Blocks (needs Block ESP)", () -> Config.tracerBlocks, v -> Config.tracerBlocks = v, null)
                .choice("Start", new String[]{"Crosshair", "Bottom", "Top"}, () -> Config.tracerStart, v -> Config.tracerStart = v)
                .num("Range", 8, 256, () -> Config.tracerRange, v -> Config.tracerRange = v, null)
                .num("Max Tracers", 10, 300, () -> Config.tracerMax, v -> Config.tracerMax = v, null)
                .num("Thickness", 1, 4, () -> Config.tracerWidth, v -> Config.tracerWidth = v, null));

        l.add(Module.toggle("HUD", render, () -> Config.hud, v -> Config.hud = v, null)
                .choice("Position", new String[]{"Top Left", "Top Right", "Bottom Left", "Bottom Right"}, () -> Config.hudCorner, v -> Config.hudCorner = v)
                .choice("Sort", new String[]{"Length", "A-Z"}, () -> Config.hudSort, v -> Config.hudSort = v)
                .dec("Scale", 5, 30, () -> Config.hudScale10, v -> Config.hudScale10 = v, null)
                .num("Offset X", 0, 300, () -> Config.hudOffX, v -> Config.hudOffX = v, null)
                .num("Offset Y", 0, 300, () -> Config.hudOffY, v -> Config.hudOffY = v, null)
                .num("Spacing", 0, 10, () -> Config.hudSpacing, v -> Config.hudSpacing = v, null)
                .choice("Color", Hud.COLOR_NAMES, () -> Config.hudColor, v -> Config.hudColor = v)
                .num("Rainbow Speed", 1, 10, () -> Config.hudRainbowSpeed, v -> Config.hudRainbowSpeed = v, null)
                .num("Background", 0, 100, () -> Config.hudBg, v -> Config.hudBg = v, null)
                .bool("Side Bar", () -> Config.hudBar, v -> Config.hudBar = v, null)
                .bool("Shadow", () -> Config.hudShadow, v -> Config.hudShadow = v, null)
                .bool("Show info", () -> Config.hudInfo, v -> Config.hudInfo = v, null));

        l.add(Module.toggle("Fullbright", render, () -> Config.fullbright, v -> Config.fullbright = v, null)
                .choice("Mode", new String[]{"Gamma", "Potion"}, () -> Config.fullbrightMode, v -> Config.fullbrightMode = v));

        l.add(Module.toggle("Free Look", render, () -> Config.freelook, v -> Config.freelook = v, null)
                .bool("Hold key only", () -> Config.freelookHold, v -> Config.freelookHold = v, null));

        l.add(Module.toggle("Freecam", render, () -> Config.freecam, v -> Config.freecam = v, null)
                .num("Speed (b/s)", 2, 60, () -> Config.freecamSpeed, v -> Config.freecamSpeed = v, null));

        // ---------------- Misc ----------------
        l.add(Module.action("Accounts", misc, () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new AccountScreen(mc.currentScreen));
        }));

        return l;
    }
}
