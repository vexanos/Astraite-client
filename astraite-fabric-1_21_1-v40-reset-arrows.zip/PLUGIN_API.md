# Astraite Plugin API (v1)

A plugin is a **second Fabric mod** that connects to Astraite. Its modules appear in the
Astraite click GUI (keybinds, HUD list, saved settings all work) and both mods run together.

## 1. Set up the plugin project
Use the `astraite-example-plugin` project. Put the Astraite jar in `libs/astraite.jar`.
`fabric.mod.json` of the plugin:

```json
"entrypoints": { "astraite": [ "com.example.hello.HelloPlugin" ] },
"depends": { "chesthl": "*" }
```

## 2. Write the plugin
```java
public class HelloPlugin implements AstraitePlugin {
    @Override
    public void onAstraiteLoad(AstraiteApi api) {
        PluginModule m = api.module("Hello", Module.Category.MISC);

        PluginModule.BoolValue shout   = m.addBool("Shout", false);
        PluginModule.IntValue  seconds = m.addInt("Interval (s)", 1, 60, 10);
        PluginModule.ChoiceValue mode  = m.addChoice("Mode", new String[]{"A", "B"}, 0);
        PluginModule.DecimalValue size = m.addDecimal("Scale", 0.5, 3.0, 1.0);

        m.onTick(mc -> { /* every tick while the module is ON */ });
        m.onHud(ctx -> { /* every frame, ctx is a DrawContext */ });
        m.onWorldRender(ctx -> api.worldLabel(somePos, "text", 0x55FF55));
        m.onEnable(() -> {}); m.onDisable(() -> {});
        m.info(() -> mode.get());            // text next to the name in the HUD list
        m.addButton("Reset", () -> "click", () -> {});
    }
}
```

## API overview
| Where | What |
|---|---|
| `api.module(name, category)` | new module (COMBAT / PLAYER / RENDER / MISC) |
| `PluginModule.addBool/addInt/addDecimal/addChoice/addButton` | settings, saved automatically |
| `PluginModule.onTick/onHud/onWorldRender/onEnable/onDisable/info` | handlers, only run while the module is ON |
| `api.onTick/onHud/onWorldRender` | global handlers, always run |
| `api.worldLabel(pos, text, rgb)` / `api.worldLine(pos, rgb)` | 2D label / tracer at a world position (use inside a world-render handler) |
| `api.isEnabled(name)` / `api.setEnabled(name, on)` | read / toggle ANY module, e.g. `"Kill Aura"` |
| `api.moduleNames()` | all module names |
| `api.notify(text)` / `api.chat(text)` | message above hotbar / in chat |
| `api.log()` | slf4j logger |

## Good to know
* State and settings are stored in `config/astraite-plugins.json`.
* If a name is already taken, the module is shown as `Name (pluginId)`.
* A handler that throws 3 times gets its module switched off (and the error is logged) instead of crashing the game.
* The Misc > **Plugins** button lists the loaded plugins in chat.
* `API_VERSION` (in `AstraiteApi`) is bumped when something breaks.
