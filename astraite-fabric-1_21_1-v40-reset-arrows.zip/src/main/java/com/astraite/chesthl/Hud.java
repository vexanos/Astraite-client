package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/** On-screen list of every module that is currently switched on (position, scale, colours, background, ...). */
final class Hud {
    static final String[] COLOR_NAMES = {"Rainbow", "Category", "White", "Red", "Green", "Blue", "Yellow", "Cyan", "Purple", "Orange"};
    private static final int[] STATIC = {0xFFFFFF, 0xFF5555, 0x55FF55, 0x5555FF, 0xFFFF55, 0x55FFFF, 0xFF55FF, 0xFFAA00};

    private static List<Module> modules;

    private static final class Row {
        final Module module;
        final String name;
        final String info;
        final int nameW;
        final int totalW;

        Row(Module module, String info, MinecraftClient mc) {
            this.module = module;
            this.name = module.name;
            this.info = info;
            this.nameW = mc.textRenderer.getWidth(name);
            this.totalW = info.isEmpty() ? nameW : nameW + mc.textRenderer.getWidth(" " + info);
        }
    }

    private Hud() {
    }

    private static String info(String module) {
        String pluginInfo = PluginManager.info(module);
        if (pluginInfo != null) return pluginInfo;
        return switch (module) {
            case "Crystal Aura" -> CrystalAura.status;
            case "Auto Anchor" -> AutoAnchor.status;
            case "Auto MLG" -> AutoMlg.status;
            case "Auto Totem+" -> AutoTotemPlus.status;
            case "Surround" -> Surround.status;
            case "Auto Trap" -> AutoTrap.status;
            case "Scaffold" -> Scaffold.status;
            case "Storage ESP" -> StorageEsp.status;
            default -> "";
        };
    }

    private static int categoryColor(Module m) {
        return switch (m.category) {
            case COMBAT -> 0xFF5555;
            case PLAYER -> 0x55FF55;
            case RENDER -> 0x55FFFF;
            case MISC -> 0xFFFF55;
        };
    }

    private static int color(Row r, int index) {
        if (Config.hudColor == 0) {
            float hue = (((System.currentTimeMillis() * Config.hudRainbowSpeed) % 12000L) / 12000f + index * 0.06f) % 1f;
            return 0xFF000000 | MathHelper.hsvToRgb(hue, 0.55f, 1.0f);
        }
        if (Config.hudColor == 1) return 0xFF000000 | categoryColor(r.module);
        int i = Math.max(0, Math.min(STATIC.length - 1, Config.hudColor - 2));
        return 0xFF000000 | STATIC[i];
    }

    static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.hud || mc.player == null || mc.options.hudHidden) return;
        if (modules == null) modules = Modules.all();

        List<Row> rows = new ArrayList<>();
        for (Module m : modules) {
            if (!m.isToggle() || !m.isOn() || m.name.equals("HUD")) continue;
            String inf = Config.hudInfo ? info(m.name) : "";
            rows.add(new Row(m, inf == null ? "" : inf, mc));
        }
        if (rows.isEmpty()) return;

        if (Config.hudSort == 1) rows.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        else rows.sort((a, b) -> Integer.compare(b.totalW, a.totalW));

        float scale = Config.hudScale10 / 10f;
        float sw = ctx.getScaledWindowWidth() / scale;
        float sh = ctx.getScaledWindowHeight() / scale;
        int rowH = 10 + Config.hudSpacing;
        boolean right = Config.hudCorner == 1 || Config.hudCorner == 3;
        boolean bottom = Config.hudCorner == 2 || Config.hudCorner == 3;
        int bgColor = Config.hudBg > 0 ? ((int) (Config.hudBg / 100.0 * 255) << 24) : 0;

        int y = bottom ? (int) (sh - Config.hudOffY - rows.size() * rowH + Config.hudSpacing) : Config.hudOffY;

        ctx.getMatrices().push();
        ctx.getMatrices().scale(scale, scale, 1f);
        int i = 0;
        for (Row r : rows) {
            int x = right ? (int) (sw - Config.hudOffX - r.totalW) : Config.hudOffX;
            int c = color(r, i);
            if (bgColor != 0) ctx.fill(x - 2, y - 1, x + r.totalW + 2, y + 9, bgColor);
            if (Config.hudBar) {
                if (right) ctx.fill(x + r.totalW + 2, y - 1, x + r.totalW + 3, y + 9, c);
                else ctx.fill(x - 3, y - 1, x - 2, y + 9, c);
            }
            ctx.drawText(mc.textRenderer, r.name, x, y, c, Config.hudShadow);
            if (!r.info.isEmpty()) {
                ctx.drawText(mc.textRenderer, " " + r.info, x + r.nameW, y, 0xFFAAAAAA, Config.hudShadow);
            }
            y += rowH;
            i++;
        }
        ctx.getMatrices().pop();
    }
}
