package com.astraite.chesthl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** One entry in the click GUI: a toggle (with settings) or a plain action. */
public final class Module {
    public enum Category {
        COMBAT("Combat"), PLAYER("Player"), RENDER("Render"), MISC("Misc");

        public final String title;

        Category(String title) {
            this.title = title;
        }
    }

    public abstract static class Setting {
        public final String name;

        Setting(String name) {
            this.name = name;
        }

        /** The current value (Boolean / Integer) or null for settings without a value. */
        public Object current() {
            return null;
        }

        /** Sets the value that {@link #reset()} restores (Boolean / Integer). */
        public void setDefault(Object value) {
        }

        /** Restores the default value (does nothing when no default is known). */
        public void reset() {
        }
    }

    public static final class Bool extends Setting {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;
        private final Runnable after;

        Bool(String name, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
            super(name);
            this.get = get;
            this.set = set;
            this.after = after;
        }

        private Boolean def;

        public boolean value() {
            return get.getAsBoolean();
        }

        @Override
        public Object current() {
            return value();
        }

        @Override
        public void setDefault(Object o) {
            if (o instanceof Boolean b) def = b;
        }

        @Override
        public void reset() {
            if (def == null) return;
            set.accept(def);
            if (after != null) after.run();
        }

        public void toggle() {
            set.accept(!value());
            if (after != null) after.run();
        }
    }

    public static final class Int extends Setting {
        public final int min, max, div;
        private final IntSupplier get;
        private final IntConsumer set;
        private final Runnable after;

        Int(String name, int min, int max, int div, IntSupplier get, IntConsumer set, Runnable after) {
            super(name);
            this.div = div;
            this.min = min;
            this.max = max;
            this.get = get;
            this.set = set;
            this.after = after;
        }

        private Integer def;

        public int value() {
            return get.getAsInt();
        }

        @Override
        public Object current() {
            return value();
        }

        @Override
        public void setDefault(Object o) {
            if (o instanceof Integer i) def = i;
        }

        @Override
        public void reset() {
            if (def == null) return;
            set.accept(def);
            if (after != null) after.run();
        }

        public String display() {
            return div == 1 ? String.valueOf(value()) : String.format("%.1f", value() / (double) div);
        }

        public double fraction() {
            return max == min ? 0 : (value() - min) / (double) (max - min);
        }

        public void setFraction(double f) {
            double c = Math.max(0, Math.min(1, f));
            set.accept(min + (int) Math.round(c * (max - min)));
            if (after != null) after.run();
        }
    }

    public static final class Choice extends Setting {
        private final String[] options;
        private final IntSupplier get;
        private final IntConsumer set;

        Choice(String name, String[] options, IntSupplier get, IntConsumer set) {
            super(name);
            this.options = options;
            this.get = get;
            this.set = set;
        }

        private Integer def;

        public String label() {
            return options[Math.max(0, Math.min(options.length - 1, get.getAsInt()))];
        }

        @Override
        public Object current() {
            return get.getAsInt();
        }

        @Override
        public void setDefault(Object o) {
            if (o instanceof Integer i) def = i;
        }

        @Override
        public void reset() {
            if (def != null) set.accept(def);
        }

        public void cycle() {
            set.accept((get.getAsInt() + 1) % options.length);
        }
    }

    /** A button row: shows "name: label" and runs something when clicked. */
    public static final class Action extends Setting {
        private final Supplier<String> label;
        private final Runnable run;

        Action(String name, Supplier<String> label, Runnable run) {
            super(name);
            this.label = label;
            this.run = run;
        }

        public String text() {
            return name + ": " + label.get();
        }

        public void run() {
            run.run();
        }
    }

    public final String name;
    public final Category category;
    public final Bool active;        // null for plain actions
    private final Runnable action;   // null for toggles
    public final List<Setting> settings = new ArrayList<>();

    private Module(String name, Category category, Bool active, Runnable action) {
        this.name = name;
        this.category = category;
        this.active = active;
        this.action = action;
    }

    public static Module toggle(String name, Category cat, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
        return new Module(name, cat, new Bool("Active", get, set, after), null);
    }

    public static Module action(String name, Category cat, Runnable run) {
        return new Module(name, cat, null, run);
    }

    /** Puts every setting of this module back to its default (the on/off state is not touched). */
    public void resetSettings() {
        for (Setting st : settings) st.reset();
    }

    public boolean isToggle() {
        return active != null;
    }

    public boolean isOn() {
        return active != null && active.value();
    }

    public void click() {
        if (active != null) active.toggle();
        else if (action != null) action.run();
    }

    public Module bool(String name, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
        settings.add(new Bool(name, get, set, after));
        return this;
    }

    public Module num(String name, int min, int max, IntSupplier get, IntConsumer set, Runnable after) {
        settings.add(new Int(name, min, max, 1, get, set, after));
        return this;
    }

    /** Like num(), but the stored int is shown divided by 10 (e.g. 35 -> 3.5). */
    public Module dec(String name, int minTenths, int maxTenths, IntSupplier get, IntConsumer set, Runnable after) {
        settings.add(new Int(name, minTenths, maxTenths, 10, get, set, after));
        return this;
    }

    public Module button(String name, Supplier<String> label, Runnable run) {
        settings.add(new Action(name, label, run));
        return this;
    }

    public Module choice(String name, String[] options, IntSupplier get, IntConsumer set) {
        settings.add(new Choice(name, options, get, set));
        return this;
    }
}
