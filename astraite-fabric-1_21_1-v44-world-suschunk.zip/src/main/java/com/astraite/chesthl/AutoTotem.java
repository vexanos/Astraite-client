package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotem {
    private static int cooldown = 0;

    public static void tick(MinecraftClient mc) {
        if (!Config.autoTotem || Config.totemPlus) return; // Auto Totem+ takes over
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.world == null) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        // PlayerScreenHandler slots: 9-35 main inventory, 36-44 hotbar, 45 offhand
        int slot = -1;
        for (int i = 9; i < 36 && slot < 0; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) slot = i;
        }
        for (int i = 0; i < 9 && slot < 0; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) slot = 36 + i;
        }
        if (slot < 0) return;

        // button 40 = swap with offhand
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
        cooldown = Math.max(0, Config.totemDelay);
    }
}
