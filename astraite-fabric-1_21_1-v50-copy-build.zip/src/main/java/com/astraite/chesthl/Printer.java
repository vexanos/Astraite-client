package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.state.property.Property;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Schematic printer (Litematica style): load a .litematic / .schem from .minecraft/schematics, set where it goes,
 * see what is missing, and let the client place it for you using blocks from your hotbar AND inventory.
 */
public final class Printer {
    public static String status = "";

    static volatile Schem schem;
    private static volatile String loading = "";
    private static boolean triedAutoLoad = false;
    private static int cd = 0;
    private static int scanTimer = 0;
    private static int nearMissing = 0;
    // anti-spam: a block we just clicked is not tried again until the server had time to answer
    private static final Map<BlockPos, Long> pending = new HashMap<>();
    // whole-build progress (scanned a few thousand cells per tick) + where to walk next
    private static int scanY = 0, scanI = 0, passTotal = 0, passDone = 0;
    static volatile int percent = -1;
    private static BlockPos walkBest = null, walkTarget = null;
    private static double walkBestD = Double.MAX_VALUE;
    private static boolean doneNotified = false;
    private static int walkTimer = 0;
    private static boolean walking = false;
    private static int lastSig = 0;
    private static volatile List<BlockPos> prevMissing = List.of();
    private static volatile List<BlockPos> prevWrong = List.of();

    private static final int OK = 0, MISSING = 1, WRONG = 2;

    private Printer() {
    }

    // ------------------------------------------------------------------ files / loading

    static Path dir() {
        Path d = FabricLoader.getInstance().getGameDir().resolve("schematics");
        try {
            Files.createDirectories(d);
        } catch (IOException ignored) {
        }
        return d;
    }

    static List<String> files() {
        List<String> out = new ArrayList<>();
        try (var st = Files.list(dir())) {
            st.forEach(pa -> {
                String n = pa.getFileName().toString();
                String l = n.toLowerCase(Locale.ROOT);
                if (l.endsWith(".litematic") || l.endsWith(".schem")) out.add(n);
            });
        } catch (IOException ignored) {
        }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    static String loadedName() {
        Schem s = schem;
        return s == null ? "" : s.name;
    }

    static void load(String fileName) {
        loading = fileName;
        status = "Loading " + fileName + "...";
        Thread t = new Thread(() -> {
            try {
                Schem s = Schem.load(dir().resolve(fileName));
                s.setTransform(Config.prRot, Config.prMirror);
                schem = s;
                prevMissing = List.of();
                prevWrong = List.of();
                Config.schemFile = fileName;
                Config.save();
                status = "Loaded " + s.name + " (" + s.dx + "x" + s.dy + "x" + s.dz + ")";
            } catch (Throwable e) {
                status = "Load failed: " + e.getMessage();
            } finally {
                loading = "";
            }
        }, "astraite-schematic");
        t.setDaemon(true);
        t.start();
    }

    /** Makes a schematic (e.g. just copied from the world) the loaded one. */
    static void setLoaded(Schem s, String fileName) {
        s.setTransform(Config.prRot, Config.prMirror);
        schem = s;
        prevMissing = List.of();
        prevWrong = List.of();
        Config.schemFile = fileName;
        Config.save();
        status = "Loaded " + s.name + " (" + s.dx + "x" + s.dy + "x" + s.dz + ")";
    }

    private static void resetProgress() {
        scanY = 0;
        scanI = 0;
        passTotal = 0;
        passDone = 0;
        percent = -1;
        walkBest = null;
        walkTarget = null;
        walkBestD = Double.MAX_VALUE;
        doneNotified = false;
        pending.clear();
    }

    static void unload() {
        schem = null;
        prevMissing = List.of();
        prevWrong = List.of();
        Config.schemFile = "";
        Config.save();
        status = "Unloaded";
    }

    // ------------------------------------------------------------------ placement of the whole schematic

    static BlockPos origin() {
        return new BlockPos(Config.schemOx + Config.prOffX, Config.schemOy + Config.prOffY, Config.schemOz + Config.prOffZ);
    }

    static void setOrigin(BlockPos p) {
        Config.schemOx = p.getX();
        Config.schemOy = p.getY();
        Config.schemOz = p.getZ();
        Config.schemOriginSet = true;
        Config.save();
    }

    static void originHere(ClientPlayerEntity p) {
        setOrigin(p.getBlockPos());
    }

    static boolean originLook(MinecraftClient mc) {
        if (mc.crosshairTarget instanceof BlockHitResult bhr && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            setOrigin(bhr.getBlockPos().offset(bhr.getSide()));
            return true;
        }
        return false;
    }

    static void nudge(int x, int y, int z) {
        setOrigin(new BlockPos(Config.schemOx + x, Config.schemOy + y, Config.schemOz + z));
    }

    // ------------------------------------------------------------------ state matching

    /** Properties that placing can decide (direction / axis / half / slab type). Others are ignored. */
    private static boolean relevant(Property<?> p, Block b) {
        switch (p.getName()) {
            case "facing", "axis", "half", "face", "rotation":
                return true;
            case "type":
                return b instanceof SlabBlock;
            default:
                return false;
        }
    }

    private static boolean matches(BlockState want, BlockState have) {
        if (want.getBlock() != have.getBlock()) return false;
        for (Property<?> p : want.getProperties()) {
            if (!relevant(p, want.getBlock())) continue;
            if (!have.contains(p)) continue;
            if (!want.get(p).equals(have.get(p))) return false;
        }
        return true;
    }

    private static boolean isDoubleSlab(BlockState st) {
        return st.getBlock() instanceof SlabBlock && st.get(SlabBlock.TYPE) == SlabType.DOUBLE;
    }

    private static boolean slabMerge(BlockState want, BlockState have) {
        return want.getBlock() == have.getBlock() && isDoubleSlab(want) && have.get(SlabBlock.TYPE) != SlabType.DOUBLE;
    }

    /** Blocks that come as part of another block (door top, bed head) or have no item (water, fire...) are not planned. */
    private static boolean plannable(BlockState want) {
        if (want.isAir()) return false;
        if (want.getBlock().asItem() == Items.AIR) return false;
        if (want.contains(Properties.DOUBLE_BLOCK_HALF) && want.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) return false;
        if (want.contains(Properties.BED_PART) && want.get(Properties.BED_PART) == BedPart.HEAD) return false;
        return true;
    }

    private static int classify(BlockState want, BlockState have) {
        if (want.getBlock() == have.getBlock()) {
            if (matches(want, have)) return OK;
            return slabMerge(want, have) ? MISSING : WRONG;
        }
        if (have.isAir() || have.isReplaceable()) return MISSING;
        return WRONG;
    }

    private static boolean layerOk(int relY) {
        return switch (Config.prLayerMode) {
            case 1 -> relY == Config.prLayer;
            case 2 -> relY <= Config.prLayer;
            default -> true;
        };
    }

    // ------------------------------------------------------------------ tick

    private static final class Cand {
        final BlockPos pos;
        final BlockState want;
        final boolean merge, fragile;
        final double d2;

        Cand(BlockPos pos, BlockState want, boolean merge, boolean fragile, double d2) {
            this.pos = pos;
            this.want = want;
            this.merge = merge;
            this.fragile = fragile;
            this.d2 = d2;
        }
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.printer) {
            status = loading.isEmpty() ? "" : status;
            if (!prevMissing.isEmpty() || !prevWrong.isEmpty()) {
                prevMissing = List.of();
                prevWrong = List.of();
            }
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) return;

        if (!triedAutoLoad) {
            triedAutoLoad = true;
            if (schem == null && !Config.schemFile.isEmpty() && Files.exists(dir().resolve(Config.schemFile))) {
                load(Config.schemFile);
            }
        }
        Schem s = schem;
        if (s == null) {
            if (loading.isEmpty()) status = "No schematic (open Schematics)";
            return;
        }
        if (s.rot != Config.prRot || s.mir != Config.prMirror) s.setTransform(Config.prRot, Config.prMirror);
        if (!Config.schemOriginSet) originHere(p);

        int sig = java.util.Objects.hash(System.identityHashCode(s), Config.schemOx, Config.schemOy, Config.schemOz,
                Config.prOffX, Config.prOffY, Config.prOffZ, Config.prRot, Config.prMirror);
        if (sig != lastSig) {
            lastSig = sig;
            resetProgress();
        }
        final long now = w.getTime();
        pending.values().removeIf(t -> now - t > 100);

        if (++scanTimer >= 10) {
            scanTimer = 0;
            scanPreview(w, p, s);
        }
        progressStep(mc, w, p, s);

        String missingItem = null;
        int stuck = 0;
        boolean nothingToPlace = false;
        if (mc.currentScreen == null && !p.isDead() && !p.isSpectator()) {
            if (cd > 0) {
                cd--;
            } else {
                double range = Config.prRange10 / 10.0;
                Vec3d eye = p.getEyePos();
                BlockPos o = origin();
                int R = (int) Math.ceil(range);
                BlockPos ep = BlockPos.ofFloored(eye);
                List<Cand> todo = new ArrayList<>();
                int x0 = Math.max(ep.getX() - R, o.getX()), x1 = Math.min(ep.getX() + R, o.getX() + s.tdx - 1);
                int y0 = Math.max(ep.getY() - R, o.getY()), y1 = Math.min(ep.getY() + R, o.getY() + s.dy - 1);
                int z0 = Math.max(ep.getZ() - R, o.getZ()), z1 = Math.min(ep.getZ() + R, o.getZ() + s.tdz - 1);
                for (int y = y0; y <= y1; y++) {
                    if (!layerOk(y - o.getY())) continue;
                    for (int x = x0; x <= x1; x++) {
                        for (int z = z0; z <= z1; z++) {
                            BlockState want = s.at(x - o.getX(), y - o.getY(), z - o.getZ());
                            if (want == null || !plannable(want)) continue;
                            BlockPos pos = new BlockPos(x, y, z);
                            double d2 = eye.squaredDistanceTo(Vec3d.ofCenter(pos));
                            if (d2 > range * range) continue;
                            BlockState have = w.getBlockState(pos);
                            if (classify(want, have) != MISSING) continue;
                            boolean merge = slabMerge(want, have);
                            Long pt = pending.get(pos);
                            if (pt != null && now - pt < Config.prRetry) continue; // clicked a moment ago, wait for the server
                            if (!merge && !Placer.canPlace(w, pos)) continue; // something stands there
                            boolean fragile = !Block.isShapeFullCube(want.getCollisionShape(w, pos));
                            todo.add(new Cand(pos, want, merge, fragile, d2));
                        }
                    }
                }
                if (Config.prOrder == 0) {
                    todo.sort(Comparator.comparingInt((Cand c) -> c.pos.getY())
                            .thenComparingInt(c -> c.fragile ? 1 : 0)
                            .thenComparingDouble(c -> c.d2));
                } else {
                    todo.sort(Comparator.comparingDouble((Cand c) -> c.d2));
                }

                nothingToPlace = todo.isEmpty();
                int prev = p.getInventory().selectedSlot;
                boolean switched = false, rotated = false;
                int placed = 0;
                Set<Item> noItem = new HashSet<>();
                for (Cand c : todo) {
                    if (!Config.prBuild) break; // preview only
                    if (placed >= Config.prPerTick) break;
                    Item item = c.want.getBlock().asItem();
                    if (noItem.contains(item)) continue;
                    int slot = prepare(mc, p, item);
                    if (slot < 0) {
                        noItem.add(item);
                        if (missingItem == null) missingItem = item.getName().getString();
                        continue;
                    }
                    ItemStack stack = p.getInventory().getStack(slot);
                    Plan pl = solve(p, w, c.pos, c.want, stack, c.merge);
                    if (pl == null) {
                        stuck++;
                        continue;
                    }
                    if (p.getInventory().selectedSlot != slot) {
                        p.getInventory().selectedSlot = slot;
                        switched = true;
                    }
                    if (pl.rot) {
                        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(pl.yaw, pl.pitch, p.isOnGround()));
                        rotated = true;
                    } else if (Config.prRotate) {
                        Placer.face(p, pl.hit.getPos());
                        rotated = true;
                    }
                    mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, pl.hit);
                    p.swingHand(Hand.MAIN_HAND);
                    pending.put(c.pos, now);
                    placed++;
                }
                if (switched) p.getInventory().selectedSlot = prev;
                if (rotated) Placer.resync(p);
                if (placed > 0) cd = Config.prDelay;
            }
        }

        // nothing left in reach: walk to the next missing blocks (Baritone)
        walking = false;
        if (Config.prWalk && Config.prBuild && nothingToPlace && missingItem == null && walkTarget != null
                && mc.currentScreen == null) {
            if (++walkTimer >= 20) {
                walkTimer = 0;
                BaritoneUtil.goNear(walkTarget, Math.max(2, (int) (Config.prRange10 / 10.0 * 0.6)));
            }
            walking = true;
        }

        String st = s.name + (percent >= 0 ? " " + percent + "%" : "") + ": " + nearMissing + " missing nearby";
        if (!Config.prBuild) st += " | preview only";
        else if (missingItem != null) st += " | need " + missingItem;
        else if (stuck > 0) st += " | " + stuck + " need support";
        else if (walking) st += " | walking to next part";
        status = st;
    }

    /** Scans the whole schematic a few thousand cells per tick: progress %, completion message, next place to walk to. */
    private static void progressStep(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, Schem s) {
        BlockPos o = origin();
        int layerCells = s.tdx * s.tdz;
        if (layerCells <= 0) return;
        Vec3d pe = p.getPos();
        BlockPos.Mutable m = new BlockPos.Mutable();
        int budget = 8000;
        while (budget-- > 0) {
            if (scanY >= s.dy) { // one full pass done
                percent = passTotal == 0 ? -1 : (int) (100L * passDone / passTotal);
                walkTarget = walkBest;
                if (percent == 100 && !doneNotified) {
                    doneNotified = true;
                    if (Config.prNotify) {
                        p.sendMessage(Text.literal("[Printer] Build complete: " + s.name).formatted(Formatting.GREEN), false);
                        if (mc.inGameHud != null) mc.inGameHud.setOverlayMessage(Text.literal("Build complete!"), false);
                    }
                } else if (percent >= 0 && percent < 100) {
                    doneNotified = false;
                }
                scanY = 0;
                scanI = 0;
                passTotal = 0;
                passDone = 0;
                walkBest = null;
                walkBestD = Double.MAX_VALUE;
                return;
            }
            int ty = scanY;
            int tx = scanI % s.tdx, tz = scanI / s.tdx;
            if (++scanI >= layerCells) {
                scanI = 0;
                scanY++;
            }
            BlockState want = s.at(tx, ty, tz);
            if (want == null || !plannable(want)) continue;
            int wx = o.getX() + tx, wy = o.getY() + ty, wz = o.getZ() + tz;
            if (!w.isChunkLoaded(wx >> 4, wz >> 4)) continue; // not loaded: do not count it
            passTotal++;
            m.set(wx, wy, wz);
            int c = classify(want, w.getBlockState(m));
            if (c == OK) {
                passDone++;
            } else if (c == MISSING) {
                double d = pe.squaredDistanceTo(wx + 0.5, wy + 0.5, wz + 0.5);
                if (d < walkBestD) {
                    walkBestD = d;
                    walkBest = m.toImmutable();
                }
            }
        }
    }

    private static void scanPreview(ClientWorld w, ClientPlayerEntity p, Schem s) {
        BlockPos o = origin();
        BlockPos pp = p.getBlockPos();
        int R = Config.prPreviewRadius;
        int x0 = Math.max(pp.getX() - R, o.getX()), x1 = Math.min(pp.getX() + R, o.getX() + s.tdx - 1);
        int y0 = Math.max(pp.getY() - R, o.getY()), y1 = Math.min(pp.getY() + R, o.getY() + s.dy - 1);
        int z0 = Math.max(pp.getZ() - R, o.getZ()), z1 = Math.min(pp.getZ() + R, o.getZ() + s.tdz - 1);
        List<BlockPos> miss = new ArrayList<>();
        List<BlockPos> wrong = new ArrayList<>();
        int nMiss = 0;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = y0; y <= y1; y++) {
            if (!layerOk(y - o.getY())) continue;
            for (int x = x0; x <= x1; x++) {
                for (int z = z0; z <= z1; z++) {
                    BlockState want = s.at(x - o.getX(), y - o.getY(), z - o.getZ());
                    if (want == null || !plannable(want)) continue;
                    m.set(x, y, z);
                    int c = classify(want, w.getBlockState(m));
                    if (c == MISSING) {
                        nMiss++;
                        if (miss.size() < 3000) miss.add(m.toImmutable());
                    } else if (c == WRONG && Config.prShowWrong && wrong.size() < 1500) {
                        wrong.add(m.toImmutable());
                    }
                }
            }
        }
        nearMissing = nMiss;
        prevMissing = miss;
        prevWrong = wrong;
    }

    // ------------------------------------------------------------------ inventory

    /** Hotbar slot (0-8) that holds the item. Pulls it out of the inventory (or the creative menu) if needed; -1 if none. */
    private static int prepare(MinecraftClient mc, ClientPlayerEntity p, Item item) {
        int cur = p.getInventory().selectedSlot;
        if (p.getInventory().getStack(cur).isOf(item)) return cur;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(item)) return i;
        }
        int scratch = PlaceUtil.slotIdx(Config.prSlot);
        if (Config.prInv) {
            for (int i = 9; i < 36; i++) {
                if (p.getInventory().getStack(i).isOf(item)) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, scratch, SlotActionType.SWAP, p);
                    return scratch;
                }
            }
        }
        if (p.isCreative()) {
            mc.interactionManager.clickCreativeStack(new ItemStack(item), 36 + scratch);
            return scratch;
        }
        return -1;
    }

    // ------------------------------------------------------------------ working out how to place a state

    private static final class Plan {
        BlockHitResult hit;
        float yaw, pitch;
        boolean rot;
    }

    private static boolean interactive(Block b) {
        return b == Blocks.CRAFTING_TABLE || b == Blocks.NOTE_BLOCK || b == Blocks.RESPAWN_ANCHOR
                || b == Blocks.SMITHING_TABLE || b == Blocks.CARTOGRAPHY_TABLE || b == Blocks.LOOM
                || b == Blocks.GRINDSTONE || b == Blocks.STONECUTTER;
    }

    /**
     * Finds a click (and the look direction) that makes the game place exactly this state at pos.
     * It asks the block itself (getPlacementState) for every click side / half / facing, so stairs, logs, slabs,
     * furnaces, pistons... come out the right way round.
     */
    private static Plan solve(ClientPlayerEntity p, ClientWorld w, BlockPos pos, BlockState wantIn, ItemStack stack, boolean merge) {
        if (merge) { // second half of a double slab: click the existing slab
            boolean bottom = w.getBlockState(pos).get(SlabBlock.TYPE) == SlabType.BOTTOM;
            Plan pl = new Plan();
            pl.hit = new BlockHitResult(new Vec3d(pos.getX() + 0.5, pos.getY() + (bottom ? 1.0 : 0.0), pos.getZ() + 0.5),
                    bottom ? Direction.UP : Direction.DOWN, pos, false);
            return pl;
        }
        BlockState want = isDoubleSlab(wantIn) ? wantIn.with(SlabBlock.TYPE, SlabType.BOTTOM) : wantIn;
        Block block = want.getBlock();
        boolean orient = false;
        for (Property<?> pr : want.getProperties()) {
            if (relevant(pr, block)) {
                orient = true;
                break;
            }
        }
        double[] fr = orient ? new double[]{0.25, 0.75} : new double[]{0.5};

        List<BlockHitResult> hits = new ArrayList<>();
        for (Direction d : Direction.values()) { // against a neighbour (DOWN first = on top of the floor)
            BlockPos n = pos.offset(d);
            BlockState st = w.getBlockState(n);
            if (st.isAir() || st.isReplaceable() || !st.isFullCube(w, n) || st.hasBlockEntity() || interactive(st.getBlock())) continue;
            Direction face = d.getOpposite();
            for (double f : fr) {
                double hx = n.getX() + 0.5 + face.getOffsetX() * 0.5;
                double hz = n.getZ() + 0.5 + face.getOffsetZ() * 0.5;
                double hy = face.getAxis().isVertical() ? n.getY() + 0.5 + face.getOffsetY() * 0.5 : pos.getY() + f;
                hits.add(new BlockHitResult(new Vec3d(hx, hy, hz), face, n, false));
            }
        }
        if (Config.prAir) { // air place: click the empty spot itself
            for (Direction side : Direction.values()) {
                for (double f : fr) {
                    hits.add(new BlockHitResult(new Vec3d(pos.getX() + 0.5, pos.getY() + f, pos.getZ() + 0.5), side, pos, false));
                }
            }
        }
        if (hits.isEmpty()) return null;

        float oy = p.getYaw(), op = p.getPitch();
        float[] yaws, pitches;
        if (!orient) {
            yaws = new float[]{oy};
            pitches = new float[]{op};
        } else {
            if (want.contains(Properties.ROTATION)) {
                yaws = new float[16];
                for (int i = 0; i < 16; i++) yaws[i] = i * 22.5f - 180f;
            } else {
                yaws = new float[]{0f, 90f, 180f, 270f};
            }
            pitches = new float[]{0f, 90f, -90f};
        }
        for (BlockHitResult hit : hits) {
            for (float yaw : yaws) {
                for (float pitch : pitches) {
                    BlockState got = null;
                    p.setYaw(yaw);
                    p.setPitch(pitch);
                    try {
                        got = block.getPlacementState(new ItemPlacementContext(p, Hand.MAIN_HAND, stack, hit));
                    } catch (Throwable ignored) {
                    }
                    p.setYaw(oy);
                    p.setPitch(op);
                    if (got == null || !matches(want, got) || !got.canPlaceAt(w, pos)) continue;
                    Plan pl = new Plan();
                    pl.hit = hit;
                    pl.yaw = yaw;
                    pl.pitch = pitch;
                    pl.rot = orient;
                    return pl;
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ materials list (chat)

    static void materials(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        Schem s = schem;
        if (p == null || w == null) return;
        if (s == null) {
            p.sendMessage(Text.literal("[Printer] No schematic loaded").formatted(Formatting.RED), false);
            return;
        }
        BlockPos o = origin();
        Map<Item, Integer> need = new HashMap<>();
        for (int ty = 0; ty < s.dy; ty++) {
            for (int tx = 0; tx < s.tdx; tx++) {
                for (int tz = 0; tz < s.tdz; tz++) {
                    BlockState want = s.at(tx, ty, tz);
                    if (want == null || !plannable(want)) continue;
                    BlockState have = w.getBlockState(new BlockPos(o.getX() + tx, o.getY() + ty, o.getZ() + tz));
                    if (classify(want, have) != MISSING) continue;
                    int count = isDoubleSlab(want) && have.getBlock() != want.getBlock() ? 2 : 1;
                    need.merge(want.getBlock().asItem(), count, Integer::sum);
                }
            }
        }
        if (need.isEmpty()) {
            p.sendMessage(Text.literal("[Printer] Nothing missing - " + s.name + " is complete").formatted(Formatting.GREEN), false);
            return;
        }
        List<Map.Entry<Item, Integer>> rows = new ArrayList<>(need.entrySet());
        rows.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        p.sendMessage(Text.literal("[Printer] Missing blocks for " + s.name + ":").formatted(Formatting.AQUA), false);
        int shown = 0;
        for (Map.Entry<Item, Integer> e : rows) {
            if (shown++ >= 14) break;
            int have = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (st.isOf(e.getKey())) have += st.getCount();
            }
            if (p.getOffHandStack().isOf(e.getKey())) have += p.getOffHandStack().getCount();
            boolean enough = have >= e.getValue();
            p.sendMessage(Text.literal("  " + e.getKey().getName().getString() + " x" + e.getValue() + "  (you have " + have + ")")
                    .formatted(enough ? Formatting.GREEN : Formatting.YELLOW), false);
        }
        if (rows.size() > 14) {
            p.sendMessage(Text.literal("  ... and " + (rows.size() - 14) + " more kinds").formatted(Formatting.GRAY), false);
        }
    }

    // ------------------------------------------------------------------ preview

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.printer || !Config.prPreview || schem == null || mc.world == null || mc.player == null) return;
        List<BlockPos> miss = prevMissing, wrong = prevWrong;
        if (miss.isEmpty() && wrong.isEmpty()) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();
        int missRgb = EntityEsp.COLORS[Math.max(0, Math.min(EntityEsp.COLORS.length - 1, Config.prMissColor))];
        int wrongRgb = EntityEsp.COLORS[Math.max(0, Math.min(EntityEsp.COLORS.length - 1, Config.prWrongColor))];

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.prShape != 0 && Config.prFill > 0 && !miss.isEmpty()) {
            int a = (int) (255 * Config.prFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (BlockPos bp : miss) {
                EntityEsp.fill(bb, mv, new Box(bp).expand(-0.003).offset(-cam.x, -cam.y, -cam.z), (a << 24) | missRgb);
            }
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.prShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (BlockPos bp : miss) {
                EntityEsp.lines(lb, mv, new Box(bp).expand(0.002).offset(-cam.x, -cam.y, -cam.z), 0xFF000000 | missRgb);
            }
            for (BlockPos bp : wrong) {
                EntityEsp.lines(lb, mv, new Box(bp).expand(0.004).offset(-cam.x, -cam.y, -cam.z), 0xFF000000 | wrongRgb);
            }
            BufferRenderer.drawWithGlobalProgram(lb.end());
        } else if (!wrong.isEmpty()) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (BlockPos bp : wrong) {
                EntityEsp.lines(lb, mv, new Box(bp).expand(0.004).offset(-cam.x, -cam.y, -cam.z), 0xFF000000 | wrongRgb);
            }
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
