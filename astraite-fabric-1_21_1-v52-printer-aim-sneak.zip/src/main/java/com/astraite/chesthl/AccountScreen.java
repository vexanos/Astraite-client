package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Account manager (cracked + premium accounts), opened from the click GUI. */
public class AccountScreen extends Screen {
    private static final int PER_PAGE = 3;
    private static final int PURPLE = 0xFFE04040;

    private final Screen parent;
    private int left, panelTop, cy;
    private int accountPage = 0;
    private String nameValue = "";
    private int seenVersion = AccountManager.version;

    public AccountScreen(Screen parent) {
        super(Text.literal("Accounts"));
        this.parent = parent;
    }

    private int totalPages() {
        return Math.max(1, (AccountManager.accounts.size() + PER_PAGE - 1) / PER_PAGE);
    }

    @Override
    protected void init() {
        left = width / 2 - 156;
        panelTop = Math.max(2, height / 2 - 92);
        cy = panelTop + 20;

        boolean launcherActive = AccountManager.active.isEmpty();
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Launcher account").formatted(launcherActive ? Formatting.GREEN : Formatting.WHITE)
                        .append(Text.literal(" [Official]").formatted(Formatting.GRAY)), b -> {
                    AccountManager.useOfficial(client);
                    clearAndInit();
                }).dimensions(left, cy + 14, 312, 18).build());

        if (accountPage >= totalPages()) accountPage = totalPages() - 1;
        List<AccountManager.Account> list = AccountManager.accounts;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = accountPage * PER_PAGE + i;
            if (idx >= list.size()) break;
            final AccountManager.Account a = list.get(idx);
            boolean isActive = a.key().equals(AccountManager.active);
            int y = cy + 34 + i * 20;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(a.name).formatted(isActive ? Formatting.GREEN : Formatting.WHITE)
                            .append(Text.literal(a.isPremium() ? " [Premium]" : " [Cracked]").formatted(Formatting.GRAY)), b -> {
                        AccountManager.switchTo(client, a);
                        clearAndInit();
                    }).dimensions(left, y, 240, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Remove").formatted(Formatting.RED), b -> {
                AccountManager.remove(client, a);
                clearAndInit();
            }).dimensions(left + 244, y, 68, 18).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (accountPage > 0) accountPage--;
            clearAndInit();
        }).dimensions(left, cy + 96, 40, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(left + 106, cy + 96, 100, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (accountPage < totalPages() - 1) accountPage++;
            clearAndInit();
        }).dimensions(left + 272, cy + 96, 40, 18).build());

        TextFieldWidget field = new TextFieldWidget(textRenderer, left, cy + 118, 150, 18, Text.literal("Cracked username"));
        field.setMaxLength(16);
        field.setText(nameValue);
        field.setChangedListener(s -> nameValue = s);
        addDrawableChild(field);

        addDrawableChild(ButtonWidget.builder(Text.literal("Add cracked"), b -> {
            String n = nameValue.trim();
            if (!AccountManager.validName(n)) {
                AccountManager.status = "Naam 3 se 16 letters/numbers/_ ka hona chahiye";
                AccountManager.version++;
                return;
            }
            nameValue = "";
            AccountManager.addCracked(client, n);
            clearAndInit();
        }).dimensions(left + 154, cy + 118, 78, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Add premium"), b -> {
            AccountManager.beginPremiumLogin(client);
            clearAndInit();
        }).dimensions(left + 236, cy + 118, 76, 18).build());
    }

    @Override
    public void tick() {
        if (seenVersion != AccountManager.version) {
            seenVersion = AccountManager.version;
            clearAndInit();
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x80000000);
        ctx.fill(left - 10, panelTop, left + 322, cy + 166, 0xF0101018);
        ctx.fill(left - 10, panelTop, left + 322, panelTop + 14, PURPLE);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Accounts", width / 2, panelTop + 3, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "Current: " + client.getSession().getUsername(), left, cy + 3, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, (accountPage + 1) + "/" + totalPages(), left + 46, cy + 101, 0xFFAAAAAA);
        ctx.drawTextWithShadow(textRenderer, AccountManager.status, left, cy + 142, 0xFFFFFFFF);
        if (!AccountManager.deviceCode.isEmpty()) {
            String url = AccountManager.deviceUrl.replace("https://", "");
            ctx.drawTextWithShadow(textRenderer, "Link: " + url + "   Code: " + AccountManager.deviceCode,
                    left, cy + 154, 0xFFFFD700);
        }
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
