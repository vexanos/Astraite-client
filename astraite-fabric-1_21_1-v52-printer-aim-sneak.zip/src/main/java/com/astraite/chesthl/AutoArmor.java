package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Equips the best armor from the inventory / hotbar. Fully customisable: material priority, enchant aware
 * (Protection, optional Blast Protection bonus), avoids Curse of Binding, keeps the elytra, minimum durability.
 */
public final class AutoArmor {
    private static int cooldown = 0;
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final int[] SCREEN_SLOT = {5, 6, 7, 8}; // PlayerScreenHandler armor slots

    public static void tick(MinecraftClient mc) {
        if (!Config.autoArmor) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || p.isDead()) return;
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (Config.armorInvOnly && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;

        for (int i = 0; i < 4; i++) {
            ItemStack cur = p.getEquippedStack(SLOTS[i]);
            if (SLOTS[i] == EquipmentSlot.CHEST && cur.isOf(Items.ELYTRA) && Config.armorKeepElytra) continue;
            // never take off a cursed piece, it can not be removed anyway
            if (!cur.isEmpty() && hasEnchant(cur, Enchantments.BINDING_CURSE) && !p.isCreative()) continue;

            double best = score(cur, SLOTS[i]);
            int bestInv = -1;
            for (int j = 0; j < 36; j++) {
                double sc = score(p.getInventory().getStack(j), SLOTS[i]);
                if (sc > best + 0.05) { // small margin so two equal pieces are not swapped back and forth
                    best = sc;
                    bestInv = j;
                }
            }
            if (bestInv < 0) continue;

            int from = bestInv < 9 ? 36 + bestInv : bestInv;
            int sync = p.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(sync, from, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(sync, SCREEN_SLOT[i], 0, SlotActionType.PICKUP, p);
            if (!p.playerScreenHandler.getCursorStack().isEmpty()) {
                mc.interactionManager.clickSlot(sync, from, 0, SlotActionType.PICKUP, p); // put old piece back
            }
            cooldown = Math.max(0, Config.armorDelay);
            return;
        }
    }

    static boolean hasEnchant(ItemStack s, RegistryKey<Enchantment> key) {
        return level(s, key) > 0;
    }

    static int level(ItemStack s, RegistryKey<Enchantment> key) {
        for (var e : s.getEnchantments().getEnchantmentEntries()) {
            if (e.getKey().matchesKey(key)) return e.getIntValue();
        }
        return 0;
    }

    private static double score(ItemStack s, EquipmentSlot slot) {
        if (s.isEmpty() || !(s.getItem() instanceof ArmorItem a)) return 0;
        if (a.getType().getEquipmentSlot() != slot) return 0;
        if (Config.armorAvoidCurse && hasEnchant(s, Enchantments.BINDING_CURSE)) return 0;

        double durability = s.isDamageable() ? 1.0 - (double) s.getDamage() / s.getMaxDamage() : 1.0;
        if (s.isDamageable() && (durability * 100.0 < Config.armorMinDur || s.getMaxDamage() - s.getDamage() < 10)) {
            return 0.01; // about to break: only better than nothing
        }

        double sc = a.getProtection() + a.getToughness() * 0.5 + durability * 0.5;
        sc += level(s, Enchantments.PROTECTION) * 0.75;
        if (Config.armorBlast) sc += level(s, Enchantments.BLAST_PROTECTION) * 1.0;

        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (Config.armorPriority == 1 && id.startsWith("netherite_")) sc += 6;
        if (Config.armorPriority == 2 && id.startsWith("diamond_")) sc += 6;
        return sc;
    }
}
