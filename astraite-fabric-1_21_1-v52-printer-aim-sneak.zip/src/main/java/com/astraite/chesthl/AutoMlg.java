package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Auto MLG: when you fall far enough to take damage, uses an item from the hotbar just before you hit the ground.
 * Priority: water bucket (picked back up after landing) > cobweb > slime block > hay bale.
 * Solid blocks (slime / hay) can only be placed while you are still at least a block above the floor,
 * so for very fast falls the water bucket is the reliable one.
 */
public final class AutoMlg {
    public static String status = "";
    private static int cd = 0;
    private static int prevSlot = -1;
    private static BlockPos water = null;   // the water source we placed (so we can pick it up again)
    private static int waterTicks = 0;

    private static final Item[] ITEMS = {Items.WATER_BUCKET, Items.COBWEB, Items.SLIME_BLOCK, Items.HAY_BLOCK};

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.mlg) {
            status = "";
            water = null;
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) {
            water = null;
            return;
        }
        if (mc.currentScreen != null || p.isDead() || p.isSpectator() || p.isCreative()) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (water != null) {
            pickup(mc, p, w);
            return;
        }

        if (p.isOnGround() || p.isFallFlying() || p.getAbilities().flying || p.isTouchingWater()
                || p.isClimbing() || p.hasVehicle() || p.hasStatusEffect(StatusEffects.SLOW_FALLING)) {
            if (p.isOnGround()) status = "";
            return;
        }
        if (p.fallDistance <= 3.0) return;

        // what is below us (within reach)?
        Vec3d eye = p.getEyePos();
        double range = Config.mlgRange10 / 10.0;
        BlockHitResult hit = w.raycast(new RaycastContext(eye, eye.add(0, -range, 0),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.ANY, p));
        if (hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos ground = hit.getBlockPos();
        if (!w.getBlockState(ground).getFluidState().isEmpty()) return; // water / lava below: nothing to do

        int slot = -1;
        Item item = null;
        for (Item it : ITEMS) {
            for (int i = 0; i < 9 && slot < 0; i++) {
                if (p.getInventory().getStack(i).isOf(it)) {
                    slot = i;
                    item = it;
                }
            }
            if (slot >= 0) break;
        }
        if (slot < 0) {
            status = "No MLG item in hotbar";
            return;
        }

        BlockPos spot = ground.offset(hit.getSide());
        if (item == Items.WATER_BUCKET) {
            select(p, slot);
            aimAndUse(p, eye, hit.getPos(), () -> mc.interactionManager.interactItem(p, Hand.MAIN_HAND));
            p.swingHand(Hand.MAIN_HAND);
            water = spot;
            waterTicks = 0;
            status = "Water MLG";
        } else {
            // solid blocks must not overlap us; cobweb has no collision so it is always fine
            if (item != Items.COBWEB && p.getBoundingBox().intersects(new Box(spot))) return;
            select(p, slot);
            BlockHitResult place = new BlockHitResult(hit.getPos(), hit.getSide(), ground, false);
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, place);
            p.swingHand(Hand.MAIN_HAND);
            status = "Block MLG";
        }
        restore(p);
        cd = 2;
    }

    /** After landing: right-click the water we placed with an empty bucket to get it back. */
    private static void pickup(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w) {
        waterTicks++;
        if (waterTicks > 80 || !Config.mlgPickup) {
            water = null;
            return;
        }
        FluidState fs = w.getFluidState(water);
        if (!fs.isIn(FluidTags.WATER) || !fs.isStill()) {
            // not (yet) there: wait while falling, give up once we are on the ground
            if (p.isOnGround() && waterTicks > 4) water = null;
            return;
        }
        if (!p.isOnGround() && !p.isTouchingWater()) return; // still falling
        Vec3d eye = p.getEyePos();
        Vec3d c = Vec3d.ofCenter(water);
        if (eye.squaredDistanceTo(c) > 4.5 * 4.5) {
            water = null;
            return;
        }
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).isOf(Items.BUCKET)) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            status = "No empty bucket to pick the water up";
            water = null;
            return;
        }
        select(p, slot);
        aimAndUse(p, eye, c, () -> mc.interactionManager.interactItem(p, Hand.MAIN_HAND));
        p.swingHand(Hand.MAIN_HAND);
        restore(p);
        status = "Picking up water";
        cd = 3;
    }

    /**
     * Item use is raycast from the player's rotation on the server, so the rotation is sent first and restored
     * right after. The client's own camera never moves.
     */
    private static void aimAndUse(ClientPlayerEntity p, Vec3d eye, Vec3d to, Runnable use) {
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, h)), -90f, 90f);
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround()));
        use.run();
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(p.getYaw(), p.getPitch(), p.isOnGround()));
    }

    private static void select(ClientPlayerEntity p, int slot) {
        if (p.getInventory().selectedSlot != slot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
        }
    }

    private static void restore(ClientPlayerEntity p) {
        if (Config.mlgSwitchBack && prevSlot >= 0) p.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }
}
