package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Refills hotbar stacks (and the offhand) from the main inventory when they run low or empty. */
public final class AutoReplenish {
    private static int cooldown = 0;
    // what each hotbar slot (0-8) and the offhand (9) held on the previous tick
    private static final Item[] lastItem = new Item[10];

    private AutoReplenish() {
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.world == null) return;
        if (!Config.replenish) {
            java.util.Arrays.fill(lastItem, null);
            return;
        }
        if (mc.currentScreen != null || !p.playerScreenHandler.getCursorStack().isEmpty()) {
            snapshot(p);
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            snapshot(p);
            return;
        }

        int sync = p.playerScreenHandler.syncId;
        int selected = p.getInventory().selectedSlot;

        // hotbar
        for (int i = 0; i < 9; i++) {
            ItemStack cur = p.getInventory().getStack(i);
            if (cur.isEmpty()) {
                // an emptied slot is only refilled when it was the slot in use
                if (i != selected || lastItem[i] == null) continue;
                int src = findSource(p, lastItem[i], null);
                if (src < 0) continue;
                mc.interactionManager.clickSlot(sync, src, i, SlotActionType.SWAP, p);
                cooldown = Config.repDelay;
                snapshot(p);
                return;
            }
            if (Config.repThreshold <= 0 || cur.getMaxCount() <= 1 || cur.getCount() > Config.repThreshold) continue;
            if (!Config.repTools && cur.isDamageable()) continue;
            int src = findSource(p, cur.getItem(), cur);
            if (src < 0) continue;
            mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p);
            mc.interactionManager.clickSlot(sync, 36 + i, 0, SlotActionType.PICKUP, p);
            if (!p.playerScreenHandler.getCursorStack().isEmpty()) {
                mc.interactionManager.clickSlot(sync, src, 0, SlotActionType.PICKUP, p); // put the rest back
            }
            cooldown = Config.repDelay;
            snapshot(p);
            return;
        }

        // offhand
        if (Config.repOffhand) {
            ItemStack off = p.getOffHandStack();
            if (off.isEmpty() && lastItem[9] != null) {
                int src = findSource(p, lastItem[9], null);
                if (src >= 0) {
                    mc.interactionManager.clickSlot(sync, src, 40, SlotActionType.SWAP, p); // 40 = offhand
                    cooldown = Config.repDelay;
                }
            }
        }
        snapshot(p);
    }

    private static void snapshot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            lastItem[i] = s.isEmpty() ? null : s.getItem();
        }
        ItemStack off = p.getOffHandStack();
        lastItem[9] = off.isEmpty() ? null : off.getItem();
    }

    /**
     * Finds a main-inventory slot (screen slot 9-35) holding the same item.
     * If 'match' is given, the stack must also be identical (same enchants / name ...).
     */
    private static int findSource(ClientPlayerEntity p, Item item, ItemStack match) {
        for (int j = 9; j < 36; j++) {
            ItemStack s = p.getInventory().getStack(j);
            if (s.isEmpty() || !s.isOf(item)) continue;
            if (match != null && !ItemStack.areItemsAndComponentsEqual(s, match)) continue;
            if (!Config.repTools && s.isDamageable()) continue;
            return j;
        }
        return -1;
    }
}
