package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** While a chest / barrel / shulker is open, moves its items into your inventory one by one. */
public final class AutoSteal {
    private static int cooldown = 0;
    private static int lastSync = -1;
    private static boolean manual = false; // set by the "Steal" button in the container screen

    private AutoSteal() {
    }

    /** True for the screens the Steal button belongs on (chest, barrel, shulker box...). */
    public static boolean isContainer(Screen s) {
        return s instanceof HandledScreen<?> hs
                && (hs.getScreenHandler() instanceof GenericContainerScreenHandler
                || hs.getScreenHandler() instanceof ShulkerBoxScreenHandler);
    }

    /** Starts stealing from the open container once, even when the module is off. */
    public static void stealNow() {
        manual = true;
        cooldown = 0;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!(mc.currentScreen instanceof HandledScreen<?> screen)) {
            lastSync = -1;
            manual = false;
            return;
        }
        if (!Config.autoSteal && !manual) return;
        ScreenHandler h = screen.getScreenHandler();
        int size;
        if (h instanceof GenericContainerScreenHandler g) size = g.getRows() * 9;
        else if (h instanceof ShulkerBoxScreenHandler) size = 27;
        else return;

        if (h.syncId != lastSync) { // just opened
            lastSync = h.syncId;
            cooldown = Config.stealDelay;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }

        boolean anyLeft = false;
        for (int i = 0; i < size; i++) {
            if (h.getSlot(i).getStack().isEmpty()) continue;
            anyLeft = true;
            if (p.getInventory().getEmptySlot() == -1) { // inventory full: nothing more can move
                manual = false;
                if (Config.stealClose) p.closeHandledScreen();
                return;
            }
            mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
            cooldown = Config.stealDelay;
            return;
        }
        if (!anyLeft) {
            manual = false;
            if (Config.stealClose) p.closeHandledScreen();
        }
    }
}
