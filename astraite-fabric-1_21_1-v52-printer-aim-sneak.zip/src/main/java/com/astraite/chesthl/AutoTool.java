package com.astraite.chesthl;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While you hold the attack key on a block, switches to the fastest hotbar tool for it (and back afterwards). */
public final class AutoTool {
    private static int prevSlot = -1;

    private AutoTool() {
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.autoTool || p == null || mc.world == null || mc.currentScreen != null) {
            prevSlot = -1;
            return;
        }

        boolean mining = mc.options.attackKey.isPressed()
                && mc.crosshairTarget instanceof BlockHitResult hit
                && hit.getType() == HitResult.Type.BLOCK
                && !p.isUsingItem();

        if (!mining) {
            if (prevSlot >= 0) {
                if (Config.toolSwitchBack) p.getInventory().selectedSlot = prevSlot;
                prevSlot = -1;
            }
            return;
        }

        BlockHitResult hit = (BlockHitResult) mc.crosshairTarget;
        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (state.isAir() || state.getHardness(mc.world, hit.getBlockPos()) < 0) return;

        int cur = p.getInventory().selectedSlot;
        int best = cur;
        float bestSpeed = usable(p.getInventory().getStack(cur)) ? p.getInventory().getStack(cur).getMiningSpeedMultiplier(state) : 1f;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!usable(st)) continue;
            float sp = st.getMiningSpeedMultiplier(state);
            if (sp > bestSpeed + 0.01f) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best != cur) {
            if (prevSlot < 0) prevSlot = cur;
            p.getInventory().selectedSlot = best;
        }
    }

    /** Skip tools that are almost broken. */
    private static boolean usable(ItemStack st) {
        return !st.isDamageable() || st.getMaxDamage() - st.getDamage() > Config.toolMinDur;
    }
}
