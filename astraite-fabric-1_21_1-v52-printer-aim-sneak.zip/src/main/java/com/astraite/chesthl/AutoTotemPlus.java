package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Auto Totem+: keeps a totem in the offhand, refills it the same tick after a pop,
 * and when your health is low also switches your hand to a hotbar totem (a second one armed).
 */
public final class AutoTotemPlus {
    public static String status = "";
    private static int cooldown = 0;
    private static boolean hadOffhand = false;
    private static int pops = 0;
    private static int prevSlot = -1; // slot to go back to after the hotbar totem

    private AutoTotemPlus() {
    }

    private static int totemCount(ClientPlayerEntity p) {
        int n = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) ? p.getOffHandStack().getCount() : 0;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) n += p.getInventory().getStack(i).getCount();
        }
        return n;
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.totemPlus) {
            status = "";
            hadOffhand = false;
            prevSlot = -1;
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.world == null || p.isDead()) {
            hadOffhand = false;
            return;
        }

        boolean off = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        boolean popped = hadOffhand && !off; // had one last tick, gone now
        hadOffhand = off;
        if (popped) {
            pops++;
            cooldown = 0; // refill right away
        }
        if (cooldown > 0) cooldown--;

        boolean containerOpen = mc.currentScreen instanceof HandledScreen<?> && !(mc.currentScreen instanceof InventoryScreen);

        // 1) offhand totem
        if (!off && cooldown == 0 && !containerOpen) {
            // PlayerScreenHandler slots: 9-35 main inventory, 36-44 hotbar, 45 offhand
            int slot = -1;
            for (int i = 9; i < 36 && slot < 0; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) slot = i;
            }
            for (int i = 0; i < 9 && slot < 0; i++) {
                if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) slot = 36 + i;
            }
            if (slot >= 0) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                cooldown = Math.max(0, Config.totemPlusDelay);
            }
        }

        // 2) low health: hold a hotbar totem as well
        if (Config.totemPlusHotbar && mc.currentScreen == null) {
            float hp = p.getHealth() + p.getAbsorptionAmount();
            int cur = p.getInventory().selectedSlot;
            if (hp <= Config.totemPlusHealth) {
                if (!p.getMainHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                    int hb = -1;
                    for (int i = 0; i < 9 && hb < 0; i++) {
                        if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) hb = i;
                    }
                    if (hb >= 0) {
                        if (prevSlot < 0) prevSlot = cur;
                        p.getInventory().selectedSlot = hb;
                    }
                }
            } else if (prevSlot >= 0 && hp > Config.totemPlusHealth + 4) {
                // healthy again: go back, but only if we are still on the totem slot we picked
                if (p.getInventory().getStack(cur).isOf(Items.TOTEM_OF_UNDYING)) p.getInventory().selectedSlot = prevSlot;
                prevSlot = -1;
            }
        }

        int n = totemCount(p);
        status = n + " totems" + (pops > 0 ? ", " + pops + " pops" : "") + (n == 0 ? " !" : "");
    }
}
