package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Auto Trap: boxes the nearest enemy player in with blocks (feet sides, head sides, roof). */
public final class AutoTrap {
    public static String status = "";
    private static int cd = 0;

    private AutoTrap() {
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.trap) {
            status = "";
            return;
        }
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (cd > 0) {
            cd--;
            return;
        }
        LivingEntity target = PlaceUtil.target(w, p, Config.trapTargetRange, false);
        if (target == null) {
            status = "No target";
            return;
        }
        int slot = Placer.findSlot(p, w, Config.trapBlock == 0 ? 0 : 1, true, false);
        if (slot < 0) {
            status = Config.trapBlock == 0 ? "No obsidian in hotbar" : "No blocks in hotbar";
            return;
        }

        BlockPos feet = target.getBlockPos();
        Direction[] sides = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        List<BlockPos> todo = new ArrayList<>();
        if (Config.trapUnder) todo.add(feet.down());
        if (Config.trapFeet) {
            for (Direction d : sides) todo.add(feet.offset(d));
        }
        if (Config.trapHead) {
            for (Direction d : sides) todo.add(feet.up().offset(d));
        }
        if (Config.trapTop) todo.add(feet.up(2));

        Vec3d eye = p.getEyePos();
        double r = Config.trapRange;
        int placed = 0, pending = 0;
        int prev = p.getInventory().selectedSlot;
        boolean switched = false;
        for (BlockPos pos : todo) {
            if (!Placer.canPlace(w, pos)) continue;
            if (eye.squaredDistanceTo(Vec3d.ofCenter(pos)) > r * r) continue;
            pending++;
            if (placed >= Config.trapPerTick) continue;
            if (!switched) {
                p.getInventory().selectedSlot = slot;
                switched = true;
            }
            if (Placer.place(mc, p, w, pos, Config.trapRotate, Config.trapAir)) placed++;
        }
        if (switched) p.getInventory().selectedSlot = prev;
        String name = target.getName().getString();
        if (placed > 0) {
            if (Config.trapRotate) Placer.resync(p);
            cd = Config.trapDelay;
            status = "Trapping " + name;
        } else {
            status = pending == 0 ? "Trapped " + name : "Out of range / no spot";
        }
    }
}
