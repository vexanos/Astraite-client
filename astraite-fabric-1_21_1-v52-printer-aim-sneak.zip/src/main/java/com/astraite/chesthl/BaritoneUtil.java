package com.astraite.chesthl;

import net.minecraft.util.math.BlockPos;

import java.lang.reflect.Method;

/** Pauses / resumes Baritone through reflection, so the mod works with or without it installed. */
public final class BaritoneUtil {
    private static boolean paused = false;

    private BaritoneUtil() {
    }

    public static void pause() {
        if (paused) return;
        if (run("pause")) paused = true;
    }

    public static void resume() {
        if (!paused) return;
        run("resume");
        paused = false;
    }

    /** Walks to within 'range' blocks of pos (Baritone GoalNear). False if Baritone is not installed. */
    public static boolean goNear(BlockPos pos, int range) {
        try {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object baritone = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
            Class<?> ib = Class.forName("baritone.api.IBaritone");
            Object process = ib.getMethod("getCustomGoalProcess").invoke(baritone);
            Class<?> goalCls = Class.forName("baritone.api.pathing.goals.GoalNear");
            Object goal = goalCls.getConstructor(BlockPos.class, int.class).newInstance(pos, range);
            Class<?> goalIface = Class.forName("baritone.api.pathing.goals.Goal");
            Class<?> pi = Class.forName("baritone.api.process.ICustomGoalProcess");
            pi.getMethod("setGoalAndPath", goalIface).invoke(process, goal);
            return true;
        } catch (Throwable t) {
            return false; // Baritone not installed (or a different API)
        }
    }

    private static boolean run(String cmd) {
        try {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object baritone = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
            Object cm = baritone.getClass().getMethod("getCommandManager").invoke(baritone);
            Method exec = cm.getClass().getMethod("execute", String.class);
            exec.invoke(cm, cmd);
            return true;
        } catch (Throwable t) {
            return false; // Baritone not installed
        }
    }
}
