package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Highlights the chosen blocks (through walls) inside the loaded chunks around you. */
public final class BlockEsp {
    private static final int MAX_HITS = 6000;

    record Hit(BlockPos pos, int rgb) {
    }

    private static volatile List<Hit> hits = List.of();
    private static final AtomicBoolean busy = new AtomicBoolean();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "astraite-block-esp");
        t.setDaemon(true);
        return t;
    });
    private static int timer = 0;
    private static boolean force = false;

    private BlockEsp() {
    }

    /** Blocks currently highlighted (empty while Block ESP is off). */
    static List<Hit> hits() {
        return hits;
    }

    /** Called after the block list changed: scan again right away. */
    public static void rescan() {
        force = true;
    }

    private static Set<Block> selection() {
        Set<Block> s = new HashSet<>();
        for (String id : Config.blockEspBlocks) {
            Identifier ident = Identifier.tryParse(id);
            if (ident == null) continue;
            Registries.BLOCK.getOrEmpty(ident).ifPresent(b -> {
                if (!BlockTypes.isStorage(b)) s.add(b);
            });
        }
        return s;
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.blockEspEnabled || mc.world == null || mc.player == null) {
            if (!hits.isEmpty()) hits = List.of();
            return;
        }
        if (!force && ++timer < 10) return;
        timer = 0;
        force = false;
        if (!busy.compareAndSet(false, true)) return;

        ClientWorld world = mc.world;
        BlockPos center = mc.player.getBlockPos();
        int range = Config.blockEspRange;
        Set<Block> sel = selection();
        boolean byBlock = Config.blockEspByBlock;
        int single = EntityEsp.COLORS[MathHelper.clamp(Config.blockEspColor, 0, EntityEsp.COLORS.length - 1)];
        if (sel.isEmpty()) {
            hits = List.of();
            busy.set(false);
            return;
        }
        POOL.execute(() -> {
            try {
                List<Hit> r = scan(world, center, range, sel, byBlock, single);
                if (MinecraftClient.getInstance().world == world) hits = r;
            } catch (Throwable ignored) {
            } finally {
                busy.set(false);
            }
        });
    }

    private static int blockColor(Block b) {
        int h = Registries.BLOCK.getId(b).toString().hashCode() & 0x7FFFFFFF;
        return MathHelper.hsvToRgb((h % 360) / 360f, 0.8f, 1f) & 0xFFFFFF;
    }

    private static List<Hit> scan(ClientWorld world, BlockPos center, int range, Set<Block> sel, boolean byBlock, int single) {
        List<Hit> out = new ArrayList<>();
        long r2 = (long) range * range;
        int cr = (range >> 4) + 1;
        int pcx = center.getX() >> 4, pcz = center.getZ() >> 4;
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                WorldChunk ch = world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                if (ch == null) continue;
                ChunkSection[] secs = ch.getSectionArray();
                for (int i = 0; i < secs.length; i++) {
                    ChunkSection s = secs[i];
                    if (s == null) continue;
                    int baseY = ch.getBottomY() + (i << 4);
                    if (baseY > center.getY() + range || baseY + 15 < center.getY() - range) continue;
                    if (!s.hasAny(st -> sel.contains(st.getBlock()))) continue;
                    for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                            for (int x = 0; x < 16; x++) {
                                BlockState st = s.getBlockState(x, y, z);
                                Block b = st.getBlock();
                                if (!sel.contains(b)) continue;
                                int wx = (ch.getPos().x << 4) + x, wy = baseY + y, wz = (ch.getPos().z << 4) + z;
                                long ddx = wx - center.getX(), ddy = wy - center.getY(), ddz = wz - center.getZ();
                                if (ddx * ddx + ddy * ddy + ddz * ddz > r2) continue;
                                out.add(new Hit(new BlockPos(wx, wy, wz), byBlock ? blockColor(b) : single));
                                if (out.size() >= MAX_HITS) return out;
                            }
                        }
                    }
                }
            }
        }
        return out;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.blockEspEnabled || mc.world == null || mc.player == null) return;
        List<Hit> list = hits;
        if (list.isEmpty()) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();
        double maxD = Config.blockEspRange + 8.0;
        double maxD2 = maxD * maxD;

        List<Box> boxes = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        for (Hit h : list) {
            BlockPos p = h.pos();
            double cx = p.getX() + 0.5 - cam.x, cy = p.getY() + 0.5 - cam.y, cz = p.getZ() + 0.5 - cam.z;
            if (cx * cx + cy * cy + cz * cz > maxD2) continue;
            boxes.add(new Box(p.getX() - cam.x, p.getY() - cam.y, p.getZ() - cam.z,
                    p.getX() + 1 - cam.x, p.getY() + 1 - cam.y, p.getZ() + 1 - cam.z));
            cols.add(h.rgb());
        }
        if (boxes.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // visible through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.blockEspShape != 0 && Config.blockEspFill > 0) {
            int a = (int) (255 * Config.blockEspFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.fill(bb, mv, boxes.get(i), (a << 24) | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.blockEspShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.lines(lb, mv, boxes.get(i), 0xFF000000 | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
