package com.astraite.chesthl;

import net.minecraft.block.AbstractChestBlock;
import net.minecraft.block.AbstractFurnaceBlock;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BrewingStandBlock;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.ChiseledBookshelfBlock;
import net.minecraft.block.CrafterBlock;
import net.minecraft.block.DecoratedPotBlock;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.JukeboxBlock;
import net.minecraft.block.LecternBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Every block the Block ESP can highlight: all blocks except ones that store items. */
public final class BlockTypes {
    private static List<Block> all = null;

    private BlockTypes() {
    }

    public static String id(Block b) {
        return Registries.BLOCK.getId(b).toString();
    }

    /** Chests, ender chests, barrels, shulker boxes, hoppers, furnaces... anything holding items. */
    public static boolean isStorage(Block b) {
        if (b instanceof AbstractChestBlock<?> || b instanceof EnderChestBlock || b instanceof BarrelBlock
                || b instanceof ShulkerBoxBlock || b instanceof HopperBlock || b instanceof DispenserBlock
                || b instanceof AbstractFurnaceBlock || b instanceof BrewingStandBlock
                || b instanceof ChiseledBookshelfBlock || b instanceof DecoratedPotBlock
                || b instanceof CrafterBlock || b instanceof JukeboxBlock || b instanceof LecternBlock
                || b instanceof CampfireBlock) {
            return true;
        }
        if (b instanceof BlockEntityProvider p) { // catches anything else with an inventory (also modded blocks)
            try {
                BlockEntity be = p.createBlockEntity(BlockPos.ORIGIN, b.getDefaultState());
                if (be instanceof Inventory) return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    public static synchronized List<Block> all() {
        if (all != null) return all;
        List<Block> l = new ArrayList<>();
        for (Block b : Registries.BLOCK) {
            if (b.getDefaultState().isAir()) continue;
            if (isStorage(b)) continue;
            l.add(b);
        }
        l.sort(Comparator.comparing(b -> b.getName().getString().toLowerCase()));
        all = l;
        return l;
    }
}
