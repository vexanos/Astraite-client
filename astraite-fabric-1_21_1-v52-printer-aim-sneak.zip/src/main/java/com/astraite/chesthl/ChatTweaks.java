package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Chat Tweaks: timestamps, own-name highlight (+ ping sound) and a repeat-message filter. Used by ChatHudMixin. */
public final class ChatTweaks {
    /** True while the mixin re-adds a message we changed (so it is not processed twice). */
    public static boolean busy = false;
    private static final Map<String, Long> seen = new HashMap<>();

    private ChatTweaks() {
    }

    /** The same text was already shown within the last few seconds. */
    public static boolean isSpam(Text msg) {
        if (!Config.chatSpam) return false;
        String s = msg.getString();
        if (s.isBlank()) return false;
        long now = System.currentTimeMillis();
        long window = Config.chatSpamSecs * 1000L;
        seen.values().removeIf(t -> now - t > window);
        if (seen.size() > 200) seen.clear();
        Long last = seen.put(s, now); // keeps refreshing while it keeps repeating
        return last != null;
    }

    public static Text modify(Text msg) {
        Text body = Config.chatName ? highlight(msg) : msg;
        if (!Config.chatTime) return body;
        String pattern = switch (Config.chatTimeFmt) {
            case 1 -> "hh:mm a";
            case 2 -> "HH:mm:ss";
            default -> "HH:mm";
        };
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH));
        MutableText out = Text.literal("[" + time + "] ").formatted(Formatting.GRAY);
        out.append(body);
        return out;
    }

    private static Text highlight(Text msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return msg;
        String ln = mc.player.getName().getString().toLowerCase(Locale.ROOT);
        if (ln.isEmpty()) return msg;
        String plain = msg.getString().toLowerCase(Locale.ROOT);
        if (!plain.contains(ln)) return msg;

        // our own chat line ("<name> hi" / "name: hi"): the sender tag is not a mention
        int skip = 0;
        if (plain.startsWith("<" + ln + ">")) skip = ln.length() + 2;
        else if (plain.startsWith(ln + ":")) skip = ln.length() + 1;
        if (plain.indexOf(ln, skip) < 0) return msg;

        final int skipUntil = skip;
        final int rgb = EntityEsp.COLORS[Math.max(0, Math.min(EntityEsp.COLORS.length - 1, Config.chatNameColor))];
        MutableText out = Text.empty();
        int[] off = {0};
        msg.visit((style, str) -> {
            String ls = str.toLowerCase(Locale.ROOT);
            int i = 0;
            while (i < str.length()) {
                int f = ls.length() == str.length() ? ls.indexOf(ln, i) : -1;
                while (f >= 0 && off[0] + f < skipUntil) f = ls.indexOf(ln, f + 1);
                if (f < 0) {
                    out.append(Text.literal(str.substring(i)).setStyle(style));
                    break;
                }
                if (f > i) out.append(Text.literal(str.substring(i, f)).setStyle(style));
                out.append(Text.literal(str.substring(f, f + ln.length())).setStyle(style.withColor(rgb).withBold(true)));
                i = f + ln.length();
            }
            off[0] += str.length();
            return Optional.empty();
        }, Style.EMPTY);

        if (Config.chatPing) {
            mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f));
        }
        return out;
    }
}
