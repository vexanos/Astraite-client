package com.astraite.chesthl;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ChestHighlightClient implements ClientModInitializer {
    public static KeyBinding openKey;
    public static boolean pendingOpen = false;


    @Override
    public void onInitializeClient() {
        Defaults.snapshot(); // real defaults, before the saved config overwrites them (used by the reset arrow)
        Config.load();
        AccountManager.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chesthl.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.chesthl"));

        // /chesthl opens the menu (useful on mobile where keybinds are awkward)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("chesthl").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("astraite").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("basefinder").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) pendingOpen = true;
            Binds.tick(client);
            AccountManager.tick(client);
            AutoArmor.tick(client);
            AutoTool.tick(client);
            AutoReplenish.tick(client);
            AutoEat.tick(client);
            KillAura.tick(client);
            CrystalAura.tick(client);
            AutoAnchor.tick(client);
            AutoMlg.tick(client);
            Surround.tick(client);
            AutoTrap.tick(client);
            Scaffold.tick(client);
            Printer.tick(client);
            AutoTotemPlus.tick(client);   // late on purpose: its hotbar-totem switch must win
            StorageEsp.tick(client);
            SusChunk.tick(client);
            NewChunks.tick(client);
            AutoSteal.tick(client);
            Fullbright.tick(client);
            Freelook.tick(client);
            EntityEsp.tick(client);
            BlockEsp.tick(client);
            PluginManager.tick(client);
            if (pendingOpen && client.player != null && client.currentScreen == null) {
                pendingOpen = false;
                client.setScreen(new ClickGui(null));
            }
        });

        WorldRenderEvents.LAST.register(Overlay::begin); // must stay first: clears + prepares the 2D overlay
        WorldRenderEvents.LAST.register(EntityEsp::render);
        WorldRenderEvents.LAST.register(BlockEsp::render);
        WorldRenderEvents.LAST.register(ItemEsp::render);
        WorldRenderEvents.LAST.register(StorageEsp::render);
        WorldRenderEvents.LAST.register(Printer::render);
        WorldRenderEvents.LAST.register(Copier::render);
        WorldRenderEvents.LAST.register(SusChunk::render);
        WorldRenderEvents.LAST.register(NewChunks::render);
        WorldRenderEvents.LAST.register(Tracers::collect);
        WorldRenderEvents.LAST.register(Nametags::collect);
        WorldRenderEvents.LAST.register(Trajectories::render); // after Overlay.begin (it adds labels)
        WorldRenderEvents.LAST.register(PluginManager::worldRender); // plugins draw labels / lines here

        // active-module list
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            Overlay.draw(ctx);
            InfoHud.render(ctx);
            ItemCounter.render(ctx);
            Hud.render(ctx);
            PluginManager.hud(ctx);
        });

        // "Steal" button in the top right of chests / barrels / shulker boxes
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (AutoSteal.isContainer(screen)) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Steal"),
                        b -> AutoSteal.stealNow()).dimensions(scaledWidth - 54, 4, 50, 18).build());
            }
        });

        // Button on the title screen so the menu (and account switch) is reachable outside a world
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Astraite"),
                        b -> client.setScreen(new ClickGui(screen))).dimensions(4, 4, 80, 20).build());
            }
        });

        // plugins (other mods with an "astraite" entrypoint) - last, so everything above is ready for them
        PluginManager.load();
    }
}
