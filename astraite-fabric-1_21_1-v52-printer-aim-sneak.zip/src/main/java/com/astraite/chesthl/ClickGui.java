package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Sidebar click GUI: categories on the left, search bar on top, two-column grid of module cards.
 * Left click a card = toggle, click the three dots (or right click) = settings popup.
 */
public class ClickGui extends Screen {
    static final int ACCENT = 0xFFE04040;
    private static final int ACCENT_DIM = 0xFF3A1519;
    private static final int TEXT = 0xFFE8E8EC;
    private static final int TEXT_DIM = 0xFF9A9AA2;

    private static final int SB_W = 88, CAT_H = 22, CARD_H = 20, GAP = 5;
    private static final int P_ROW = 20, P_HEAD = 22;

    private final Screen parent;
    private final List<List<Module>> byCat = new ArrayList<>();
    private final List<Module> allModules;

    private int selCat = 0;
    private String query = "";
    private double gridScroll = 0;

    private Module open = null;
    private boolean listening = false;
    private Module.Action bindRow;
    private List<Module.Setting> rows = new ArrayList<>();
    private Module.Int dragging = null;
    private int dragX, dragW;

    private long flashUntil = 0;
    private String flashText = "";
    private boolean armAll = false;
    private long armTime = 0;

    // window layout
    private int wx, wy, ww, wh, mainX, mainW, searchY, headY, gridY, gridH, cardW;
    // popup layout
    private int px, py, pw, ph, visRows, maxScroll;
    private double scroll = 0;

    public ClickGui(Screen parent) {
        super(Text.literal("Astraite"));
        this.parent = parent;
        allModules = Modules.all();
        for (Module.Category c : Module.Category.values()) {
            List<Module> l = new ArrayList<>();
            for (Module m : allModules) if (m.category == c) l.add(m);
            byCat.add(l);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (client != null && client.world == null) super.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(0, 0, width, height, 0x70000000);
    }

    // ---------------- layout ----------------
    private void layout() {
        ww = Math.min(width - 16, 470);
        wh = Math.min(height - 16, 290);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2;
        mainX = wx + SB_W + 8;
        mainW = ww - SB_W - 16;
        searchY = wy + 8;
        headY = searchY + 20 + 6;
        gridY = headY + 18 + 6;
        gridH = wy + wh - 8 - gridY;
        cardW = (mainW - GAP) / 2;
    }

    private List<Module> shownModules() {
        if (query.isEmpty()) return byCat.get(selCat);
        String q = query.toLowerCase(Locale.ROOT);
        List<Module> l = new ArrayList<>();
        for (Module m : allModules) if (m.name.toLowerCase(Locale.ROOT).contains(q)) l.add(m);
        return l;
    }

    private double maxGridScroll() {
        int n = shownModules().size();
        int rowsN = (n + 1) / 2;
        int content = rowsN * (CARD_H + GAP) - GAP;
        return Math.max(0, content - gridH);
    }

    private int cardX(int i) {
        return mainX + (i % 2) * (cardW + GAP);
    }

    private int cardY(int i) {
        return gridY + (i / 2) * (CARD_H + GAP) - (int) gridScroll;
    }

    private int catY(int i) {
        return wy + 36 + i * CAT_H;
    }

    private int accountsY() {
        return catY(byCat.size()) + 8;
    }

    private void buildRows(Module m) {
        rows = new ArrayList<>();
        scroll = 0;
        listening = false;
        if (m.active != null) rows.add(m.active);
        rows.addAll(m.settings);
        bindRow = new Module.Action("Bind", () -> listening ? "Press a key..." : Binds.label(m.name), () -> listening = true);
        rows.add(bindRow);
    }

    private void popupLayout() {
        int n = rows.size();
        int maxRows = Math.max(4, (height - 24 - P_HEAD) / P_ROW);
        visRows = Math.min(n, maxRows);
        pw = Math.min(width - 16, 214);
        ph = P_HEAD + visRows * P_ROW + 4;
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        maxScroll = Math.max(0, (n - visRows) * P_ROW);
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private int rowW() {
        return pw - 8 - (maxScroll > 0 ? 4 : 0);
    }

    private int rowX() {
        return px + 4;
    }

    private int rowY(int i) {
        return py + P_HEAD + 2 + i * P_ROW - (int) scroll;
    }

    // ---------------- small icons ----------------
    private static final String[] RESET_ICON = {
            ".XXXX.X..",
            "X....XXX.",
            "X.....X..",
            "X........",
            "X.......X",
            "X.......X",
            ".X.....X.",
            "..X...X..",
            "...XXX..."
    };

    private static void resetIcon(DrawContext ctx, int x, int y, int color) {
        for (int r = 0; r < RESET_ICON.length; r++) {
            String row = RESET_ICON[r];
            for (int c = 0; c < row.length(); c++) {
                if (row.charAt(c) == 'X') ctx.fill(x + c, y + r, x + c + 1, y + r + 1, color);
            }
        }
    }

    private static void arrowDown(DrawContext ctx, int x, int y, int color) {
        for (int i = 0; i < 4; i++) ctx.fill(x + i, y + i, x + 7 - i, y + i + 1, color);
    }

    private static void dots(DrawContext ctx, int x, int y, int color) {
        for (int i = 0; i < 3; i++) ctx.fill(x, y + i * 4, x + 2, y + i * 4 + 2, color);
    }

    private void flash(String text) {
        flashText = text;
        flashUntil = System.currentTimeMillis() + 1500;
    }

    // ---------------- drawing ----------------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        layout();
        gridScroll = Math.max(0, Math.min(maxGridScroll(), gridScroll));
        boolean free = open == null;

        // window
        ctx.fill(wx - 1, wy - 1, wx + ww + 1, wy + wh + 1, 0xFF050507);
        ctx.fill(wx, wy, wx + ww, wy + wh, 0xF20B0B0F);
        ctx.fill(wx, wy, wx + SB_W, wy + wh, 0xF2060608);
        ctx.fill(wx + SB_W, wy, wx + SB_W + 1, wy + wh, 0xFF1C1C22);

        // sidebar
        ctx.drawTextWithShadow(textRenderer, "ASTRAITE", wx + 12, wy + 11, ACCENT);
        ctx.fill(wx + 10, wy + 26, wx + SB_W - 10, wy + 27, 0xFF1C1C22);
        Module.Category[] cats = Module.Category.values();
        for (int i = 0; i < cats.length; i++) {
            int y = catY(i);
            boolean sel = query.isEmpty() && i == selCat;
            boolean hover = free && mx >= wx && mx < wx + SB_W && my >= y && my < y + CAT_H;
            if (sel) {
                ctx.fill(wx + 6, y, wx + SB_W - 6, y + CAT_H - 2, ACCENT_DIM);
                ctx.fill(wx + 6, y, wx + 9, y + CAT_H - 2, ACCENT);
            } else if (hover) {
                ctx.fill(wx + 6, y, wx + SB_W - 6, y + CAT_H - 2, 0xFF14141A);
            }
            ctx.drawTextWithShadow(textRenderer, cats[i].title, wx + 16, y + 7, sel ? 0xFFFFFFFF : (hover ? TEXT : TEXT_DIM));
        }
        int ay = accountsY();
        boolean hoverAcc = free && mx >= wx && mx < wx + SB_W && my >= ay && my < ay + CAT_H;
        if (hoverAcc) ctx.fill(wx + 6, ay, wx + SB_W - 6, ay + CAT_H - 2, 0xFF14141A);
        ctx.drawTextWithShadow(textRenderer, "Accounts", wx + 16, ay + 7, hoverAcc ? TEXT : TEXT_DIM);

        // search bar
        ctx.fill(mainX, searchY, mainX + mainW, searchY + 20, 0xFF101015);
        ctx.fill(mainX, searchY + 19, mainX + mainW, searchY + 20, ACCENT);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        if (query.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, "search modules...", mainX + 8, searchY + 6, 0xFF6A6A72);
            if (free && blink) ctx.fill(mainX + 6, searchY + 5, mainX + 7, searchY + 15, TEXT_DIM);
        } else {
            String shown = textRenderer.trimToWidth(query, mainW - 90);
            ctx.drawTextWithShadow(textRenderer, shown, mainX + 8, searchY + 6, TEXT);
            if (free && blink) {
                int cx = mainX + 8 + textRenderer.getWidth(shown) + 1;
                ctx.fill(cx, searchY + 5, cx + 1, searchY + 15, TEXT);
            }
        }
        String brand = "ASTRAITE";
        ctx.drawTextWithShadow(textRenderer, brand, mainX + mainW - 8 - textRenderer.getWidth(brand), searchY + 6, ACCENT);

        // category header
        List<Module> list = shownModules();
        String title = query.isEmpty() ? cats[selCat].title : "Results";
        ctx.fill(mainX, headY, mainX + mainW, headY + 18, 0xFF101015);
        ctx.fill(mainX, headY + 17, mainX + mainW, headY + 18, ACCENT);
        ctx.drawTextWithShadow(textRenderer, title, mainX + 8, headY + 5, TEXT);
        String count = String.valueOf(list.size());
        ctx.drawTextWithShadow(textRenderer, count, mainX + mainW - 8 - textRenderer.getWidth(count), headY + 5, TEXT_DIM);

        // module cards
        ctx.enableScissor(mainX, gridY, mainX + mainW, gridY + gridH);
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int x = cardX(i), y = cardY(i);
            if (y + CARD_H < gridY || y > gridY + gridH) continue;
            boolean inGrid = my >= gridY && my < gridY + gridH;
            boolean hover = free && inGrid && mx >= x && mx < x + cardW && my >= y && my < y + CARD_H;
            boolean on = m.isOn();
            int bg = on ? (hover ? 0xFF4A1C21 : ACCENT_DIM) : (hover ? 0xFF1B1B22 : 0xFF121217);
            ctx.fill(x, y, x + cardW, y + CARD_H, bg);
            if (on) ctx.fill(x, y, x + 3, y + CARD_H, ACCENT);
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.name, cardW - 32), x + 10, y + 6,
                    on ? 0xFFFFFFFF : (hover ? TEXT : TEXT_DIM));
            boolean hoverDots = hover && mx >= x + cardW - 20;
            dots(ctx, x + cardW - 11, y + 4, hoverDots ? ACCENT : (on ? 0xFFE08080 : 0xFF6A6A72));
        }
        ctx.disableScissor();

        // scrollbar for the grid
        double mgs = maxGridScroll();
        if (mgs > 0) {
            int trackH = gridH;
            int content = (int) (mgs + gridH);
            int barH = Math.max(12, (int) (trackH * (gridH / (double) content)));
            int barY = gridY + (int) ((trackH - barH) * (gridScroll / mgs));
            ctx.fill(mainX + mainW - 2, gridY, mainX + mainW, gridY + trackH, 0x30FFFFFF);
            ctx.fill(mainX + mainW - 2, barY, mainX + mainW, barY + barH, ACCENT);
        }
        if (list.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "No modules found", mainX + mainW / 2, gridY + 14, TEXT_DIM);
        }

        // popup (modal)
        if (open != null) {
            ctx.getMatrices().push();
            ctx.getMatrices().translate(0, 0, 300);
            ctx.fill(0, 0, width, height, 0x80000000);
            drawPopup(ctx, mx, my);
            ctx.getMatrices().pop();
        }

        // reset-all-keybinds icon (top right)
        if (open == null) {
            boolean armed = armAll && System.currentTimeMillis() - armTime < 3000;
            if (!armed) armAll = false;
            boolean hoverAll = mx >= width - 16 && my < 14;
            resetIcon(ctx, width - 13, 3, armed ? 0xFFFF5555 : (hoverAll ? 0xFFFFFF55 : 0xFFFFFFFF));
            if (armed) {
                String t = "Click again: reset ALL keybinds";
                ctx.drawTextWithShadow(textRenderer, t, width - 18 - textRenderer.getWidth(t), 4, 0xFFFF5555);
            } else if (hoverAll) {
                String t = "Reset all keybinds";
                ctx.drawTextWithShadow(textRenderer, t, width - 18 - textRenderer.getWidth(t), 4, 0xFFFFFF55);
            }
        }

        if (System.currentTimeMillis() < flashUntil) {
            ctx.getMatrices().push();
            ctx.getMatrices().translate(0, 0, 400);
            ctx.drawCenteredTextWithShadow(textRenderer, flashText, width / 2, wy + wh + 4 < height - 10 ? wy + wh + 4 : height - 12, 0xFF55FF55);
            ctx.getMatrices().pop();
        }
    }

    private void drawPopup(DrawContext ctx, int mx, int my) {
        popupLayout();
        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF050507);
        ctx.fill(px, py, px + pw, py + ph, 0xFF0D0D12);
        ctx.fill(px, py, px + pw, py + P_HEAD, 0xFF14141A);
        ctx.fill(px, py + P_HEAD - 1, px + pw, py + P_HEAD, ACCENT);
        ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(open.name, pw - 60), px + 8, py + 7, 0xFFFFFFFF);

        boolean hoverClose = mx >= px + pw - 22 && mx < px + pw && my >= py && my < py + P_HEAD;
        boolean hoverReset = mx >= px + pw - 38 && mx < px + pw - 22 && my >= py && my < py + P_HEAD;
        arrowDown(ctx, px + pw - 15, py + 9, hoverClose ? ACCENT : 0xFFD0D0D6);
        resetIcon(ctx, px + pw - 34, py + 7, hoverReset ? 0xFFFFFF55 : 0xFFD0D0D6);

        ctx.enableScissor(px, py + P_HEAD, px + pw, py + ph - 2);
        for (int i = 0; i < rows.size(); i++) {
            Module.Setting s = rows.get(i);
            int x = rowX(), y = rowY(i), w = rowW();
            if (y + P_ROW < py + P_HEAD || y > py + ph) continue;
            boolean hover = mx >= x && mx < x + w && my >= y && my < y + P_ROW
                    && my >= py + P_HEAD && my < py + ph - 2;
            ctx.fill(x, y, x + w, y + P_ROW - 2, hover ? 0xFF1C1C24 : 0xFF14141A);

            if (s instanceof Module.Bool b) {
                ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(b.name, w - 40), x + 6, y + 5, TEXT);
                boolean on = b.value();
                int tx = x + w - 26, ty = y + 4;
                ctx.fill(tx, ty, tx + 20, ty + 10, on ? ACCENT : 0xFF2E2E36);
                int kx = on ? tx + 11 : tx + 1;
                ctx.fill(kx, ty + 1, kx + 8, ty + 9, 0xFFFFFFFF);
            } else if (s instanceof Module.Int n) {
                ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(n.name, w - 50), x + 6, y + 2, TEXT);
                String v = n.display();
                ctx.drawTextWithShadow(textRenderer, v, x + w - 6 - textRenderer.getWidth(v), y + 2, ACCENT);
                int bx = x + 6, bw = w - 12;
                ctx.fill(bx, y + 13, bx + bw, y + 16, 0xFF2E2E36);
                ctx.fill(bx, y + 13, bx + (int) (bw * n.fraction()), y + 16, ACCENT);
            } else if (s instanceof Module.Action a) {
                boolean bindReset = a == bindRow && !listening && Binds.get(open.name) >= 0;
                String t = textRenderer.trimToWidth(a.text(), w - (bindReset ? 30 : 12));
                int tx = x + (w - (bindReset ? 16 : 0)) / 2 - textRenderer.getWidth(t) / 2;
                ctx.drawTextWithShadow(textRenderer, t, tx, y + 5, hover ? 0xFFFFFFFF : TEXT);
                if (bindReset) {
                    boolean hoverB = hover && mx >= x + w - 18;
                    resetIcon(ctx, x + w - 14, y + 4, hoverB ? 0xFFFFFF55 : 0xFFD0D0D6);
                }
            } else if (s instanceof Module.Choice c) {
                ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(c.name, w / 2), x + 6, y + 5, TEXT);
                String v = textRenderer.trimToWidth(c.label(), w / 2 - 10);
                ctx.drawTextWithShadow(textRenderer, v, x + w - 6 - textRenderer.getWidth(v), y + 5, ACCENT);
            }
        }
        ctx.disableScissor();

        if (maxScroll > 0) {
            int trackH = visRows * P_ROW;
            int barH = Math.max(10, (int) (trackH * (visRows / (double) rows.size())));
            int barY = py + P_HEAD + 2 + (int) ((trackH - barH) * (scroll / maxScroll));
            ctx.fill(px + pw - 4, py + P_HEAD + 2, px + pw - 2, py + P_HEAD + 2 + trackH, 0x30FFFFFF);
            ctx.fill(px + pw - 4, barY, px + pw - 2, barY + barH, ACCENT);
        }
    }

    // ---------------- input ----------------
    private void applyDrag(double mx) {
        if (dragging != null) dragging.setFraction((mx - dragX) / (double) dragW);
    }

    private void openModule(Module m) {
        open = m;
        buildRows(m);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        if (listening) { // any click while waiting for a key cancels the bind
            listening = false;
            return true;
        }

        if (open != null) {
            popupLayout();
            if (mx >= px && mx < px + pw && my >= py && my < py + ph) {
                if (my < py + P_HEAD) {
                    if (button == 0 && mx >= px + pw - 22) {
                        open = null; // down arrow = close
                        dragging = null;
                    } else if (button == 0 && mx >= px + pw - 38) {
                        open.resetSettings(); // round arrow = reset this module's settings
                        Config.save();
                        flash("Settings reset: " + open.name);
                    }
                    return true;
                }
                int rx = rowX(), rw = rowW();
                if (mx >= rx && mx < rx + rw && my >= py + P_HEAD) {
                    int i = (int) ((my - py - P_HEAD - 2 + scroll) / P_ROW);
                    if (i >= 0 && i < rows.size()) {
                        Module.Setting s = rows.get(i);
                        if (button == 1) {
                            if (s == bindRow) { // right click on Bind = clear it
                                Binds.set(open.name, -1);
                                flash("Keybind reset: " + open.name);
                            }
                        } else if (button == 0) {
                            if (s == bindRow && Binds.get(open.name) >= 0 && mx >= rx + rw - 18) {
                                Binds.set(open.name, -1);
                                flash("Keybind reset: " + open.name);
                            } else if (s instanceof Module.Bool b) b.toggle();
                            else if (s instanceof Module.Choice c) c.cycle();
                            else if (s instanceof Module.Action a) a.run();
                            else if (s instanceof Module.Int n) {
                                dragging = n;
                                dragX = rx + 6;
                                dragW = rw - 12;
                                applyDrag(mx);
                            }
                        }
                    }
                }
            } else {
                open = null; // click outside closes the popup
            }
            return true;
        }

        if (mx >= width - 16 && my < 14) { // reset ALL keybinds (asks twice)
            if (armAll && System.currentTimeMillis() - armTime < 3000) {
                Config.binds.clear();
                Config.save();
                armAll = false;
                flash("All keybinds reset");
            } else {
                armAll = true;
                armTime = System.currentTimeMillis();
            }
            return true;
        }
        armAll = false;

        // sidebar
        if (mx >= wx && mx < wx + SB_W) {
            for (int i = 0; i < byCat.size(); i++) {
                int y = catY(i);
                if (my >= y && my < y + CAT_H) {
                    selCat = i;
                    query = "";
                    gridScroll = 0;
                    return true;
                }
            }
            int ay = accountsY();
            if (my >= ay && my < ay + CAT_H) {
                client.setScreen(new AccountScreen(this));
                return true;
            }
            return true;
        }

        // module cards
        if (mx >= mainX && mx < mainX + mainW && my >= gridY && my < gridY + gridH) {
            List<Module> list = shownModules();
            for (int i = 0; i < list.size(); i++) {
                int x = cardX(i), y = cardY(i);
                if (mx >= x && mx < x + cardW && my >= y && my < y + CARD_H) {
                    Module m = list.get(i);
                    if (button == 1 || (button == 0 && mx >= x + cardW - 20)) openModule(m);
                    else if (button == 0) m.click();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (open != null) {
            scroll = Math.max(0, Math.min(maxScroll, scroll - vAmount * P_ROW * 2));
            return true;
        }
        gridScroll = Math.max(0, Math.min(maxGridScroll(), gridScroll - vAmount * (CARD_H + GAP) * 1.5));
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            applyDrag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (open == null && !listening && chr >= 32 && chr != 127 && query.length() < 24) {
            query += chr;
            gridScroll = 0;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening && open != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) Binds.set(open.name, -1);
            else if (keyCode != GLFW.GLFW_KEY_ESCAPE) Binds.set(open.name, keyCode);
            listening = false;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (open != null) {
                open = null;
                return true;
            }
            if (!query.isEmpty()) {
                query = "";
                gridScroll = 0;
                return true;
            }
        }
        if (open == null && keyCode == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            gridScroll = 0;
            return true;
        }
        if (ChestHighlightClient.openKey != null && ChestHighlightClient.openKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
