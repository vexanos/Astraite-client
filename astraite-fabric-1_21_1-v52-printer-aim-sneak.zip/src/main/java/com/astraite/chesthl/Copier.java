package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Copy any build from the world: pick two corners, copy -> it is saved as a .schem in .minecraft/schematics
 * and loaded into the Schematic Printer, so you can build it again anywhere (rotate / mirror included).
 */
public final class Copier {
    static final int MAX_BLOCKS = 8_000_000;

    static volatile BlockPos a, b;
    public static String status = "";

    private Copier() {
    }

    // ------------------------------------------------------------------ selection

    static boolean setLook(MinecraftClient mc, boolean first) {
        if (mc.crosshairTarget instanceof BlockHitResult bhr && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            set(bhr.getBlockPos(), first);
            return true;
        }
        status = "Look at a block first";
        return false;
    }

    static void setHere(ClientPlayerEntity p, boolean first) {
        set(p.getBlockPos().down(), first); // the block you stand on
    }

    private static void set(BlockPos pos, boolean first) {
        if (first) a = pos;
        else b = pos;
        status = (first ? "Pos1" : "Pos2") + " = " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ();
    }

    static void clear() {
        a = null;
        b = null;
        status = "Selection cleared";
    }

    static boolean hasSelection() {
        return a != null && b != null;
    }

    static int[] size() {
        if (!hasSelection()) return null;
        return new int[]{Math.abs(a.getX() - b.getX()) + 1, Math.abs(a.getY() - b.getY()) + 1, Math.abs(a.getZ() - b.getZ()) + 1};
    }

    static String sizeText() {
        int[] s = size();
        if (s == null) return "Select Pos1 and Pos2";
        return s[0] + " x " + s[1] + " x " + s[2] + "  (" + ((long) s[0] * s[1] * s[2]) + " blocks)";
    }

    // ------------------------------------------------------------------ copy

    /** Copies the selected region, saves it and loads it into the printer. Returns true on success. */
    static boolean copy(MinecraftClient mc, String rawName) {
        ClientWorld w = mc.world;
        if (w == null) return false;
        if (!hasSelection()) {
            status = "Set Pos1 and Pos2 first";
            return false;
        }
        int[] sz = size();
        if ((long) sz[0] * sz[1] * sz[2] > MAX_BLOCKS) {
            status = "Selection is too big (max " + MAX_BLOCKS + " blocks)";
            return false;
        }
        int minX = Math.min(a.getX(), b.getX()), maxX = Math.max(a.getX(), b.getX());
        int minZ = Math.min(a.getZ(), b.getZ()), maxZ = Math.max(a.getZ(), b.getZ());
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                if (!w.isChunkLoaded(cx, cz)) {
                    status = "Part of the selection is not loaded - walk closer";
                    return false;
                }
            }
        }

        String base = cleanName(rawName);
        Schem s;
        try {
            s = Schem.fromWorld(base, w, a, b);
        } catch (IOException e) {
            status = "Copy failed: " + e.getMessage();
            return false;
        }

        String file = "";
        try {
            Path dir = Printer.dir();
            String fn = base + ".schem";
            int n = 2;
            while (Files.exists(dir.resolve(fn))) fn = base + "_" + n++ + ".schem";
            s.save(dir.resolve(fn));
            file = fn;
        } catch (Throwable e) {
            status = "Copied, but saving failed: " + e.getMessage();
        }
        Printer.setLoaded(s, file);
        // the copy is meant to go somewhere else: the printer asks for a new origin (set it with Origin here / look)
        Config.schemOriginSet = false;
        Config.printer = false;
        Config.save();
        if (!file.isEmpty()) {
            status = "Copied " + s.blockCount() + " blocks -> " + file;
        }
        return true;
    }

    static String cleanName(String raw) {
        String n = raw == null ? "" : raw.trim().replaceAll("[^A-Za-z0-9_\\- ]", "_");
        return n.isEmpty() ? "build" : n;
    }

    // ------------------------------------------------------------------ render

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BlockPos pa = a, pb = b;
        if ((pa == null && pb == null) || mc.world == null) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;
        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        if (pa != null && pb != null) {
            Box region = new Box(Math.min(pa.getX(), pb.getX()), Math.min(pa.getY(), pb.getY()), Math.min(pa.getZ(), pb.getZ()),
                    Math.max(pa.getX(), pb.getX()) + 1, Math.max(pa.getY(), pb.getY()) + 1, Math.max(pa.getZ(), pb.getZ()) + 1);
            EntityEsp.lines(lb, mv, region.offset(-cam.x, -cam.y, -cam.z), 0xFF55FFFF);
        }
        if (pa != null) EntityEsp.lines(lb, mv, new Box(pa).expand(0.01).offset(-cam.x, -cam.y, -cam.z), 0xFF55FF55);
        if (pb != null) EntityEsp.lines(lb, mv, new Box(pb).expand(0.01).offset(-cam.x, -cam.y, -cam.z), 0xFFFF5555);
        BufferRenderer.drawWithGlobalProgram(lb.end());

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
