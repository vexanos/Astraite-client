package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/** Copy a build from the world and paste (print) it somewhere else. */
public class CopyScreen extends Screen {
    private static String lastName = "build";

    private final Screen parent;
    private TextFieldWidget nameField;

    public CopyScreen(Screen parent) {
        super(Text.literal("Copy Build"));
        this.parent = parent;
    }

    private static String pos(BlockPos p) {
        return p == null ? "-" : p.getX() + ", " + p.getY() + ", " + p.getZ();
    }

    @Override
    protected void init() {
        int bw = 220, rowH = 22, cx = width / 2, left = cx - bw / 2, half = (bw - 6) / 2;
        int y = Math.max(40, (height - 7 * rowH - 50) / 2 + 34);

        addDrawableChild(ButtonWidget.builder(Text.literal("Pos1: look"), b -> Copier.setLook(client, true))
                .dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Pos1: here"), b -> {
            if (client.player != null) Copier.setHere(client.player, true);
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Pos2: look"), b -> Copier.setLook(client, false))
                .dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Pos2: here"), b -> {
            if (client.player != null) Copier.setHere(client.player, false);
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        nameField = new TextFieldWidget(textRenderer, left, y, bw, 20, Text.literal("Name"));
        nameField.setMaxLength(40);
        nameField.setText(lastName);
        addDrawableChild(nameField);

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Copy"), b -> {
            lastName = nameField.getText();
            Copier.copy(client, lastName);
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear"), b -> Copier.clear())
                .dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Paste at: here"), b -> {
            if (client.player != null) {
                Printer.originHere(client.player);
                Copier.status = "Paste origin = your position";
            }
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Paste at: look"), b -> {
            if (Printer.originLook(client)) Copier.status = "Paste origin = block you look at";
            else Copier.status = "Look at a block first";
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Preview only"), b -> {
            Config.printer = true;
            Config.prBuild = false;
            Config.save();
            close();
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Build it"), b -> {
            Config.printer = true;
            Config.prBuild = true;
            Config.save();
            close();
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left, y, bw, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xE0101018);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, "Copy Build", cx, 6, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "Pos1: " + pos(Copier.a) + "   Pos2: " + pos(Copier.b), cx, 18, 0xFFAAFFAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Copier.sizeText(), cx, 29, 0xFFFFFFFF);
        int bottom = Math.max(40, (height - 7 * 22 - 50) / 2 + 34) + 7 * 22 + 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Copier.status, cx, bottom, 0xFFFFD700);
        String loaded = Printer.loadedName().isEmpty() ? "Nothing loaded" : "Loaded: " + Printer.loadedName()
                + "  @ " + Config.schemOx + ", " + Config.schemOy + ", " + Config.schemOz;
        ctx.drawCenteredTextWithShadow(textRenderer, loaded, cx, bottom + 11, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
