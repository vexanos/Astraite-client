package com.astraite.chesthl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Remembers the real default of every built-in setting. snapshot() must run BEFORE Config.load(),
 * while the Config fields still hold their default values.
 */
final class Defaults {
    private static final Map<String, Object> map = new HashMap<>();

    private Defaults() {
    }

    private static String key(Module m, int i) {
        return m.name + "#" + i;
    }

    static void snapshot() {
        try {
            for (Module m : Modules.builtin()) {
                for (int i = 0; i < m.settings.size(); i++) {
                    Object v = m.settings.get(i).current();
                    if (v != null) map.put(key(m, i), v);
                }
            }
        } catch (Throwable t) {
            // defaults just stay unknown, the reset arrow then does nothing for those settings
        }
    }

    static void apply(List<Module> mods) {
        for (Module m : mods) {
            for (int i = 0; i < m.settings.size(); i++) {
                Object v = map.get(key(m, i));
                if (v != null) m.settings.get(i).setDefault(v);
            }
        }
    }
}
