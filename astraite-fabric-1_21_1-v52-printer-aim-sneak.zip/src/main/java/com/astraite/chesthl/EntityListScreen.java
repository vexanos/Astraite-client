package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.entity.EntityType;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Scrollable checklist of every living entity type (Kill Aura -> Entities -> Select). */
public class EntityListScreen extends Screen {
    private static final int PURPLE = 0xFFE04040;
    private static final int HEADER_H = 14, ROW_H = 12;

    private final Screen parent;
    private final java.util.Set<String> set;
    private final List<EntityType<?>> all = new ArrayList<>();
    private final List<EntityType<?>> shown = new ArrayList<>();
    private TextFieldWidget search;
    private String query = "";
    private double scroll = 0;
    private boolean draggingBar = false;

    private int px, py, pw, ph, listY, listH;

    public EntityListScreen(Screen parent, java.util.Set<String> set) {
        super(Text.literal("Entities"));
        this.parent = parent;
        this.set = set;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) all.addAll(EntityTypes.living(mc.world));
        shown.addAll(all);
    }

    @Override
    protected void init() {
        pw = Math.min(240, width - 16);
        ph = height - 24;
        px = (width - pw) / 2;
        py = 12;
        listY = py + HEADER_H + 18;
        listH = ph - HEADER_H - 18 - 24;

        search = new TextFieldWidget(textRenderer, px + 3, py + HEADER_H + 2, pw - 6, 14, Text.literal("Search"));
        search.setPlaceholder(Text.literal("Search..."));
        search.setText(query);
        search.setChangedListener(s -> {
            query = s;
            refilter();
        });
        addDrawableChild(search);
        setInitialFocus(search);

        int by = py + ph - 20, bw = (pw - 12) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal("Select all"), b -> setAllShown(true))
                .dimensions(px + 3, by, bw, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear"), b -> setAllShown(false))
                .dimensions(px + 6 + bw, by, bw, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(px + 9 + 2 * bw, by, bw, 16).build());
    }

    private void refilter() {
        String q = query.trim().toLowerCase();
        shown.clear();
        for (EntityType<?> t : all) {
            if (q.isEmpty() || t.getName().getString().toLowerCase().contains(q) || EntityTypes.id(t).contains(q)) shown.add(t);
        }
        scroll = 0;
    }

    private void setAllShown(boolean on) {
        for (EntityType<?> t : shown) {
            if (on) set.add(EntityTypes.id(t));
            else set.remove(EntityTypes.id(t));
        }
    }

    private double maxScroll() {
        return Math.max(0, shown.size() * ROW_H - listH);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x90000000);
        drawPanel(ctx, mx, my);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // calls renderBackground once, then buttons + search box
    }

    private void drawPanel(DrawContext ctx, int mx, int my) {
        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF000000);
        ctx.fill(px, py, px + pw, py + HEADER_H, PURPLE);
        ctx.drawCenteredTextWithShadow(textRenderer, "Entities (" + set.size() + " selected)",
                px + pw / 2, py + 3, 0xFFFFFFFF);
        ctx.fill(px, py + HEADER_H, px + pw, py + ph, 0xF0101018);

        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        ctx.enableScissor(px, listY, px + pw, listY + listH);
        int first = (int) (scroll / ROW_H);
        int last = Math.min(shown.size(), first + listH / ROW_H + 2);
        for (int i = first; i < last; i++) {
            EntityType<?> t = shown.get(i);
            int y = listY + i * ROW_H - (int) scroll;
            boolean hover = mx >= px && mx < px + pw - 6 && my >= Math.max(y, listY) && my < Math.min(y + ROW_H, listY + listH);
            ctx.fill(px + 1, y, px + pw - 6, y + ROW_H - 1, hover ? 0xC02C2C38 : 0xC0141420);
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(t.getName().getString(), pw - 30), px + 5, y + 2, 0xFFE0E0E0);
            boolean on = set.contains(EntityTypes.id(t));
            int bx = px + pw - 18, by = y + 2;
            ctx.fill(bx, by, bx + 8, by + 8, 0xFF808090);
            ctx.fill(bx + 1, by + 1, bx + 7, by + 7, on ? PURPLE : 0xFF141420);
        }
        ctx.disableScissor();

        // scrollbar
        if (maxScroll() > 0) {
            int barH = Math.max(14, (int) (listH * (listH / (double) (shown.size() * ROW_H))));
            int barY = listY + (int) ((listH - barH) * (scroll / maxScroll()));
            ctx.fill(px + pw - 5, listY, px + pw - 2, listY + listH, 0x60FFFFFF);
            ctx.fill(px + pw - 5, barY, px + pw - 2, barY + barH, PURPLE);
        }
        if (shown.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "No entities found", px + pw / 2, listY + 8, 0xFF909090);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        if (my >= listY && my < listY + listH && mx >= px && mx < px + pw) {
            if (mx >= px + pw - 7 && maxScroll() > 0) {
                draggingBar = true;
                dragBar(my);
                return true;
            }
            int i = (int) ((my - listY + scroll) / ROW_H);
            if (i >= 0 && i < shown.size()) {
                String id = EntityTypes.id(shown.get(i));
                if (!set.remove(id)) set.add(id);
            }
            return true;
        }
        return false;
    }

    private void dragBar(double my) {
        scroll = Math.max(0, Math.min(maxScroll(), (my - listY) / listH * (shown.size() * ROW_H) - listH / 2.0));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingBar) {
            dragBar(my);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingBar = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - vAmount * ROW_H * 3));
        return true;
    }

    @Override
    public void close() {
        Config.save();
        MinecraftClient.getInstance().setScreen(parent);
    }
}
