package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Coordinates / direction / FPS / ping / speed overlay. */
final class InfoHud {
    static final String[] COLORS = {"White", "Red", "Green", "Blue", "Yellow", "Cyan", "Purple", "Orange", "Rainbow"};
    private static final int[] PAL = {0xFFFFFF, 0xFF5555, 0x55FF55, 0x5555FF, 0xFFFF55, 0x55FFFF, 0xFF55FF, 0xFFAA00};

    private InfoHud() {
    }

    private static String facing(ClientPlayerEntity p) {
        Direction d = p.getHorizontalFacing();
        return switch (d) {
            case NORTH -> "North (-Z)";
            case SOUTH -> "South (+Z)";
            case EAST -> "East (+X)";
            default -> "West (-X)";
        };
    }

    static void render(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.info || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        ClientPlayerEntity p = mc.player;

        List<String> lines = new ArrayList<>();
        if (Config.infoCoords) {
            lines.add(String.format(Locale.ROOT, "XYZ: %.1f, %.1f, %.1f", p.getX(), p.getY(), p.getZ()));
        }
        if (Config.infoNether) {
            if (mc.world.getRegistryKey() == World.OVERWORLD) {
                lines.add(String.format(Locale.ROOT, "Nether: %.0f, %.0f", p.getX() / 8.0, p.getZ() / 8.0));
            } else if (mc.world.getRegistryKey() == World.NETHER) {
                lines.add(String.format(Locale.ROOT, "Overworld: %.0f, %.0f", p.getX() * 8.0, p.getZ() * 8.0));
            }
        }
        if (Config.infoDir) lines.add("Facing: " + facing(p));
        if (Config.infoFps) lines.add("FPS: " + mc.getCurrentFps());
        if (Config.infoPing) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (e != null) ping = e.getLatency();
            }
            lines.add("Ping: " + ping + " ms");
        }
        if (Config.infoSpeed) {
            double bps = Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ) * 20.0;
            lines.add(String.format(Locale.ROOT, "Speed: %.1f b/s", bps));
        }
        if (lines.isEmpty()) return;

        float scale = Config.infoScale10 / 10f;
        float sw = g.getScaledWindowWidth() / scale;
        float sh = g.getScaledWindowHeight() / scale;
        boolean right = Config.infoCorner == 1 || Config.infoCorner == 3;
        boolean bottom = Config.infoCorner == 2 || Config.infoCorner == 3;
        int bg = Config.infoBg > 0 ? ((int) (Config.infoBg / 100.0 * 255) << 24) : 0;
        int rowH = 10;
        int y = bottom ? (int) (sh - Config.infoOffY - lines.size() * rowH) : Config.infoOffY;

        g.getMatrices().push();
        g.getMatrices().scale(scale, scale, 1f);
        int i = 0;
        for (String line : lines) {
            int w = mc.textRenderer.getWidth(line);
            int x = right ? (int) (sw - Config.infoOffX - w) : Config.infoOffX;
            int c;
            if (Config.infoColor == 8) {
                float hue = (((System.currentTimeMillis() * 3L) % 12000L) / 12000f + i * 0.06f) % 1f;
                c = 0xFF000000 | MathHelper.hsvToRgb(hue, 0.55f, 1.0f);
            } else {
                c = 0xFF000000 | PAL[Math.max(0, Math.min(PAL.length - 1, Config.infoColor))];
            }
            if (bg != 0) g.fill(x - 2, y - 1, x + w + 2, y + 9, bg);
            g.drawText(mc.textRenderer, line, x, y, c, Config.infoShadow);
            y += rowH;
            i++;
        }
        g.getMatrices().pop();
    }
}
