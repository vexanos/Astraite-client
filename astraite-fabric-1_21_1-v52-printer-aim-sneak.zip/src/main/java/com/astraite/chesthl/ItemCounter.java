package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Totem / armor durability / crystal / anchor ... counter overlay with item icons. */
final class ItemCounter {
    private record Entry(ItemStack icon, String text, int rgb) {
    }

    private ItemCounter() {
    }

    private static int count(ClientPlayerEntity p, Item... items) {
        int n = 0;
        for (ItemStack s : p.getInventory().main) {
            for (Item it : items) if (s.isOf(it)) n += s.getCount();
        }
        for (ItemStack s : p.getInventory().offHand) {
            for (Item it : items) if (s.isOf(it)) n += s.getCount();
        }
        return n;
    }

    private static void add(List<Entry> l, ClientPlayerEntity p, Item icon, Item... items) {
        l.add(new Entry(new ItemStack(icon), String.valueOf(count(p, items)), 0xFFFFFF));
    }

    static void render(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.counter || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        ClientPlayerEntity p = mc.player;

        List<Entry> list = new ArrayList<>();
        if (Config.counterTotems) {
            int n = count(p, Items.TOTEM_OF_UNDYING);
            boolean low = Config.counterWarn > 0 && n <= Config.counterWarn;
            list.add(new Entry(new ItemStack(Items.TOTEM_OF_UNDYING), String.valueOf(n), low ? 0xFF5555 : 0xFFFFFF));
        }
        if (Config.counterCrystals) add(list, p, Items.END_CRYSTAL, Items.END_CRYSTAL);
        if (Config.counterAnchors) {
            add(list, p, Items.RESPAWN_ANCHOR, Items.RESPAWN_ANCHOR);
            add(list, p, Items.GLOWSTONE, Items.GLOWSTONE);
        }
        if (Config.counterGaps) add(list, p, Items.GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE);
        if (Config.counterXp) add(list, p, Items.EXPERIENCE_BOTTLE, Items.EXPERIENCE_BOTTLE);
        if (Config.counterArmor) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot es : slots) {
                ItemStack st = p.getEquippedStack(es);
                if (st.isEmpty()) continue;
                if (st.isDamageable()) {
                    int pct = (int) Math.round(100.0 * (st.getMaxDamage() - st.getDamage()) / st.getMaxDamage());
                    int rgb = pct > 60 ? 0x55FF55 : pct > 30 ? 0xFFFF55 : 0xFF5555;
                    list.add(new Entry(st, pct + "%", rgb));
                } else {
                    list.add(new Entry(st, "", 0xFFFFFF));
                }
            }
        }
        if (list.isEmpty()) return;

        float scale = Config.counterScale10 / 10f;
        float sw = g.getScaledWindowWidth() / scale;
        float sh = g.getScaledWindowHeight() / scale;
        boolean right = Config.counterCorner == 1 || Config.counterCorner == 3;
        boolean bottom = Config.counterCorner == 2 || Config.counterCorner == 3;
        boolean horizontal = Config.counterLayout == 1;
        int bg = Config.counterBg > 0 ? ((int) (Config.counterBg / 100.0 * 255) << 24) : 0;

        int[] widths = new int[list.size()];
        int total = 0, maxW = 0;
        for (int i = 0; i < list.size(); i++) {
            Entry e = list.get(i);
            widths[i] = 18 + (e.text().isEmpty() ? 0 : mc.textRenderer.getWidth(e.text()) + 2);
            total += widths[i] + (horizontal ? 6 : 0);
            maxW = Math.max(maxW, widths[i]);
        }
        int boxW = horizontal ? total - 6 : maxW;
        int boxH = horizontal ? 16 : list.size() * 18 - 2;
        int x0 = right ? (int) (sw - Config.counterOffX - boxW) : Config.counterOffX;
        int y0 = bottom ? (int) (sh - Config.counterOffY - boxH) : Config.counterOffY;

        g.getMatrices().push();
        g.getMatrices().scale(scale, scale, 1f);
        if (bg != 0) g.fill(x0 - 2, y0 - 2, x0 + boxW + 2, y0 + boxH + 2, bg);
        int x = x0, y = y0;
        for (int i = 0; i < list.size(); i++) {
            Entry e = list.get(i);
            g.drawItem(e.icon(), x, y);
            if (!e.text().isEmpty()) {
                g.drawText(mc.textRenderer, e.text(), x + 18, y + 4, 0xFF000000 | e.rgb(), true);
            }
            if (horizontal) x += widths[i] + 6;
            else y += 18;
        }
        g.getMatrices().pop();
    }
}
