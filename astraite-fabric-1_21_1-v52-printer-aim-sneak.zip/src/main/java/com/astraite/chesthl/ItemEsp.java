package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Highlights dropped items (through walls); the name + count labels are drawn by {@link Overlay}. */
public final class ItemEsp {
    private ItemEsp() {
    }

    static int colorFor(ItemStack st) {
        if (Config.itemEspRarity) {
            return switch (st.getRarity()) {
                case UNCOMMON -> 0xFFFF55;
                case RARE -> 0x55FFFF;
                case EPIC -> 0xFF55FF;
                default -> 0xFFFFFF;
            };
        }
        return EntityEsp.COLORS[MathHelper.clamp(Config.itemEspColor, 0, EntityEsp.COLORS.length - 1)];
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.itemEspEnabled || mc.world == null || mc.player == null) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        float delta = mc.getRenderTickCounter().getTickDelta(false);
        Matrix4f mv = stack.peek().getPositionMatrix();
        double max2 = (double) Config.itemEspRange * Config.itemEspRange;
        float scale = Config.itemEspScale10 / 10.0f;

        List<Box> boxes = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie)) continue;
            Vec3d lp = ie.getLerpedPos(delta);
            double dx = lp.x - cam.x, dy = lp.y - cam.y, dz = lp.z - cam.z;
            if (dx * dx + dy * dy + dz * dz > max2) continue;
            ItemStack st = ie.getStack();
            if (st.isEmpty()) continue;

            int rgb = colorFor(st);
            Box b = ie.getBoundingBox().offset(lp.x - ie.getX(), lp.y - ie.getY(), lp.z - ie.getZ())
                    .expand(0.08).offset(-cam.x, -cam.y, -cam.z);
            boxes.add(b);
            cols.add(rgb);

            if (Config.itemEspNames) {
                String label = st.getName().getString();
                if (Config.itemEspCount && st.getCount() > 1) label += " x" + st.getCount();
                Vec3d c = b.getCenter();
                Overlay.addLabel(new Vec3d(c.x, c.y + 0.4, c.z), label, rgb, scale);
            }
        }
        if (boxes.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // visible through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.itemEspShape != 0 && Config.itemEspFill > 0) {
            int a = (int) (255 * Config.itemEspFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.fill(bb, mv, boxes.get(i), (a << 24) | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.itemEspShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.lines(lb, mv, boxes.get(i), 0xFF000000 | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
