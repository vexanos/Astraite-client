package com.astraite.chesthl;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Collects the data for the custom nametags (name, health, ping, distance, armor + hand items). Drawn by {@link Overlay}. */
public final class Nametags {
    private Nametags() {
    }

    public static void collect(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.nametags || mc.world == null || mc.player == null) return;
        Vec3d cam = ctx.camera().getPos();
        float delta = mc.getRenderTickCounter().getTickDelta(false);
        double max2 = (double) Config.tagRange * Config.tagRange;
        float scale = Config.tagScale10 / 10.0f;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le.isDead()) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !Config.tagMobs) continue;
            if (e == mc.player && !Config.tagSelf) continue;

            Vec3d rel = e.getLerpedPos(delta).add(0, e.getHeight() + 0.75, 0).subtract(cam);
            double d2 = rel.lengthSquared();
            if (d2 > max2) continue;

            StringBuilder name = new StringBuilder(e.getName().getString());
            if (player && Config.tagPing && mc.getNetworkHandler() != null) {
                PlayerListEntry pe = mc.getNetworkHandler().getPlayerListEntry(e.getUuid());
                if (pe != null) name.append(' ').append(pe.getLatency()).append("ms");
            }
            if (Config.tagDist) {
                name.append(' ').append(String.format(Locale.ROOT, "%.0fm", mc.player.distanceTo(e)));
            }

            String suffix = "";
            int suffixRgb = 0xFFFFFF;
            if (Config.tagHealth) {
                float hp = le.getHealth() + le.getAbsorptionAmount();
                float frac = hp / Math.max(1f, le.getMaxHealth());
                suffix = " " + String.format(Locale.ROOT, "%.1f", hp);
                suffixRgb = frac >= 0.66f ? 0x55FF55 : frac >= 0.33f ? 0xFFFF55 : 0xFF5555;
            }

            List<ItemStack> items = new ArrayList<>();
            if (Config.tagItems) {
                add(items, le.getMainHandStack());
                add(items, le.getEquippedStack(EquipmentSlot.HEAD));
                add(items, le.getEquippedStack(EquipmentSlot.CHEST));
                add(items, le.getEquippedStack(EquipmentSlot.LEGS));
                add(items, le.getEquippedStack(EquipmentSlot.FEET));
                add(items, le.getOffHandStack());
            }
            Overlay.addTag(rel, name.toString(), e.isSneaking() ? 0xFFAA00 : 0xFFFFFF, suffix, suffixRgb, items, scale);
        }
    }

    private static void add(List<ItemStack> l, ItemStack s) {
        if (!s.isEmpty()) l.add(s);
    }
}
