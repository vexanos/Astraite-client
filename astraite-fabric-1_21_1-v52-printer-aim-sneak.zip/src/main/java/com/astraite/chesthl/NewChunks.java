package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * New Chunks: a chunk is marked "new" when a still-flowing liquid update arrives for it
 * (liquids only keep flowing like that in freshly generated terrain). Marked chunks are drawn
 * as a flat plane at your feet, so trails of new chunks show where other players have not been.
 */
public final class NewChunks {
    private static final int MAX = 4000;
    private static final Set<Long> chunks = ConcurrentHashMap.newKeySet();
    private static ClientWorld lastWorld = null;
    public static String status = "";

    private NewChunks() {
    }

    /** Called from the network mixin for every block change the server sends. */
    public static void onBlock(BlockPos pos, BlockState state) {
        if (!Config.newChunks || chunks.size() >= MAX) return;
        FluidState fs = state.getFluidState();
        if (fs.isEmpty() || fs.isStill()) return;
        chunks.add(ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4));
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.newChunks || mc.world == null || mc.player == null) {
            if (!chunks.isEmpty()) chunks.clear();
            lastWorld = null;
            status = "";
            return;
        }
        if (lastWorld != mc.world) { // new world / dimension
            lastWorld = mc.world;
            chunks.clear();
        }
        status = String.valueOf(chunks.size());
    }

    public static void clear() {
        chunks.clear();
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.newChunks || mc.world == null || mc.player == null || chunks.isEmpty()) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();
        int rgb = EntityEsp.COLORS[MathHelper.clamp(Config.ncColor, 0, EntityEsp.COLORS.length - 1)];
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        double y = mc.player.getBlockY() + 0.02;
        List<Box> boxes = new ArrayList<>();
        for (long k : chunks) {
            int cx = ChunkPos.getPackedX(k), cz = ChunkPos.getPackedZ(k);
            if (Math.abs(cx - pcx) > Config.ncRange || Math.abs(cz - pcz) > Config.ncRange) continue;
            boxes.add(new Box(cx * 16, y, cz * 16, cx * 16 + 16, y + 0.01, cz * 16 + 16)
                    .offset(-cam.x, -cam.y, -cam.z));
        }
        if (boxes.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.ncShape != 0 && Config.ncFill > 0) {
            int a = (int) (255 * Config.ncFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Box b : boxes) EntityEsp.fill(bb, mv, b, (a << 24) | rgb);
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.ncShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (Box b : boxes) EntityEsp.lines(lb, mv, b, 0xFF000000 | rgb);
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
