package com.astraite.chesthl;

/** No Render: switches off annoying visual effects. The mixins ask these methods before drawing. */
public final class NoRender {
    private NoRender() {
    }

    private static boolean on() {
        return Config.noRender;
    }

    public static boolean fire() { return on() && Config.nrFire; }
    public static boolean water() { return on() && Config.nrWater; }
    public static boolean wall() { return on() && Config.nrWall; }
    public static boolean weather() { return on() && Config.nrWeather; }
    public static boolean particles() { return on() && Config.nrParticles; }
    public static boolean totem() { return on() && Config.nrTotem; }
    public static boolean hurt() { return on() && Config.nrHurt; }
    public static boolean pumpkin() { return on() && Config.nrPumpkin; }
    public static boolean vignette() { return on() && Config.nrVignette; }
}
