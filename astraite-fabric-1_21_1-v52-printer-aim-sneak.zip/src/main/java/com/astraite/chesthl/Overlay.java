package com.astraite.chesthl;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * 2D overlay for things that must always be readable: tracer lines and text labels.
 * The world render phase only collects camera-relative points; the points are projected to the screen
 * and drawn with the normal GUI renderer, which (unlike 3D lines / world text) always works.
 */
public final class Overlay {
    private record Label(Vec3d rel, String text, int rgb, float scale) {
    }

    private record Line(Vec3d rel, int argb) {
    }

    private record Tag(Vec3d rel, String name, int nameRgb, String suffix, int suffixRgb, List<ItemStack> items, float scale) {
    }

    private static final List<Label> labels = new ArrayList<>();
    private static final List<Line> lines = new ArrayList<>();
    private static final List<Tag> tags = new ArrayList<>();
    private static final Matrix4f viewProj = new Matrix4f();
    private static boolean valid = false;

    private Overlay() {
    }

    /** Runs first in WorldRenderEvents.LAST every frame. */
    public static void begin(WorldRenderContext ctx) {
        labels.clear();
        lines.clear();
        tags.clear();
        valid = false;
        Camera camera = ctx.camera();
        if (camera == null) return;
        // view = inverse of the camera rotation (same as vanilla); points are camera-relative
        Matrix4f view = new Matrix4f().rotation(new Quaternionf(camera.getRotation()).conjugate());
        viewProj.set(ctx.projectionMatrix()).mul(view);
        valid = true;
    }

    /** rel = world position minus camera position. */
    static void addLabel(Vec3d rel, String text, int rgb, float scale) {
        if (valid) labels.add(new Label(rel, text, rgb, scale));
    }

    static void addTag(Vec3d rel, String name, int nameRgb, String suffix, int suffixRgb, List<ItemStack> items, float scale) {
        if (valid) tags.add(new Tag(rel, name, nameRgb, suffix, suffixRgb, items, scale));
    }

    static void addLine(Vec3d rel, int argb) {
        if (valid) lines.add(new Line(rel, argb));
    }

    /** Returns {x, y, inFront}. Points behind the camera are pushed off-screen in their direction. */
    private static float[] project(Vec3d rel, int w, int h) {
        Vector4f v = new Vector4f((float) rel.x, (float) rel.y, (float) rel.z, 1f);
        viewProj.transform(v);
        if (v.w > 0.05f) {
            float nx = v.x / v.w, ny = v.y / v.w;
            return new float[]{(nx * 0.5f + 0.5f) * w, (0.5f - ny * 0.5f) * h, 1f};
        }
        float len = (float) Math.hypot(v.x, v.y);
        float dx = len < 1e-4f ? 0f : v.x / len;
        float dy = len < 1e-4f ? -1f : v.y / len;
        return new float[]{w * 0.5f + dx * w * 2f, h * 0.5f - dy * h * 2f, 0f};
    }

    public static void draw(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!valid || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (lines.isEmpty() && labels.isEmpty() && tags.isEmpty()) return;
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();

        if (!lines.isEmpty()) {
            float sx = w / 2f;
            float sy = switch (Config.tracerStart) {
                case 1 -> (float) h;
                case 2 -> 0f;
                default -> h / 2f;
            };
            for (Line l : lines) {
                float[] p = project(l.rel(), w, h);
                line(g, sx, sy, p[0], p[1], l.argb(), Config.tracerWidth);
            }
        }

        TextRenderer tr = mc.textRenderer;
        for (Label lb : labels) {
            float[] p = project(lb.rel(), w, h);
            if (p[2] == 0f || p[0] < -50 || p[0] > w + 50 || p[1] < -20 || p[1] > h + 20) continue;
            double dist = lb.rel().length();
            float s = lb.scale() * MathHelper.clamp(20f / (float) (dist + 8.0), 0.7f, 1.2f);
            int tw = tr.getWidth(lb.text());
            MatrixStack ms = g.getMatrices();
            ms.push();
            ms.translate(p[0], p[1], 0f);
            ms.scale(s, s, 1f);
            g.fill(-tw / 2 - 2, -11, tw / 2 + 3, 1, 0x99000000);
            g.drawText(tr, lb.text(), -tw / 2, -9, 0xFF000000 | lb.rgb(), true);
            ms.pop();
        }
        if (!tags.isEmpty()) drawTags(g, mc, w, h);
    }

    private static void drawTags(DrawContext g, MinecraftClient mc, int w, int h) {
        TextRenderer tr = mc.textRenderer;
        // far tags first so near ones are drawn on top
        List<Tag> sorted = new ArrayList<>(tags);
        sorted.sort((a, b) -> Double.compare(b.rel().lengthSquared(), a.rel().lengthSquared()));
        for (Tag t : sorted) {
            float[] p = project(t.rel(), w, h);
            if (p[2] == 0f || p[0] < -80 || p[0] > w + 80 || p[1] < -40 || p[1] > h + 40) continue;
            double dist = t.rel().length();
            float s = t.scale() * MathHelper.clamp(20f / (float) (dist + 8.0), 0.7f, 1.3f);
            int nw = tr.getWidth(t.name()), sw = tr.getWidth(t.suffix());
            int tw = nw + sw;
            MatrixStack ms = g.getMatrices();
            ms.push();
            ms.translate(p[0], p[1], 0f);
            ms.scale(s, s, 1f);
            g.fill(-tw / 2 - 2, -11, tw / 2 + 3, 1, 0x99000000);
            g.drawText(tr, t.name(), -tw / 2, -9, 0xFF000000 | t.nameRgb(), true);
            if (sw > 0) g.drawText(tr, t.suffix(), -tw / 2 + nw, -9, 0xFF000000 | t.suffixRgb(), true);
            int n = t.items().size();
            if (n > 0) {
                int x = -(n * 17) / 2;
                for (ItemStack st : t.items()) {
                    g.drawItem(st, x, -29);
                    // stack count + durability bar, drawn by hand (no dependency on a DrawContext helper)
                    if (st.getCount() > 1) {
                        String cnt = String.valueOf(st.getCount());
                        g.drawText(tr, cnt, x + 17 - tr.getWidth(cnt), -20, 0xFFFFFFFF, true);
                    }
                    if (st.isDamageable() && st.getDamage() > 0) {
                        float frac = 1f - (float) st.getDamage() / st.getMaxDamage();
                        g.fill(x + 2, -16, x + 15, -14, 0xFF000000);
                        g.fill(x + 2, -16, x + 2 + Math.round(13 * frac), -15,
                                0xFF000000 | MathHelper.hsvToRgb(frac / 3f, 1f, 1f));
                    }
                    x += 17;
                }
            }
            ms.pop();
        }
    }

    private static void line(DrawContext g, float x1, float y1, float x2, float y2, int argb, float thickness) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1f) return;
        MatrixStack ms = g.getMatrices();
        ms.push();
        ms.translate(x1, y1, 0f);
        ms.multiply(RotationAxis.POSITIVE_Z.rotation((float) Math.atan2(dy, dx)));
        ms.scale(len, thickness, 1f);
        ms.translate(0f, -0.5f, 0f);
        g.fill(0, 0, 1, 1, argb);
        ms.pop();
    }
}
