package com.astraite.chesthl;

import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Block placing shared by Surround, Auto Trap and Scaffold. */
final class Placer {
    private Placer() {
    }

    private static boolean usable(ClientWorld w, ItemStack st, boolean obsidianOnly, boolean avoidObsidian) {
        if (st.isEmpty() || !(st.getItem() instanceof BlockItem bi)) return false;
        Block b = bi.getBlock();
        if (obsidianOnly) return b == Blocks.OBSIDIAN;
        if (b instanceof FallingBlock || b instanceof BlockEntityProvider || b == Blocks.TNT) return false;
        if (avoidObsidian && (b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN)) return false;
        try {
            return b.getDefaultState().isFullCube(w, BlockPos.ORIGIN);
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Hotbar slot (0-8) to place from, or -1.
     * mode 0 = obsidian only, 1 = any full block (first found), 2 = any full block (biggest stack).
     */
    static int findSlot(ClientPlayerEntity p, ClientWorld w, int mode, boolean preferHeld, boolean avoidObsidian) {
        boolean obsOnly = mode == 0;
        int cur = p.getInventory().selectedSlot;
        if (preferHeld && usable(w, p.getInventory().getStack(cur), obsOnly, avoidObsidian)) return cur;
        int best = -1, bestCount = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!usable(w, st, obsOnly, avoidObsidian)) continue;
            if (mode != 2) return i;
            if (st.getCount() > bestCount) {
                best = i;
                bestCount = st.getCount();
            }
        }
        return best;
    }

    /** A living thing (or crystal) is standing in the spot. */
    static boolean blocked(ClientWorld w, BlockPos pos) {
        for (Entity e : w.getOtherEntities(null, new Box(pos))) {
            if (!e.isAlive()) continue;
            if (e instanceof LivingEntity || e instanceof EndCrystalEntity) return true;
        }
        return false;
    }

    /** The spot is empty / replaceable and nothing stands in it. */
    static boolean canPlace(ClientWorld w, BlockPos pos) {
        if (w.isOutOfHeightLimit(pos)) return false;
        BlockState st = w.getBlockState(pos);
        return (st.isAir() || st.isReplaceable()) && !blocked(w, pos);
    }

    /** Places the held block at pos: against a neighbour if there is one, otherwise air-places. */
    static boolean place(MinecraftClient mc, ClientPlayerEntity p, ClientWorld w, BlockPos pos, boolean rotate, boolean air) {
        BlockHitResult hit = PlaceUtil.hitFor(w, pos);
        if (hit == null) {
            if (!air) return false;
            hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
        }
        if (rotate) face(p, hit.getPos());
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    /** Tells the server we look at the point (silent rotation). */
    static void face(ClientPlayerEntity p, Vec3d pos) {
        Vec3d e = p.getEyePos();
        double dx = pos.x - e.x, dy = pos.y - e.y, dz = pos.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround()));
    }

    /** Sends our real rotation again after silent rotations. */
    static void resync(ClientPlayerEntity p) {
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(p.getYaw(), p.getPitch(), p.isOnGround()));
    }
}
