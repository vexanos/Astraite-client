package com.astraite.chesthl;

import com.astraite.chesthl.api.AstraiteApi;
import com.astraite.chesthl.api.AstraitePlugin;
import com.astraite.chesthl.api.PluginModule;
import com.mojang.logging.LogUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Finds and runs Astraite plugins: other Fabric mods that declare an "astraite" entrypoint
 * (see {@link AstraitePlugin}). Their modules show up in the click GUI next to the built-in ones.
 */
public final class PluginManager {
    private static final Logger LOG = LogUtils.getLogger();

    private static final List<PluginModule> mods = new ArrayList<>();
    private static final List<String> loaded = new ArrayList<>();
    private static final List<Handler<MinecraftClient>> tickHandlers = new ArrayList<>();
    private static final List<Handler<DrawContext>> hudHandlers = new ArrayList<>();
    private static final List<Handler<WorldRenderContext>> worldHandlers = new ArrayList<>();
    private static int ticks = 0;

    private PluginManager() {
    }

    /** A global handler that is dropped after 3 exceptions so a broken plugin can not spam the log / crash. */
    private static final class Handler<T> {
        final String owner;
        final Consumer<T> fn;
        int errors = 0;

        Handler(String owner, Consumer<T> fn) {
            this.owner = owner;
            this.fn = fn;
        }

        void run(T arg) {
            if (errors >= 3) return;
            try {
                fn.accept(arg);
            } catch (Throwable t) {
                errors++;
                LOG.error("[Astraite plugin {}] global handler threw an exception ({}/3)", owner, errors, t);
            }
        }
    }

    // ------------------------------------------------------------------ loading

    /** Called once from ChestHighlightClient after everything else is set up. */
    public static void load() {
        List<EntrypointContainer<AstraitePlugin>> found;
        try {
            found = FabricLoader.getInstance().getEntrypointContainers("astraite", AstraitePlugin.class);
        } catch (Throwable t) {
            LOG.error("[Astraite] could not read plugin entrypoints", t);
            return;
        }
        for (EntrypointContainer<AstraitePlugin> c : found) {
            String id = c.getProvider().getMetadata().getId();
            String ver = c.getProvider().getMetadata().getVersion().getFriendlyString();
            try {
                c.getEntrypoint().onAstraiteLoad(new AstraiteApi(id));
                loaded.add(id + " " + ver);
                LOG.info("[Astraite] loaded plugin {} {}", id, ver);
            } catch (Throwable t) {
                LOG.error("[Astraite] plugin {} failed to load", id, t);
            }
        }
        PluginStore.flush();
    }

    // ------------------------------------------------------------------ registry

    public static PluginModule register(String pluginId, String name, Module.Category cat) {
        Set<String> taken = new HashSet<>();
        for (Module m : Modules.builtin()) taken.add(m.name);
        for (PluginModule pm : mods) taken.add(pm.name());

        String finalName = name;
        if (taken.contains(finalName)) finalName = name + " (" + pluginId + ")";
        int n = 2;
        while (taken.contains(finalName)) finalName = name + " (" + pluginId + " " + n++ + ")";

        PluginModule pm = new PluginModule(pluginId, finalName, cat);
        mods.add(pm);
        return pm;
    }

    /** The GUI entries of all plugin modules (appended to the built-in list). */
    static List<Module> modules() {
        List<Module> l = new ArrayList<>();
        for (PluginModule pm : mods) l.add(pm.guiModule());
        return l;
    }

    public static List<String> allModuleNames() {
        List<String> names = new ArrayList<>();
        for (Module m : Modules.all()) names.add(m.name);
        return names;
    }

    public static boolean isEnabled(String name) {
        for (Module m : Modules.all()) if (m.name.equals(name)) return m.isOn();
        return false;
    }

    public static void setEnabled(String name, boolean on) {
        for (Module m : Modules.all()) {
            if (!m.name.equals(name) || !m.isToggle()) continue;
            if (m.isOn() != on) {
                m.click();
                Config.save();
            }
            return;
        }
    }

    // ------------------------------------------------------------------ global handlers

    public static void addTick(String owner, Consumer<MinecraftClient> h) {
        tickHandlers.add(new Handler<>(owner, h));
    }

    public static void addHud(String owner, Consumer<DrawContext> h) {
        hudHandlers.add(new Handler<>(owner, h));
    }

    public static void addWorld(String owner, Consumer<WorldRenderContext> h) {
        worldHandlers.add(new Handler<>(owner, h));
    }

    // ------------------------------------------------------------------ dispatch (called from ChestHighlightClient)

    public static void tick(MinecraftClient mc) {
        for (PluginModule pm : mods) pm.dispatchTick(mc);
        for (Handler<MinecraftClient> h : tickHandlers) h.run(mc);
        if (++ticks % 40 == 0) PluginStore.flush();
    }

    public static void hud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        for (PluginModule pm : mods) pm.dispatchHud(ctx);
        for (Handler<DrawContext> h : hudHandlers) h.run(ctx);
    }

    public static void worldRender(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        for (PluginModule pm : mods) pm.dispatchWorld(ctx);
        for (Handler<WorldRenderContext> h : worldHandlers) h.run(ctx);
    }

    /** Text next to a plugin module's name in the HUD list, or null. */
    static String info(String moduleName) {
        for (PluginModule pm : mods) {
            if (pm.name().equals(moduleName)) return pm.infoText();
        }
        return null;
    }

    // ------------------------------------------------------------------ drawing helpers for the API

    public static void label(Vec3d worldPos, String text, int rgb, float scale) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        Overlay.addLabel(worldPos.subtract(cam), text, rgb, scale);
    }

    public static void line(Vec3d worldPos, int rgb) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        Overlay.addLine(worldPos.subtract(cam), 0xFF000000 | rgb);
    }

    // ------------------------------------------------------------------ "Plugins" button in the menu

    static void announce() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (loaded.isEmpty()) {
            mc.player.sendMessage(Text.literal("[Astraite] No plugins loaded. Put a plugin mod in your mods folder."), false);
            return;
        }
        mc.player.sendMessage(Text.literal("[Astraite] Plugins (" + loaded.size() + "): " + String.join(", ", loaded)), false);
    }

    static int count() {
        return loaded.size();
    }
}
