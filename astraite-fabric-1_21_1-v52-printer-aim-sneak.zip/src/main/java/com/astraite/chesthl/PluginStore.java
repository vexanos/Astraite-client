package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Saves plugin module state + settings in config/astraite-plugins.json (flat key -> value map). */
public final class PluginStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("astraite-plugins.json");
    private static Map<String, String> data = new LinkedHashMap<>();
    private static boolean dirty = false;
    private static boolean loaded = false;

    private PluginStore() {
    }

    private static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        try {
            if (Files.exists(PATH)) {
                Type t = new TypeToken<Map<String, String>>() {
                }.getType();
                Map<String, String> m = GSON.fromJson(Files.readString(PATH), t);
                if (m != null) data = new LinkedHashMap<>(m);
            }
        } catch (Exception e) {
            // broken file: start fresh, it gets rewritten on the next change
        }
        Runtime.getRuntime().addShutdownHook(new Thread(PluginStore::flush));
    }

    public static boolean getBool(String key, boolean def) {
        ensureLoaded();
        String v = data.get(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    public static int getInt(String key, int def) {
        ensureLoaded();
        String v = data.get(key);
        if (v == null) return def;
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public static void put(String key, String value) {
        ensureLoaded();
        String old = data.put(key, value);
        if (!value.equals(old)) dirty = true;
    }

    public static synchronized void flush() {
        if (!dirty) return;
        dirty = false;
        try {
            Files.writeString(PATH, GSON.toJson(data));
        } catch (IOException e) {
            // ignore, will retry on the next change
        }
    }
}
