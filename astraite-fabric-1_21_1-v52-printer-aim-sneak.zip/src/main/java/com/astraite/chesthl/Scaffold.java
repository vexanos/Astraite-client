package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Scaffold: places a block under your feet (and a bit ahead) while you walk. */
public final class Scaffold {
    public static String status = "";
    private static int cd = 0;

    private Scaffold() {
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.scaffold) {
            status = "";
            return;
        }
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (p.getAbilities().flying || p.isFallFlying() || p.hasVehicle()) return;
        if (cd > 0) {
            cd--;
            return;
        }
        int slot = Placer.findSlot(p, w, 2, Config.scaffoldPreferHeld, Config.scaffoldAvoidObs);
        if (slot < 0) {
            status = "No blocks in hotbar";
            return;
        }

        int by = MathHelper.floor(p.getY()) - 1;
        double x = p.getX(), z = p.getZ();
        List<BlockPos> todo = new ArrayList<>();
        todo.add(new BlockPos(MathHelper.floor(x), by, MathHelper.floor(z)));
        Vec3d vel = p.getVelocity();
        double hs = Math.hypot(vel.x, vel.z);
        if (Config.scaffoldAhead > 0 && hs > 0.03) {
            double dx = vel.x / hs, dz = vel.z / hs;
            for (int k = 1; k <= Config.scaffoldAhead; k++) {
                BlockPos ahead = new BlockPos(MathHelper.floor(x + dx * k), by, MathHelper.floor(z + dz * k));
                if (!todo.contains(ahead)) todo.add(ahead);
            }
        }

        int placed = 0;
        int prev = p.getInventory().selectedSlot;
        boolean switched = false;
        for (BlockPos pos : todo) {
            if (placed >= Config.scaffoldPerTick) break;
            if (!Placer.canPlace(w, pos)) continue;
            if (!switched) {
                p.getInventory().selectedSlot = slot;
                switched = true;
            }
            if (Placer.place(mc, p, w, pos, Config.scaffoldRotate, Config.scaffoldAir)) placed++;
        }
        if (switched) p.getInventory().selectedSlot = prev;
        if (placed > 0) {
            if (Config.scaffoldRotate) Placer.resync(p);
            cd = Config.scaffoldDelay;
            status = "Bridging";
        } else {
            status = "";
        }
    }
}
