package com.astraite.chesthl;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;

/**
 * A loaded schematic (.litematic or Sponge .schem): one palette index per cell, plus rotation / mirror.
 * Cell layout: cells[(y * dz + z) * dx + x], index 0 = air.
 */
final class Schem {
    final String name;
    final int dx, dy, dz;
    final int[] cells;
    final BlockState[] base;
    final BlockState[] states;
    int rot = 0, mir = 0;
    int tdx, tdz;

    private Schem(String name, int dx, int dy, int dz, int[] cells, BlockState[] base) {
        this.name = name;
        this.dx = dx;
        this.dy = dy;
        this.dz = dz;
        this.cells = cells;
        this.base = base;
        this.states = base.clone();
        this.tdx = dx;
        this.tdz = dz;
    }

    /** rot: 0..3 (x 90 degrees clockwise), mir: 0 none, 1 mirror X, 2 mirror Z. */
    void setTransform(int rot, int mir) {
        this.rot = rot;
        this.mir = mir;
        BlockMirror m = mir == 1 ? BlockMirror.FRONT_BACK : (mir == 2 ? BlockMirror.LEFT_RIGHT : BlockMirror.NONE);
        BlockRotation r = rot == 1 ? BlockRotation.CLOCKWISE_90
                : (rot == 2 ? BlockRotation.CLOCKWISE_180
                : (rot == 3 ? BlockRotation.COUNTERCLOCKWISE_90 : BlockRotation.NONE));
        for (int i = 0; i < base.length; i++) states[i] = base[i].mirror(m).rotate(r);
        boolean swap = rot == 1 || rot == 3;
        tdx = swap ? dz : dx;
        tdz = swap ? dx : dz;
    }

    /** State at transformed coordinates (0,0,0 = the min corner of the placed schematic), null for air / outside. */
    BlockState at(int tx, int ty, int tz) {
        if (ty < 0 || ty >= dy || tx < 0 || tx >= tdx || tz < 0 || tz >= tdz) return null;
        int x, z;
        switch (rot) {
            case 1 -> {
                x = tz;
                z = dz - 1 - tx;
            }
            case 2 -> {
                x = dx - 1 - tx;
                z = dz - 1 - tz;
            }
            case 3 -> {
                x = dx - 1 - tz;
                z = tx;
            }
            default -> {
                x = tx;
                z = tz;
            }
        }
        if (mir == 1) x = dx - 1 - x;
        else if (mir == 2) z = dz - 1 - z;
        int idx = cells[(ty * dz + z) * dx + x];
        return idx == 0 ? null : states[idx];
    }

    // ------------------------------------------------------------------ copy from the world / save

    /** Builds a schematic from a region of the (loaded) world. Air stays air. */
    static Schem fromWorld(String name, ClientWorld w, BlockPos p1, BlockPos p2) throws IOException {
        int x0 = Math.min(p1.getX(), p2.getX()), y0 = Math.min(p1.getY(), p2.getY()), z0 = Math.min(p1.getZ(), p2.getZ());
        int dx = Math.abs(p1.getX() - p2.getX()) + 1, dy = Math.abs(p1.getY() - p2.getY()) + 1, dz = Math.abs(p1.getZ() - p2.getZ()) + 1;
        checkSize(dx, dy, dz);
        int[] cells = new int[dx * dy * dz];
        Pal pal = new Pal();
        Map<BlockState, Integer> known = new HashMap<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = 0; y < dy; y++) {
            for (int z = 0; z < dz; z++) {
                for (int x = 0; x < dx; x++) {
                    m.set(x0 + x, y0 + y, z0 + z);
                    BlockState st = w.getBlockState(m);
                    if (st.isAir()) continue;
                    Integer g = known.get(st);
                    if (g == null) {
                        g = pal.add(st);
                        known.put(st, g);
                    }
                    cells[(y * dz + z) * dx + x] = g;
                }
            }
        }
        return new Schem(name, dx, dy, dz, cells, pal.list.toArray(new BlockState[0]));
    }

    int blockCount() {
        int n = 0;
        for (int c : cells) if (c != 0) n++;
        return n;
    }

    private static String stateString(BlockState st) {
        StringBuilder sb = new StringBuilder(Registries.BLOCK.getId(st.getBlock()).toString());
        List<Property<?>> props = new ArrayList<>(st.getProperties());
        if (!props.isEmpty()) {
            props.sort((x, y) -> x.getName().compareTo(y.getName()));
            sb.append('[');
            boolean first = true;
            for (Property<?> p : props) {
                if (!first) sb.append(',');
                first = false;
                sb.append(p.getName()).append('=').append(valueName(st, p));
            }
            sb.append(']');
        }
        return sb.toString();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static String valueName(BlockState st, Property<?> p) {
        return ((Property) p).name(st.get(p));
    }

    /** Writes a Sponge v2 .schem (loadable by this mod and by WorldEdit / Litematica). The untransformed cells are saved. */
    void save(Path file) throws IOException {
        NbtCompound root = new NbtCompound();
        root.putInt("Version", 2);
        root.putInt("DataVersion", 3955); // 1.21.1
        root.putShort("Width", (short) dx);
        root.putShort("Height", (short) dy);
        root.putShort("Length", (short) dz);
        NbtCompound palette = new NbtCompound();
        for (int i = 0; i < base.length; i++) palette.putInt(stateString(base[i]), i);
        root.put("Palette", palette);
        root.putInt("PaletteMax", base.length);
        ByteArrayOutputStream out = new ByteArrayOutputStream(cells.length);
        for (int c : cells) {
            int v = c;
            while ((v & -128) != 0) {
                out.write(v & 127 | 128);
                v >>>= 7;
            }
            out.write(v);
        }
        root.putByteArray("BlockData", out.toByteArray());
        root.putIntArray("Offset", new int[]{0, 0, 0});
        NbtIo.writeCompressed(root, file);
    }

    // ------------------------------------------------------------------ loading

    static Schem load(Path file) throws IOException {
        String fn = file.getFileName().toString();
        Map<String, Object> root;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(Files.newInputStream(file))))) {
            int t = in.readByte();
            in.readUTF();
            root = map(readPayload(in, t));
        }
        if (root == null) throw new IOException("Empty file");
        String lower = fn.toLowerCase(Locale.ROOT);
        String nm = fn.contains(".") ? fn.substring(0, fn.lastIndexOf('.')) : fn;
        if (lower.endsWith(".litematic")) return fromLitematic(nm, root);
        if (lower.endsWith(".schem")) return fromSponge(nm, root);
        throw new IOException("Unsupported file type");
    }

    private static Schem fromLitematic(String name, Map<String, Object> root) throws IOException {
        Map<String, Object> regions = map(root.get("Regions"));
        if (regions == null || regions.isEmpty()) throw new IOException("No regions in schematic");

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (Object ro : regions.values()) {
            Map<String, Object> r = map(ro);
            int[] pos = vec(r.get("Position"));
            int[] size = vec(r.get("Size"));
            int x0 = pos[0] + (size[0] < 0 ? size[0] + 1 : 0);
            int y0 = pos[1] + (size[1] < 0 ? size[1] + 1 : 0);
            int z0 = pos[2] + (size[2] < 0 ? size[2] + 1 : 0);
            minX = Math.min(minX, x0);
            minY = Math.min(minY, y0);
            minZ = Math.min(minZ, z0);
            maxX = Math.max(maxX, x0 + Math.abs(size[0]) - 1);
            maxY = Math.max(maxY, y0 + Math.abs(size[1]) - 1);
            maxZ = Math.max(maxZ, z0 + Math.abs(size[2]) - 1);
        }
        int dx = maxX - minX + 1, dy = maxY - minY + 1, dz = maxZ - minZ + 1;
        checkSize(dx, dy, dz);
        int[] cells = new int[dx * dy * dz];
        Pal pal = new Pal();

        for (Object ro : regions.values()) {
            Map<String, Object> r = map(ro);
            int[] pos = vec(r.get("Position"));
            int[] size = vec(r.get("Size"));
            int sx = Math.abs(size[0]), sy = Math.abs(size[1]), sz = Math.abs(size[2]);
            int x0 = pos[0] + (size[0] < 0 ? size[0] + 1 : 0);
            int y0 = pos[1] + (size[1] < 0 ? size[1] + 1 : 0);
            int z0 = pos[2] + (size[2] < 0 ? size[2] + 1 : 0);

            List<Object> pl = list(r.get("BlockStatePalette"));
            int[] regionMap = new int[pl.size()];
            for (int i = 0; i < pl.size(); i++) {
                Map<String, Object> e = map(pl.get(i));
                String nm = String.valueOf(e.get("Name"));
                Object pr = e.get("Properties");
                regionMap[i] = pal.get(nm, pr == null ? null : map(pr));
            }
            Object bso = r.get("BlockStates");
            if (!(bso instanceof long[] bs)) continue;
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, pl.size() - 1)));
            long mask = (1L << bits) - 1;
            for (int y = 0; y < sy; y++) {
                for (int z = 0; z < sz; z++) {
                    for (int x = 0; x < sx; x++) {
                        long i = ((long) y * sz + z) * sx + x;
                        long start = i * bits;
                        int li = (int) (start >>> 6);
                        int off = (int) (start & 63);
                        if (li >= bs.length) continue;
                        long v = bs[li] >>> off;
                        if (off + bits > 64 && li + 1 < bs.length) v |= bs[li + 1] << (64 - off);
                        int pi = (int) (v & mask);
                        if (pi >= regionMap.length) continue;
                        int g = regionMap[pi];
                        if (g == 0) continue;
                        cells[((y + y0 - minY) * dz + (z + z0 - minZ)) * dx + (x + x0 - minX)] = g;
                    }
                }
            }
        }
        return new Schem(name, dx, dy, dz, cells, pal.list.toArray(new BlockState[0]));
    }

    private static Schem fromSponge(String name, Map<String, Object> root) throws IOException {
        Map<String, Object> s = root.containsKey("Schematic") ? map(root.get("Schematic")) : root;
        int w = num(s.get("Width")), h = num(s.get("Height")), l = num(s.get("Length"));
        Map<String, Object> palette;
        Object dataObj;
        if (s.get("Blocks") != null) {
            Map<String, Object> b = map(s.get("Blocks"));
            palette = map(b.get("Palette"));
            dataObj = b.get("Data");
        } else {
            palette = map(s.get("Palette"));
            dataObj = s.get("BlockData");
        }
        if (palette == null || !(dataObj instanceof byte[] data)) throw new IOException("Not a Sponge schematic");
        checkSize(w, h, l);

        Pal pal = new Pal();
        Map<Integer, Integer> pm = new HashMap<>();
        for (Map.Entry<String, Object> e : palette.entrySet()) {
            String full = e.getKey();
            String nm = full;
            Map<String, Object> props = null;
            int br = full.indexOf('[');
            if (br >= 0 && full.endsWith("]")) {
                nm = full.substring(0, br);
                props = new HashMap<>();
                for (String kv : full.substring(br + 1, full.length() - 1).split(",")) {
                    int eq = kv.indexOf('=');
                    if (eq > 0) props.put(kv.substring(0, eq), kv.substring(eq + 1));
                }
            }
            pm.put(num(e.getValue()), pal.get(nm, props));
        }
        int total = w * h * l;
        int[] cells = new int[total];
        int pos = 0;
        for (int i = 0; i < total && pos < data.length; i++) {
            int v = 0, shift = 0;
            while (pos < data.length) {
                int b = data[pos++];
                v |= (b & 0x7F) << shift;
                if ((b & 0x80) == 0) break;
                shift += 7;
            }
            Integer g = pm.get(v);
            cells[i] = g == null ? 0 : g;
        }
        return new Schem(name, w, h, l, cells, pal.list.toArray(new BlockState[0]));
    }

    private static void checkSize(int dx, int dy, int dz) throws IOException {
        if (dx <= 0 || dy <= 0 || dz <= 0) throw new IOException("Empty schematic");
        if ((long) dx * dy * dz > 40_000_000L) throw new IOException("Schematic is too big");
    }

    // ------------------------------------------------------------------ palette / states

    private static final class Pal {
        final List<BlockState> list = new ArrayList<>();
        final Map<String, Integer> idx = new HashMap<>();

        Pal() {
            list.add(Blocks.AIR.getDefaultState());
            idx.put("minecraft:air", 0);
        }

        int add(BlockState st) {
            list.add(st);
            return list.size() - 1;
        }

        int get(String name, Map<String, Object> props) {
            String key = props == null ? name : name + new TreeMap<>(props);
            Integer i = idx.get(key);
            if (i != null) return i;
            BlockState st = parseState(name, props);
            int n;
            if (st == null || st.isAir()) {
                n = 0;
            } else {
                n = list.size();
                list.add(st);
            }
            idx.put(key, n);
            return n;
        }
    }

    private static BlockState parseState(String name, Map<String, Object> props) {
        Identifier id = Identifier.tryParse(name);
        if (id == null) return null;
        Block b = Registries.BLOCK.get(id);
        if (b == Blocks.AIR && !name.endsWith(":air")) return null; // unknown block
        BlockState st = b.getDefaultState();
        if (props != null) {
            for (Map.Entry<String, Object> e : props.entrySet()) {
                Property<?> pr = b.getStateManager().getProperty(e.getKey());
                if (pr != null) st = withValue(st, pr, String.valueOf(e.getValue()));
            }
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState st, Property<T> prop, String val) {
        Optional<T> o = prop.parse(val);
        return o.isPresent() ? st.with(prop, o.get()) : st;
    }

    // ------------------------------------------------------------------ tiny NBT reader

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    private static List<Object> list(Object o) {
        return o instanceof List ? (List<Object>) o : new ArrayList<>();
    }

    private static int num(Object o) {
        return o instanceof Number n ? n.intValue() : 0;
    }

    private static int[] vec(Object o) {
        Map<String, Object> m = map(o);
        if (m == null) return new int[]{0, 0, 0};
        return new int[]{num(m.get("x")), num(m.get("y")), num(m.get("z"))};
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1:
                return in.readByte();
            case 2:
                return in.readShort();
            case 3:
                return in.readInt();
            case 4:
                return in.readLong();
            case 5:
                return in.readFloat();
            case 6:
                return in.readDouble();
            case 7: {
                byte[] a = new byte[in.readInt()];
                in.readFully(a);
                return a;
            }
            case 8:
                return in.readUTF();
            case 9: {
                int t = in.readByte();
                int n = in.readInt();
                List<Object> l = new ArrayList<>(Math.max(0, Math.min(n, 1 << 16)));
                for (int i = 0; i < n; i++) l.add(readPayload(in, t));
                return l;
            }
            case 10: {
                Map<String, Object> m = new HashMap<>();
                while (true) {
                    int t = in.readByte();
                    if (t == 0) break;
                    String k = in.readUTF();
                    m.put(k, readPayload(in, t));
                }
                return m;
            }
            case 11: {
                int[] a = new int[in.readInt()];
                for (int i = 0; i < a.length; i++) a[i] = in.readInt();
                return a;
            }
            case 12: {
                long[] a = new long[in.readInt()];
                for (int i = 0; i < a.length; i++) a[i] = in.readLong();
                return a;
            }
            default:
                throw new IOException("Bad NBT tag " + type);
        }
    }
}
