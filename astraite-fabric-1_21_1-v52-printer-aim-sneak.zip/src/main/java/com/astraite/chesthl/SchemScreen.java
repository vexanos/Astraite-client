package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Pick a schematic from .minecraft/schematics, set where it goes, rotate / mirror / move it. */
public class SchemScreen extends Screen {
    private static final String[] ROT = {"0", "90", "180", "270"};
    private static final String[] MIR = {"None", "X", "Z"};
    private static int step = 1;

    private final Screen parent;
    private List<String> files = List.of();
    private int page = 0;
    private int perPage = 4;
    private String confirmDelete = null;

    public SchemScreen(Screen parent) {
        super(Text.literal("Schematics"));
        this.parent = parent;
    }

    private int pages() {
        return Math.max(1, (files.size() + perPage - 1) / perPage);
    }

    private static String shorten(String s) {
        return s.length() > 34 ? s.substring(0, 31) + "..." : s;
    }

    @Override
    protected void init() {
        files = Printer.files();
        int bw = 220, rowH = 22, cx = width / 2, left = cx - bw / 2;
        int bottomTop = height - 6 - 5 * rowH;
        int listTop = 26;
        perPage = Math.max(1, (bottomTop - listTop - rowH - 4) / rowH);
        if (page >= pages()) page = pages() - 1;

        String loaded = Printer.loadedName();
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= files.size()) break;
            final String fn = files.get(idx);
            boolean isLoaded = !loaded.isEmpty() && fn.startsWith(loaded + ".");
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(shorten(fn)).formatted(isLoaded ? Formatting.GREEN : Formatting.WHITE), b -> {
                        confirmDelete = null;
                        Printer.load(fn);
                    }).dimensions(left, listTop + i * rowH, bw - 24, 20).build());
            // red X = delete the file (tap twice: the second tap shows "?" and confirms)
            boolean armed = fn.equals(confirmDelete);
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(armed ? "?" : "X").formatted(Formatting.RED), b -> {
                        if (fn.equals(confirmDelete)) {
                            Printer.delete(fn);
                            confirmDelete = null;
                            files = Printer.files();
                        } else {
                            confirmDelete = fn;
                        }
                        clearAndInit();
                    }).dimensions(left + bw - 22, listTop + i * rowH, 22, 20).build());
        }
        int navY = listTop + perPage * rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (page > 0) page--;
            clearAndInit();
        }).dimensions(left, navY, 40, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (page < pages() - 1) page++;
            clearAndInit();
        }).dimensions(left + bw - 40, navY, 40, 20).build());

        int half = (bw - 6) / 2;
        int y = bottomTop;
        addDrawableChild(ButtonWidget.builder(Text.literal("Origin: here"), b -> {
            if (client.player != null) Printer.originHere(client.player);
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Origin: look"), b -> {
            Printer.originLook(client);
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Rotate: " + ROT[Config.prRot]), b -> {
            Config.prRot = (Config.prRot + 1) % 4;
            Config.save();
            clearAndInit();
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Mirror: " + MIR[Config.prMirror]), b -> {
            Config.prMirror = (Config.prMirror + 1) % 3;
            Config.save();
            clearAndInit();
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        String[] lab = {"X-", "X+", "Y-", "Y+", "Z-", "Z+"};
        int[][] dir = {{-1, 0, 0}, {1, 0, 0}, {0, -1, 0}, {0, 1, 0}, {0, 0, -1}, {0, 0, 1}};
        int nw = 34, gap = 3;
        for (int i = 0; i < 6; i++) {
            final int[] d = dir[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(lab[i]), b -> {
                Printer.nudge(d[0] * step, d[1] * step, d[2] * step);
            }).dimensions(left + i * (nw + gap), y, nw, 20).build());
        }

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Materials"), b -> {
            Printer.materials(client);
            close();
        }).dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Unload"), b -> {
            Printer.unload();
            clearAndInit();
        }).dimensions(left + half + 6, y, half, 20).build());

        y += rowH;
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left, y, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Move step: " + step), b -> {
            step = step == 1 ? 8 : (step == 8 ? 32 : 1);
            clearAndInit();
        }).dimensions(left + half + 6, y, half, 20).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xE0101018);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Schematics  (.minecraft/schematics)", width / 2, 8, 0xFFFFFFFF);
        int cx = width / 2;
        int navY = 26 + perPage * 22;
        ctx.drawCenteredTextWithShadow(textRenderer, (page + 1) + "/" + pages(), cx, navY + 6, 0xFFAAAAAA);
        if (files.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Put .litematic / .schem files in the folder", cx, 40, 0xFFFFD700);
        }
        int infoY = height - 6 - 5 * 22 - 11;
        String info = Printer.loadedName().isEmpty() ? "Nothing loaded"
                : Printer.loadedName() + "  @ " + Config.schemOx + ", " + Config.schemOy + ", " + Config.schemOz;
        ctx.drawCenteredTextWithShadow(textRenderer, info, cx, infoY, 0xFFFFFFFF);
        if (confirmDelete != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Tap ? again to DELETE " + shorten(confirmDelete), cx, infoY - 11, 0xFFFF5555);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer, Printer.status, cx, infoY - 11, 0xFFAAAAAA);
        }
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
