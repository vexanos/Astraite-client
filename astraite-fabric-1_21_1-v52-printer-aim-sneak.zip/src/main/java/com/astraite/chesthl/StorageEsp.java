package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.inventory.Inventory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Highlights chests, trapped chests, ender chests, barrels, shulker boxes (and other containers) through walls. */
public final class StorageEsp {
    record Item(BlockPos pos, Box box, int rgb) {
    }

    public static String status = "";
    private static volatile List<Item> items = List.of();
    private static int timer = 10;

    private StorageEsp() {
    }

    static List<Item> items() {
        return items;
    }

    /** -1 = do not show this block entity. */
    private static int colorFor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return Config.storageTrapped ? 0xFF3B30 : -1;
        if (be instanceof ChestBlockEntity) return Config.storageChests ? 0xFFAA00 : -1;
        if (be instanceof EnderChestBlockEntity) return Config.storageEnder ? 0xB44CFF : -1;
        if (be instanceof BarrelBlockEntity) return Config.storageBarrels ? 0xC8883C : -1;
        if (be instanceof ShulkerBoxBlockEntity) return Config.storageShulkers ? 0xFF69B4 : -1;
        if (be instanceof Inventory) return Config.storageOther ? 0xAAAAAA : -1; // hoppers, furnaces, dispensers...
        return -1;
    }

    private static Box boxFor(ClientWorld w, BlockEntity be) {
        BlockPos bp = be.getPos();
        try {
            var shape = be.getCachedState().getOutlineShape(w, bp);
            if (!shape.isEmpty()) return shape.getBoundingBox().offset(bp);
        } catch (Throwable ignored) {
        }
        return new Box(bp);
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.storageEsp || mc.world == null || mc.player == null) {
            if (!items.isEmpty()) items = List.of();
            status = "";
            return;
        }
        if (++timer < 10) return;
        timer = 0;

        ClientWorld w = mc.world;
        BlockPos c = mc.player.getBlockPos();
        int range = Config.storageRange;
        long r2 = (long) range * range;
        int cr = (range >> 4) + 1;
        int pcx = c.getX() >> 4, pcz = c.getZ() >> 4;
        List<Item> out = new ArrayList<>();
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                WorldChunk ch = w.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                if (ch == null) continue;
                for (BlockEntity be : ch.getBlockEntities().values()) {
                    int rgb = colorFor(be);
                    if (rgb < 0) continue;
                    BlockPos bp = be.getPos();
                    long ddx = bp.getX() - c.getX(), ddy = bp.getY() - c.getY(), ddz = bp.getZ() - c.getZ();
                    if (ddx * ddx + ddy * ddy + ddz * ddz > r2) continue;
                    out.add(new Item(bp, boxFor(w, be), rgb));
                    if (out.size() >= 3000) break;
                }
            }
        }
        items = out;
        status = String.valueOf(out.size());
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.storageEsp || mc.world == null || mc.player == null) return;
        List<Item> list = items;
        if (list.isEmpty()) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();
        List<Box> boxes = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        for (Item it : list) {
            boxes.add(it.box().expand(0.01).offset(-cam.x, -cam.y, -cam.z));
            cols.add(it.rgb());
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // visible through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.storageShape != 0 && Config.storageFill > 0) {
            int a = (int) (255 * Config.storageFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.fill(bb, mv, boxes.get(i), (a << 24) | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.storageShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < boxes.size(); i++) EntityEsp.lines(lb, mv, boxes.get(i), 0xFF000000 | cols.get(i));
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
