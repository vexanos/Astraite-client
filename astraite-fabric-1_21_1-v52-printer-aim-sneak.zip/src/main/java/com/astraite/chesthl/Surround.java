package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Surround: keeps blocks (obsidian) around your feet and puts them back when they get broken. */
public final class Surround {
    public static String status = "";
    private static int cd = 0;

    private Surround() {
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.surround) {
            status = "";
            return;
        }
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (cd > 0) {
            cd--;
            return;
        }
        if (!p.isOnGround()) {
            status = "In air";
            return;
        }
        int slot = Placer.findSlot(p, w, Config.surroundBlock == 0 ? 0 : 1, true, false);
        if (slot < 0) {
            status = Config.surroundBlock == 0 ? "No obsidian in hotbar" : "No blocks in hotbar";
            return;
        }

        BlockPos feet = p.getBlockPos();
        Direction[] sides = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};
        List<BlockPos> todo = new ArrayList<>();
        if (Config.surroundUnder) todo.add(feet.down());
        for (Direction d : sides) todo.add(feet.offset(d));
        if (Config.surroundHeight >= 2) {
            for (Direction d : sides) todo.add(feet.up().offset(d));
        }

        Vec3d eye = p.getEyePos();
        int placed = 0, pending = 0;
        int prev = p.getInventory().selectedSlot;
        boolean switched = false;
        for (BlockPos pos : todo) {
            if (!Placer.canPlace(w, pos)) continue; // already filled (or something stands there)
            if (eye.squaredDistanceTo(Vec3d.ofCenter(pos)) > 20.0) continue;
            pending++;
            if (placed >= Config.surroundPerTick) continue;
            if (!switched) {
                p.getInventory().selectedSlot = slot;
                switched = true;
            }
            if (Placer.place(mc, p, w, pos, Config.surroundRotate, Config.surroundAir)) placed++;
        }
        if (switched) p.getInventory().selectedSlot = prev;
        if (placed > 0) {
            if (Config.surroundRotate) Placer.resync(p);
            cd = Config.surroundDelay;
            status = "Placing";
        } else {
            status = pending == 0 ? "Safe" : "Can not place";
        }
    }
}
