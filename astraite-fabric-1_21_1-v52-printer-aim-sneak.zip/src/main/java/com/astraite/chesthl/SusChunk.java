package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Sus Chunk: marks loaded chunks that contain blocks which almost never generate naturally
 * (ender chests, shulkers, hoppers, pistons, redstone parts, glass, beds, furnaces, ...).
 * Every block type adds a weighted score (capped per type so one big cave of torches doesn't
 * trigger it); chunks at or above "Min Score" are boxed through walls.
 */
public final class SusChunk {
    /** A flagged chunk and the vertical span of the suspicious blocks in it. */
    record Hit(int cx, int cz, int minY, int maxY, int score) {
    }

    private static final Map<Block, Integer> WEIGHTS = new IdentityHashMap<>();
    private static final int CAP_PER_TYPE = 4;

    static {
        // strong signs of a player (rarely / never natural)
        w(3, Blocks.ENDER_CHEST, Blocks.BEACON, Blocks.HOPPER, Blocks.DROPPER, Blocks.DISPENSER, Blocks.OBSERVER,
                Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP,
                Blocks.REDSTONE_BLOCK, Blocks.TNT, Blocks.NOTE_BLOCK, Blocks.JUKEBOX, Blocks.ENCHANTING_TABLE,
                Blocks.ANVIL, Blocks.SMITHING_TABLE, Blocks.LODESTONE, Blocks.CONDUIT, Blocks.RESPAWN_ANCHOR,
                Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX,
                Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX,
                Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.LIGHT_GRAY_SHULKER_BOX,
                Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX,
                Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX,
                Blocks.BLACK_SHULKER_BOX, Blocks.NETHERITE_BLOCK, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK,
                Blocks.GOLD_BLOCK, Blocks.IRON_BLOCK, Blocks.SEA_LANTERN, Blocks.GLOWSTONE);
        // medium (can be natural in villages / structures, but a pile of them is a base)
        w(2, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL, Blocks.FURNACE, Blocks.BLAST_FURNACE,
                Blocks.SMOKER, Blocks.CRAFTING_TABLE, Blocks.BOOKSHELF, Blocks.GLASS, Blocks.GLASS_PANE,
                Blocks.WHITE_STAINED_GLASS, Blocks.BLACK_STAINED_GLASS, Blocks.TINTED_GLASS,
                Blocks.WHITE_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.BLACK_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE,
                Blocks.POLISHED_ANDESITE, Blocks.POLISHED_DIORITE, Blocks.POLISHED_GRANITE,
                Blocks.POLISHED_DEEPSLATE, Blocks.POLISHED_BLACKSTONE, Blocks.SMOOTH_STONE, Blocks.COBBLESTONE_STAIRS,
                Blocks.COBBLESTONE_SLAB, Blocks.STONE_BRICKS, Blocks.OBSIDIAN, Blocks.CRYING_OBSIDIAN,
                Blocks.REDSTONE_WIRE, Blocks.REDSTONE_TORCH, Blocks.REDSTONE_WALL_TORCH, Blocks.LEVER,
                Blocks.STONE_BUTTON, Blocks.OAK_PRESSURE_PLATE, Blocks.STONE_PRESSURE_PLATE,
                Blocks.TRIPWIRE_HOOK, Blocks.SLIME_BLOCK, Blocks.HONEY_BLOCK, Blocks.COMPOSTER, Blocks.CAULDRON);
        // weak (torches, beds, ... on their own mean little)
        w(1, Blocks.TORCH, Blocks.WALL_TORCH, Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH, Blocks.LANTERN,
                Blocks.SOUL_LANTERN, Blocks.CAMPFIRE, Blocks.SOUL_CAMPFIRE, Blocks.LADDER, Blocks.WHITE_BED,
                Blocks.RED_BED, Blocks.BLUE_BED, Blocks.BLACK_BED, Blocks.GREEN_BED, Blocks.YELLOW_BED,
                Blocks.OAK_SIGN, Blocks.OAK_WALL_SIGN, Blocks.SPRUCE_SIGN, Blocks.SPRUCE_WALL_SIGN,
                Blocks.BIRCH_SIGN, Blocks.BIRCH_WALL_SIGN, Blocks.OAK_DOOR, Blocks.IRON_DOOR, Blocks.OAK_TRAPDOOR,
                Blocks.IRON_TRAPDOOR, Blocks.OAK_FENCE, Blocks.OAK_FENCE_GATE, Blocks.COBBLESTONE_WALL,
                Blocks.COBBLESTONE, Blocks.OAK_PLANKS, Blocks.SPRUCE_PLANKS, Blocks.OAK_STAIRS, Blocks.OAK_SLAB);
    }

    private static void w(int weight, Block... blocks) {
        for (Block b : blocks) WEIGHTS.put(b, weight);
    }

    public static String status = "";
    private static volatile List<Hit> hits = List.of();
    private static final Set<Long> notified = new HashSet<>();
    private static final AtomicBoolean busy = new AtomicBoolean();
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "astraite-sus-chunk");
        t.setDaemon(true);
        return t;
    });
    private static int timer = 0;
    private static boolean force = false;
    private static ClientWorld lastWorld = null;

    private SusChunk() {
    }

    static List<Hit> hits() {
        return hits;
    }

    /** Called when a setting changed: scan again right away. */
    public static void rescan() {
        force = true;
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.susChunk || mc.world == null || mc.player == null) {
            if (!hits.isEmpty()) hits = List.of();
            if (!notified.isEmpty()) notified.clear();
            status = "";
            lastWorld = null;
            return;
        }
        if (lastWorld != mc.world) { // new world / dimension: forget old results
            lastWorld = mc.world;
            hits = List.of();
            notified.clear();
        }
        if (!force && ++timer < 40) return; // every 2 seconds
        timer = 0;
        force = false;
        if (!busy.compareAndSet(false, true)) return;

        ClientWorld world = mc.world;
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        int range = Config.susRange, min = Config.susMinScore;
        POOL.execute(() -> {
            try {
                List<Hit> r = scan(world, pcx, pcz, range, min);
                MinecraftClient m = MinecraftClient.getInstance();
                if (m.world == world) {
                    hits = r;
                    status = String.valueOf(r.size());
                    m.execute(() -> notifyNew(m, r));
                }
            } catch (Throwable ignored) {
            } finally {
                busy.set(false);
            }
        });
    }

    private static void notifyNew(MinecraftClient mc, List<Hit> list) {
        if (mc.player == null) return;
        for (Hit h : list) {
            long key = ((long) h.cx() << 32) ^ (h.cz() & 0xFFFFFFFFL);
            if (!notified.add(key)) continue;
            if (Config.susNotify) {
                mc.player.sendMessage(Text.literal("[Astraite] Sus chunk (score " + h.score() + ") at "
                        + (h.cx() * 16 + 8) + ", " + (h.cz() * 16 + 8)), false);
            }
        }
    }

    private static List<Hit> scan(ClientWorld world, int pcx, int pcz, int range, int minScore) {
        List<Hit> out = new ArrayList<>();
        for (int dx = -range; dx <= range; dx++) {
            for (int dz = -range; dz <= range; dz++) {
                WorldChunk ch = world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz);
                if (ch == null) continue;
                Hit h = scanChunk(ch, minScore);
                if (h != null) out.add(h);
            }
        }
        return out;
    }

    private static Hit scanChunk(WorldChunk ch, int minScore) {
        Map<Block, Integer> counts = new IdentityHashMap<>();
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        ChunkSection[] secs = ch.getSectionArray();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty()) continue;
            if (!s.hasAny(st -> WEIGHTS.containsKey(st.getBlock()))) continue; // cheap palette check
            int baseY = ch.getBottomY() + (i << 4);
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        Block b = s.getBlockState(x, y, z).getBlock();
                        if (!WEIGHTS.containsKey(b)) continue;
                        counts.merge(b, 1, Integer::sum);
                        int wy = baseY + y;
                        if (wy < minY) minY = wy;
                        if (wy > maxY) maxY = wy;
                    }
                }
            }
        }
        int score = 0;
        for (Map.Entry<Block, Integer> e : counts.entrySet()) {
            score += Math.min(e.getValue(), CAP_PER_TYPE) * WEIGHTS.get(e.getKey());
        }
        if (score < minScore) return null;
        return new Hit(ch.getPos().x, ch.getPos().z, minY, maxY, score);
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.susChunk || mc.world == null || mc.player == null) return;
        List<Hit> list = hits;
        if (list.isEmpty()) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Matrix4f mv = stack.peek().getPositionMatrix();
        int rgb = EntityEsp.COLORS[MathHelper.clamp(Config.susColor, 0, EntityEsp.COLORS.length - 1)];
        List<Box> boxes = new ArrayList<>();
        for (Hit h : list) {
            double y0, y1;
            if (Config.susFullHeight) {
                y0 = mc.world.getBottomY();
                y1 = mc.world.getTopY();
            } else {
                y0 = h.minY();
                y1 = h.maxY() + 1;
            }
            boxes.add(new Box(h.cx() * 16, y0, h.cz() * 16, h.cx() * 16 + 16, y1, h.cz() * 16 + 16)
                    .offset(-cam.x, -cam.y, -cam.z));
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // visible through walls
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.susShape != 0 && Config.susFill > 0) {
            int a = (int) (255 * Config.susFill / 100.0);
            BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Box b : boxes) EntityEsp.fill(bb, mv, b, (a << 24) | rgb);
            BufferRenderer.drawWithGlobalProgram(bb.end());
        }
        if (Config.susShape != 1) {
            BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (Box b : boxes) EntityEsp.lines(lb, mv, b, 0xFF000000 | rgb);
            BufferRenderer.drawWithGlobalProgram(lb.end());
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
