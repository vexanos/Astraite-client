package com.astraite.chesthl;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Tracer lines from the crosshair / bottom / top of the screen to players, mobs, dropped items and ESP blocks. */
public final class Tracers {
    private record Cand(Vec3d rel, int rgb, double d2) {
    }

    private Tracers() {
    }

    /** Runs in WorldRenderEvents.LAST (after Overlay.begin) and hands the end points to the overlay. */
    public static void collect(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.tracers || mc.world == null || mc.player == null) return;
        Vec3d cam = ctx.camera().getPos();
        float delta = mc.getRenderTickCounter().getTickDelta(false);
        double max2 = (double) Config.tracerRange * Config.tracerRange;
        List<Cand> out = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            int rgb;
            if (e instanceof ItemEntity ie) {
                if (!Config.tracerItems) continue;
                rgb = ItemEsp.colorFor(ie.getStack());
            } else if (e instanceof PlayerEntity) {
                if (!Config.tracerPlayers) continue;
                rgb = EntityEsp.groupColor(e);
            } else if (e instanceof LivingEntity) {
                boolean monster = e.getType().getSpawnGroup() == SpawnGroup.MONSTER;
                if (monster ? !Config.tracerMonsters : !Config.tracerAnimals) continue;
                rgb = EntityEsp.groupColor(e);
            } else {
                continue;
            }
            Vec3d rel = e.getLerpedPos(delta).add(0, e.getHeight() / 2.0, 0).subtract(cam);
            double d2 = rel.lengthSquared();
            if (d2 > max2) continue;
            out.add(new Cand(rel, rgb, d2));
        }

        if (Config.tracerBlocks) {
            for (BlockEsp.Hit h : BlockEsp.hits()) {
                BlockPos p = h.pos();
                Vec3d rel = new Vec3d(p.getX() + 0.5 - cam.x, p.getY() + 0.5 - cam.y, p.getZ() + 0.5 - cam.z);
                double d2 = rel.lengthSquared();
                if (d2 > max2) continue;
                out.add(new Cand(rel, h.rgb(), d2));
            }
        }

        if (Config.tracerStorage) {
            for (StorageEsp.Item it : StorageEsp.items()) {
                Vec3d rel = it.box().getCenter().subtract(cam);
                double d2 = rel.lengthSquared();
                if (d2 > max2) continue;
                out.add(new Cand(rel, it.rgb(), d2));
            }
        }

        out.sort(Comparator.comparingDouble(Cand::d2));
        int n = Math.min(out.size(), Config.tracerMax);
        for (int i = 0; i < n; i++) {
            Cand c = out.get(i);
            Overlay.addLine(c.rel(), 0xFF000000 | c.rgb());
        }
    }
}
