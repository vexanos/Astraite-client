package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Trajectories: the path of what you are about to throw / shoot (bow, crossbow, trident, pearls, snowballs, eggs,
 * potions, XP bottles) and of arrows / pearls / potions that are already flying.
 */
public final class Trajectories {
    private static final int RED = 0xFF3B30;
    private static final int GREEN = 0x34D959;

    private record Sim(List<Vec3d> pts, Vec3d end, Entity hit, int rgb, String label) {
    }

    private Trajectories() {
    }

    private static Sim simulate(ClientWorld w, ClientPlayerEntity p, Entity ignore, Vec3d start, Vec3d vel,
                                double gravity, double drag, double waterDrag, int rgb, String label) {
        List<Vec3d> pts = new ArrayList<>();
        pts.add(start);
        List<LivingEntity> ents = w.getEntitiesByClass(LivingEntity.class,
                new Box(start.x - 100, start.y - 100, start.z - 100, start.x + 100, start.y + 100, start.z + 100),
                e -> e != ignore && e.isAlive() && !e.isSpectator());

        Vec3d pos = start, v = vel, end = null;
        Entity hitEnt = null;
        for (int i = 0; i < 300; i++) {
            Vec3d next = pos.add(v);
            BlockHitResult bh = w.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, p));
            boolean blockHit = bh.getType() != HitResult.Type.MISS;
            Vec3d limit = blockHit ? bh.getPos() : next;

            double bestD = Double.MAX_VALUE;
            Vec3d eh = null;
            Entity he = null;
            for (LivingEntity e : ents) {
                Optional<Vec3d> r = e.getBoundingBox().expand(0.3).raycast(pos, limit);
                if (r.isPresent()) {
                    double d = pos.squaredDistanceTo(r.get());
                    if (d < bestD) {
                        bestD = d;
                        eh = r.get();
                        he = e;
                    }
                }
            }
            if (he != null) {
                pts.add(eh);
                end = eh;
                hitEnt = he;
                break;
            }
            if (blockHit) {
                pts.add(bh.getPos());
                end = bh.getPos();
                break;
            }
            pts.add(next);
            pos = next;
            boolean water = w.getFluidState(BlockPos.ofFloored(pos)).isIn(FluidTags.WATER);
            v = v.multiply(water ? waterDrag : drag).subtract(0, gravity, 0);
            if (pos.y < w.getBottomY() - 20) break;
        }
        int col = rgb;
        if (hitEnt == p) col = RED;
        else if (hitEnt != null) col = GREEN;
        return new Sim(pts, end, hitEnt, col, label);
    }

    private static Vec3d launchVel(ClientPlayerEntity p, float delta, float roll, double speed) {
        float yaw = p.getYaw(delta), pitch = p.getPitch(delta);
        double rad = Math.PI / 180.0;
        double vx = -Math.sin(yaw * rad) * Math.cos(pitch * rad);
        double vy = -Math.sin((pitch + roll) * rad);
        double vz = Math.cos(yaw * rad) * Math.cos(pitch * rad);
        Vec3d v = new Vec3d(vx, vy, vz).normalize().multiply(speed);
        Vec3d pv = p.getVelocity();
        return v.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
    }

    /** The path for the stack in hand, or null if it is not something that is thrown / shot right now. */
    private static Sim fromHeld(ClientWorld w, ClientPlayerEntity p, ItemStack st, float delta, int rgb) {
        if (st.isEmpty()) return null;
        float roll = 0f;
        double speed, gravity = 0.03, water = 0.8;
        if (st.isOf(Items.BOW)) {
            if (!p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return null;
            float f = p.getItemUseTime() / 20f;
            f = (f * f + f * 2f) / 3f;
            if (f < 0.1f) return null;
            if (f > 1f) f = 1f;
            speed = f * 3.0;
            gravity = 0.05;
            water = 0.6;
        } else if (st.isOf(Items.CROSSBOW)) {
            if (!CrossbowItem.isCharged(st)) return null;
            speed = 3.15;
            gravity = 0.05;
            water = 0.6;
        } else if (st.isOf(Items.TRIDENT)) {
            if (!p.isUsingItem() || !p.getActiveItem().isOf(Items.TRIDENT)) return null;
            speed = 2.5;
            gravity = 0.05;
            water = 0.99;
        } else if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) {
            speed = 1.5;
        } else if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) {
            speed = 0.5;
            roll = -20f;
            gravity = 0.05;
        } else if (st.isOf(Items.EXPERIENCE_BOTTLE)) {
            speed = 0.7;
            roll = -20f;
            gravity = 0.07;
        } else {
            return null;
        }
        Vec3d lp = p.getLerpedPos(delta);
        Vec3d start = new Vec3d(lp.x, lp.y + p.getEyeHeight(p.getPose()) - 0.1, lp.z);
        Vec3d vel = launchVel(p, delta, roll, speed);
        return simulate(w, p, p, start, vel, gravity, 0.99, water, rgb, "");
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.traj || mc.world == null || mc.player == null) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        Vec3d cam = ctx.camera().getPos();
        float delta = mc.getRenderTickCounter().getTickDelta(false);
        int base = EntityEsp.COLORS[Math.max(0, Math.min(EntityEsp.COLORS.length - 1, Config.trajColor))];

        List<Sim> sims = new ArrayList<>();

        // 1) what you are about to throw / shoot
        if (Config.trajHeld) {
            Sim s = fromHeld(w, p, p.getMainHandStack(), delta, base);
            if (s == null) s = fromHeld(w, p, p.getOffHandStack(), delta, base);
            if (s != null) {
                Vec3d last = s.pts().get(s.pts().size() - 1);
                String lab = String.format(Locale.ROOT, "%.1fm", last.distanceTo(p.getEyePos()));
                sims.add(new Sim(s.pts(), s.end(), s.hit(), s.rgb(), lab));
            }
        }

        // 2) projectiles that are already flying
        if (Config.trajFlying) {
            int count = 0;
            for (Entity e : w.getEntities()) {
                if (count >= 8) break;
                EntityType<?> t = e.getType();
                double gravity, drag = 0.99, water;
                if (t == EntityType.ARROW || t == EntityType.SPECTRAL_ARROW) {
                    gravity = 0.05;
                    water = 0.6;
                } else if (t == EntityType.TRIDENT) {
                    gravity = 0.05;
                    water = 0.99;
                } else if (t == EntityType.ENDER_PEARL) {
                    gravity = 0.03;
                    water = 0.8;
                } else if (t == EntityType.POTION) {
                    gravity = 0.05;
                    water = 0.8;
                } else if (t == EntityType.EXPERIENCE_BOTTLE) {
                    gravity = 0.07;
                    water = 0.8;
                } else {
                    continue;
                }
                Vec3d v = e.getVelocity();
                if (v.lengthSquared() < 0.04) continue; // stuck in the ground
                Vec3d lp = e.getLerpedPos(delta);
                if (lp.squaredDistanceTo(cam) > 120.0 * 120.0) continue;
                Entity owner = e instanceof ProjectileEntity pr ? pr.getOwner() : null;
                String lab = "";
                if (t == EntityType.ENDER_PEARL && owner != null) lab = owner.getName().getString();
                sims.add(simulate(w, p, owner, lp, v, gravity, drag, water, base, lab));
                count++;
            }
        }
        if (sims.isEmpty()) return;

        Matrix4f mv = stack.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        BufferBuilder lb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        boolean any = false;
        for (Sim s : sims) {
            int c = 0xFF000000 | s.rgb();
            List<Vec3d> pts = s.pts();
            for (int i = 1; i < pts.size(); i++) {
                Vec3d a = pts.get(i - 1), b = pts.get(i);
                lb.vertex(mv, (float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z)).color(c);
                lb.vertex(mv, (float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z)).color(c);
                any = true;
            }
            if (s.end() != null && Config.trajMarker) {
                Vec3d e = s.end();
                Box mark = new Box(e.x - 0.2, e.y - 0.2, e.z - 0.2, e.x + 0.2, e.y + 0.2, e.z + 0.2).offset(-cam.x, -cam.y, -cam.z);
                EntityEsp.lines(lb, mv, mark, c);
                any = true;
            }
            if (s.hit() != null) {
                Box hb = s.hit().getBoundingBox().offset(-cam.x, -cam.y, -cam.z);
                EntityEsp.lines(lb, mv, hb, c);
                any = true;
            }
            if (Config.trajLabel && s.end() != null && !s.label().isEmpty()) {
                Overlay.addLabel(new Vec3d(s.end().x - cam.x, s.end().y - cam.y + 0.4, s.end().z - cam.z),
                        s.label(), s.rgb(), 1.0f);
            }
        }
        if (any) BufferRenderer.drawWithGlobalProgram(lb.end());

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
