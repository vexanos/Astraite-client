package com.astraite.chesthl.api;

import com.astraite.chesthl.Module;
import com.astraite.chesthl.PluginManager;
import com.mojang.logging.LogUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.slf4j.Logger;

import java.util.List;
import java.util.function.Consumer;

/** What a plugin gets in {@link AstraitePlugin#onAstraiteLoad}. One instance per plugin. */
public final class AstraiteApi {
    /** Bumped when the API changes in a way that breaks plugins. */
    public static final int API_VERSION = 1;

    private final String pluginId;
    private final Logger log;

    public AstraiteApi(String pluginId) {
        this.pluginId = pluginId;
        this.log = LogUtils.getLogger();
    }

    public String pluginId() {
        return pluginId;
    }

    public Logger log() {
        return log;
    }

    // ------------------------------------------------------------------ modules

    /**
     * Creates a module that shows up in the Astraite click GUI (with keybind + HUD list support).
     * Its on/off state and all its settings are saved automatically in config/astraite-plugins.json.
     */
    public PluginModule module(String name, Module.Category category) {
        return PluginManager.register(pluginId, name, category);
    }

    // ------------------------------------------------------------------ global events (always run)

    /** Runs every client tick, whether or not any of your modules is on. */
    public void onTick(Consumer<MinecraftClient> handler) {
        PluginManager.addTick(pluginId, handler);
    }

    /** Runs every frame while the HUD is drawn. */
    public void onHud(Consumer<DrawContext> handler) {
        PluginManager.addHud(pluginId, handler);
    }

    /** Runs every frame at the end of world rendering (see {@link #worldLabel}/{@link #worldLine}). */
    public void onWorldRender(Consumer<WorldRenderContext> handler) {
        PluginManager.addWorld(pluginId, handler);
    }

    // ------------------------------------------------------------------ drawing helpers (call from a world-render handler)

    /** Draws a text label at a world position (always readable, drawn in 2D). */
    public void worldLabel(Vec3d worldPos, String text, int rgb) {
        PluginManager.label(worldPos, text, rgb, 1.0f);
    }

    /** Draws a tracer line from the crosshair (or screen bottom/top, see the Tracers module) to a world position. */
    public void worldLine(Vec3d worldPos, int rgb) {
        PluginManager.line(worldPos, rgb);
    }

    // ------------------------------------------------------------------ control Astraite's own modules

    /** Names of every module (built-in + plugins). */
    public List<String> moduleNames() {
        return PluginManager.allModuleNames();
    }

    public boolean isEnabled(String moduleName) {
        return PluginManager.isEnabled(moduleName);
    }

    /** Turns any module (built-in or plugin) on or off by its name, e.g. "Kill Aura". */
    public void setEnabled(String moduleName, boolean on) {
        PluginManager.setEnabled(moduleName, on);
    }

    // ------------------------------------------------------------------ misc

    /** Short message above the hotbar. */
    public void notify(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) mc.inGameHud.setOverlayMessage(Text.literal(text), false);
    }

    /** Message in the chat window (only you see it). */
    public void chat(String text) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal(text), false);
    }
}
