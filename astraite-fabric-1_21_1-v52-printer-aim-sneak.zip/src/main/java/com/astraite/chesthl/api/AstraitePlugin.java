package com.astraite.chesthl.api;

/**
 * Entry point of an Astraite plugin (= a second Fabric mod that plugs into Astraite).
 * <p>
 * Register it in your fabric.mod.json under the custom entrypoint key "astraite":
 * <pre>
 * "entrypoints": { "astraite": [ "com.example.myplugin.MyPlugin" ] },
 * "depends": { "chesthl": "*" }
 * </pre>
 */
public interface AstraitePlugin {
    /** Called once when the client starts, after Astraite itself is ready. Create your modules here. */
    void onAstraiteLoad(AstraiteApi api);
}
