package com.astraite.chesthl.api;

import com.astraite.chesthl.Module;
import com.astraite.chesthl.PluginStore;
import com.mojang.logging.LogUtils;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * A module added by a plugin. Build it with {@link AstraiteApi#module}, add settings and handlers:
 * <pre>
 * PluginModule m = api.module("My Module", Module.Category.MISC);
 * PluginModule.BoolValue loud = m.addBool("Loud", false);
 * m.onTick(mc -> { if (loud.get()) ... });
 * </pre>
 * Handlers only run while the module is on. A handler that throws 3 times switches the module off.
 */
public final class PluginModule {
    private static final Logger LOG = LogUtils.getLogger();

    private final String pluginId;
    private final String name;
    private final Module module;
    private final String enabledKey;

    private boolean enabled;
    private boolean started;
    private int errors;
    private Supplier<String> info;

    private final List<Consumer<MinecraftClient>> tick = new ArrayList<>();
    private final List<Consumer<DrawContext>> hud = new ArrayList<>();
    private final List<Consumer<WorldRenderContext>> world = new ArrayList<>();
    private final List<Runnable> enable = new ArrayList<>();
    private final List<Runnable> disable = new ArrayList<>();

    /** Do not call - use {@link AstraiteApi#module}. */
    public PluginModule(String pluginId, String name, Module.Category category) {
        this.pluginId = pluginId;
        this.name = name;
        this.enabledKey = key("enabled");
        this.enabled = PluginStore.getBool(enabledKey, false);
        this.module = Module.toggle(name, category, () -> enabled, this::setEnabled, null);
    }

    private Module.Setting lastSetting() {
        return module.settings.get(module.settings.size() - 1);
    }

    private String key(String setting) {
        return pluginId + "/" + name + "/" + setting;
    }

    // ------------------------------------------------------------------ info

    /** The name shown in the GUI / HUD list (can differ from the requested one if it was already taken). */
    public String name() {
        return name;
    }

    /** The GUI entry (used by Astraite internally). */
    public Module guiModule() {
        return module;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean on) {
        if (on == enabled && (on == started)) return;
        enabled = on;
        PluginStore.put(enabledKey, String.valueOf(on));
        if (on && !started) {
            started = true;
            errors = 0;
            run(enable);
        } else if (!on && started) {
            started = false;
            run(disable);
        }
    }

    /** Text shown next to the module name in the HUD module list (return "" or null for nothing). */
    public PluginModule info(Supplier<String> text) {
        this.info = text;
        return this;
    }

    // ------------------------------------------------------------------ settings

    public BoolValue addBool(String setting, boolean def) {
        BoolValue v = new BoolValue(key(setting), def);
        module.bool(setting, v::get, v::set, null);
        lastSetting().setDefault(def);
        return v;
    }

    public IntValue addInt(String setting, int min, int max, int def) {
        IntValue v = new IntValue(key(setting), min, max, def);
        module.num(setting, min, max, v::get, v::set, null);
        lastSetting().setDefault(def);
        return v;
    }

    /** Decimal slider with a step of 0.1. */
    public DecimalValue addDecimal(String setting, double min, double max, double def) {
        DecimalValue v = new DecimalValue(key(setting), min, max, def);
        module.dec(setting, v.minTenths, v.maxTenths, v::tenths, v::setTenths, null);
        lastSetting().setDefault((int) Math.round(def * 10));
        return v;
    }

    public ChoiceValue addChoice(String setting, String[] options, int def) {
        ChoiceValue v = new ChoiceValue(key(setting), options, def);
        module.choice(setting, options, v::index, v::set);
        lastSetting().setDefault(def);
        return v;
    }

    /** A button row in the module's settings: shows "name: label" and runs something when clicked. */
    public PluginModule addButton(String setting, Supplier<String> label, Runnable action) {
        module.button(setting, label, action);
        return this;
    }

    // ------------------------------------------------------------------ handlers (only run while the module is on)

    public PluginModule onTick(Consumer<MinecraftClient> h) {
        tick.add(h);
        return this;
    }

    public PluginModule onHud(Consumer<DrawContext> h) {
        hud.add(h);
        return this;
    }

    public PluginModule onWorldRender(Consumer<WorldRenderContext> h) {
        world.add(h);
        return this;
    }

    public PluginModule onEnable(Runnable r) {
        enable.add(r);
        return this;
    }

    public PluginModule onDisable(Runnable r) {
        disable.add(r);
        return this;
    }

    // ------------------------------------------------------------------ internal dispatch (called by Astraite)

    public void dispatchTick(MinecraftClient mc) {
        if (!enabled) return;
        if (!started) {
            started = true;
            run(enable);
        }
        for (Consumer<MinecraftClient> h : tick) guard(() -> h.accept(mc));
    }

    public void dispatchHud(DrawContext ctx) {
        if (!enabled) return;
        for (Consumer<DrawContext> h : hud) guard(() -> h.accept(ctx));
    }

    public void dispatchWorld(WorldRenderContext ctx) {
        if (!enabled) return;
        for (Consumer<WorldRenderContext> h : world) guard(() -> h.accept(ctx));
    }

    public String infoText() {
        if (info == null) return null;
        try {
            return info.get();
        } catch (Throwable t) {
            return null;
        }
    }

    private void run(List<Runnable> list) {
        for (Runnable r : list) guard(r);
    }

    private void guard(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            errors++;
            LOG.error("[Astraite plugin {}] module '{}' threw an exception ({}/3)", pluginId, name, errors, t);
            if (errors >= 3) {
                enabled = false;
                started = false;
                PluginStore.put(enabledKey, "false");
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.inGameHud != null) {
                    mc.inGameHud.setOverlayMessage(Text.literal(name + " turned off (plugin error, see log)"), false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ value handles

    public static final class BoolValue {
        private final String key;
        private boolean value;

        BoolValue(String key, boolean def) {
            this.key = key;
            this.value = PluginStore.getBool(key, def);
        }

        public boolean get() {
            return value;
        }

        public void set(boolean v) {
            value = v;
            PluginStore.put(key, String.valueOf(v));
        }
    }

    public static final class IntValue {
        private final String key;
        private final int min, max;
        private int value;

        IntValue(String key, int min, int max, int def) {
            this.key = key;
            this.min = min;
            this.max = max;
            this.value = Math.max(min, Math.min(max, PluginStore.getInt(key, def)));
        }

        public int get() {
            return value;
        }

        public void set(int v) {
            value = Math.max(min, Math.min(max, v));
            PluginStore.put(key, String.valueOf(value));
        }
    }

    public static final class DecimalValue {
        private final String key;
        final int minTenths, maxTenths;
        private int tenths;

        DecimalValue(String key, double min, double max, double def) {
            this.key = key;
            this.minTenths = (int) Math.round(min * 10);
            this.maxTenths = (int) Math.round(max * 10);
            int d = PluginStore.getInt(key, (int) Math.round(def * 10));
            this.tenths = Math.max(minTenths, Math.min(maxTenths, d));
        }

        int tenths() {
            return tenths;
        }

        void setTenths(int v) {
            tenths = Math.max(minTenths, Math.min(maxTenths, v));
            PluginStore.put(key, String.valueOf(tenths));
        }

        public double get() {
            return tenths / 10.0;
        }

        public void set(double v) {
            setTenths((int) Math.round(v * 10));
        }
    }

    public static final class ChoiceValue {
        private final String key;
        private final String[] options;
        private int index;

        ChoiceValue(String key, String[] options, int def) {
            this.key = key;
            this.options = options;
            this.index = Math.max(0, Math.min(options.length - 1, PluginStore.getInt(key, def)));
        }

        public int index() {
            return index;
        }

        /** The selected option text. */
        public String get() {
            return options[index];
        }

        public void set(int i) {
            index = Math.max(0, Math.min(options.length - 1, i));
            PluginStore.put(key, String.valueOf(index));
        }

        public boolean is(String option) {
            return options[index].equalsIgnoreCase(option);
        }
    }
}
