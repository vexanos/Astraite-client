package com.astraite.chesthl.mixin;

import com.astraite.chesthl.ChatTweaks;
import com.astraite.chesthl.Config;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"), cancellable = true)
    private void chesthl_chat(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
        if (ChatTweaks.busy || !Config.chat) return;
        if (ChatTweaks.isSpam(message)) {
            ci.cancel();
            return;
        }
        Text changed = ChatTweaks.modify(message);
        if (changed != message) {
            ci.cancel();
            ChatTweaks.busy = true;
            try {
                ((ChatHud) (Object) this).addMessage(changed, signature, indicator);
            } finally {
                ChatTweaks.busy = false;
            }
        }
    }
}
