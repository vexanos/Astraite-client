package com.astraite.chesthl.mixin;

import com.astraite.chesthl.NewChunks;
import com.astraite.chesthl.TickRate;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onWorldTimeUpdate", at = @At("HEAD"))
    private void chesthl_timeUpdate(WorldTimeUpdateS2CPacket packet, CallbackInfo ci) {
        TickRate.onTimeUpdate();
    }

    @Inject(method = "onBlockUpdate", at = @At("HEAD"))
    private void chesthl_blockUpdate(BlockUpdateS2CPacket packet, CallbackInfo ci) {
        NewChunks.onBlock(packet.getPos(), packet.getState());
    }

    @Inject(method = "onChunkDeltaUpdate", at = @At("HEAD"))
    private void chesthl_deltaUpdate(ChunkDeltaUpdateS2CPacket packet, CallbackInfo ci) {
        packet.visitUpdates(NewChunks::onBlock);
    }
}
