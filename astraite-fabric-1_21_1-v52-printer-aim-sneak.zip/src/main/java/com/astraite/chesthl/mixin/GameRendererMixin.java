package com.astraite.chesthl.mixin;

import com.astraite.chesthl.NoRender;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
    private void chesthl_totem(CallbackInfo ci) {
        if (NoRender.totem()) ci.cancel();
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void chesthl_hurt(CallbackInfo ci) {
        if (NoRender.hurt()) ci.cancel();
    }
}
