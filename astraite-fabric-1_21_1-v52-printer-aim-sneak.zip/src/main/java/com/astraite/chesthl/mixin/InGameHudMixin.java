package com.astraite.chesthl.mixin;

import com.astraite.chesthl.NoRender;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
    private void chesthl_vignette(CallbackInfo ci) {
        if (NoRender.vignette()) ci.cancel();
    }

    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void chesthl_overlay(DrawContext context, Identifier texture, float opacity, CallbackInfo ci) {
        if (NoRender.pumpkin() && texture.getPath().contains("pumpkinblur")) ci.cancel();
    }
}
