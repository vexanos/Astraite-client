package com.astraite.chesthl;

import com.astraite.chesthl.mixin.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;

public final class AccountManager {
    // The account the launcher started the game with. Kept in memory only, never saved to disk.
    private static Session official;
    private static boolean applied = false;

    public static boolean validName(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    public static void tick(MinecraftClient mc) {
        if (official == null) official = mc.getSession();
        if (!applied) {
            applied = true;
            if (Config.accountMode == 1 && validName(Config.localName)) useLocal(mc, Config.localName);
        }
    }

    public static void useLocal(MinecraftClient mc, String name) {
        UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        Session s = new Session(name, id, "", Optional.empty(), Optional.empty(), Session.AccountType.MOJANG);
        ((MinecraftClientAccessor) mc).chesthl_setSession(s);
        Config.accountMode = 1;
        Config.localName = name;
        Config.save();
    }

    public static boolean useOfficial(MinecraftClient mc) {
        if (official == null) return false;
        ((MinecraftClientAccessor) mc).chesthl_setSession(official);
        Config.accountMode = 0;
        Config.save();
        return true;
    }
}
