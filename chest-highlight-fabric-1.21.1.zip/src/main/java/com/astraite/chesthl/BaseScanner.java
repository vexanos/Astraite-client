package com.astraite.chesthl;

import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.AnvilBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CakeBlock;
import net.minecraft.block.CandleCakeBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FlowerPotBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class BaseScanner {
    public static final int N = 33;
    public static final int BLOCK_TYPES = 28; // 0..27 are blocks, 28..32 are entities

    public static final String[] NAMES = {
            "Furnace", "Blast Furnace", "Smoker", "Campfire", "Soul Campfire",
            "Cauldron", "Water Cauldron", "Barrel", "Composter", "Cake",
            "Flower Pot", "Ench. Table", "Bookshelf", "Anvil", "Grindstone",
            "Smithing Table", "Cartography", "Brewing Stand", "Ender Chest", "Chest",
            "Trapped Chest", "Shulker Box", "Hopper", "Sign", "Cactus",
            "Glowstone", "Sugar Cane", "Fence", "Painting", "Item Frame",
            "Glow Frame", "Armor Stand", "Chest Minecart"
    };

    public static final int[] COLORS = {
            0xFFFF9F43, 0xFFFF6B35, 0xFFE17055, 0xFFFF5252, 0xFF48DBFB,
            0xFF95A5A6, 0xFF3498DB, 0xFFC08040, 0xFF2ECC71, 0xFFFF9FF3,
            0xFFFF6B81, 0xFFA55EEA, 0xFFB8860B, 0xFF7F8C8D, 0xFFBDC3C7,
            0xFF576574, 0xFF8395A7, 0xFFFDCB6E, 0xFFB44CFF, 0xFFFFA500,
            0xFFFF3B30, 0xFFFF69B4, 0xFFDFE6E9, 0xFFFFEAA7, 0xFF00B894,
            0xFFFFD32A, 0xFF7BED9F, 0xFFCD853F, 0xFF00CEC9, 0xFFE84393,
            0xFF55EFC4, 0xFFFAB1A0, 0xFFFFDD59
    };

    public record Hit(Box box, int type) {}

    public static volatile List<Hit> cache = new ArrayList<>();

    private static final Map<Block, Integer> CLASS_CACHE = new HashMap<>();
    private static final int MAX_HITS = 6000;
    private static int ticks = 30;

    private static int classify(Block b) {
        if (b == Blocks.FURNACE) return 0;
        if (b == Blocks.BLAST_FURNACE) return 1;
        if (b == Blocks.SMOKER) return 2;
        if (b == Blocks.CAMPFIRE) return 3;
        if (b == Blocks.SOUL_CAMPFIRE) return 4;
        if (b == Blocks.CAULDRON || b == Blocks.LAVA_CAULDRON || b == Blocks.POWDER_SNOW_CAULDRON) return 5;
        if (b == Blocks.WATER_CAULDRON) return 6;
        if (b == Blocks.BARREL) return 7;
        if (b == Blocks.COMPOSTER) return 8;
        if (b instanceof CakeBlock || b instanceof CandleCakeBlock) return 9;
        if (b instanceof FlowerPotBlock) return 10;
        if (b == Blocks.ENCHANTING_TABLE) return 11;
        if (b == Blocks.BOOKSHELF) return 12;
        if (b instanceof AnvilBlock) return 13;
        if (b == Blocks.GRINDSTONE) return 14;
        if (b == Blocks.SMITHING_TABLE) return 15;
        if (b == Blocks.CARTOGRAPHY_TABLE) return 16;
        if (b == Blocks.BREWING_STAND) return 17;
        if (b == Blocks.ENDER_CHEST) return 18;
        if (b == Blocks.CHEST) return 19;
        if (b == Blocks.TRAPPED_CHEST) return 20;
        if (b instanceof ShulkerBoxBlock) return 21;
        if (b == Blocks.HOPPER) return 22;
        if (b instanceof AbstractSignBlock) return 23;
        if (b == Blocks.CACTUS) return 24;
        if (b == Blocks.GLOWSTONE) return 25;
        if (b == Blocks.SUGAR_CANE) return 26;
        if (b instanceof FenceBlock) return 27;
        return -1;
    }

    private static int typeOf(BlockState s) {
        return CLASS_CACHE.computeIfAbsent(s.getBlock(), BaseScanner::classify);
    }

    private static boolean isWanted(BlockState s) {
        int t = typeOf(s);
        return t >= 0 && t < BLOCK_TYPES && Config.baseTypes[t];
    }

    public static void rescan() {
        ticks = 30;
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.enabled || mc.world == null || mc.player == null
                || (!mc.isInSingleplayer() && !Config.allowMultiplayer)) {
            if (!cache.isEmpty()) cache = new ArrayList<>();
            return;
        }
        if (++ticks < 30) return;
        ticks = 0;
        scan(mc);
    }

    private static void scan(MinecraftClient mc) {
        ClientWorld w = mc.world;
        int range = Config.range;
        double r2 = (double) range * range;
        Vec3d pp = mc.player.getPos();
        BlockPos pb = mc.player.getBlockPos();
        int minX = pb.getX() - range, maxX = pb.getX() + range;
        int minY = pb.getY() - range, maxY = pb.getY() + range;
        int minZ = pb.getZ() - range, maxZ = pb.getZ() + range;

        List<Hit> out = new ArrayList<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                WorldChunk chunk = w.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection s = sections[i];
                    if (s == null || s.isEmpty()) continue;
                    int baseY = (w.getBottomSectionCoord() + i) << 4;
                    if (baseY + 15 < minY || baseY > maxY) continue;
                    if (!s.hasAny(BaseScanner::isWanted)) continue;
                    for (int x = 0; x < 16; x++) {
                        int wx = (cx << 4) + x;
                        if (wx < minX || wx > maxX) continue;
                        double dx = wx + 0.5 - pp.x;
                        for (int z = 0; z < 16; z++) {
                            int wz = (cz << 4) + z;
                            if (wz < minZ || wz > maxZ) continue;
                            double dz = wz + 0.5 - pp.z;
                            for (int y = 0; y < 16; y++) {
                                int wy = baseY + y;
                                if (wy < minY || wy > maxY) continue;
                                double dy = wy + 0.5 - pp.y;
                                if (dx * dx + dy * dy + dz * dz > r2) continue;
                                BlockState st = s.getBlockState(x, y, z);
                                int t = typeOf(st);
                                if (t < 0 || t >= BLOCK_TYPES || !Config.baseTypes[t]) continue;
                                BlockPos pos = new BlockPos(wx, wy, wz);
                                VoxelShape shape = st.getOutlineShape(w, pos);
                                Box box = shape.isEmpty() ? new Box(pos) : shape.getBoundingBox().offset(pos);
                                out.add(new Hit(box, t));
                                if (out.size() >= MAX_HITS) {
                                    cache = out;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
        cache = out;
    }
}
