package com.astraite.chesthl;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ChestHighlightClient implements ClientModInitializer {
    public static KeyBinding openKey;
    public static boolean pendingOpen = false;

    @Override
    public void onInitializeClient() {
        Config.load();
        AccountManager.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chesthl.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.chesthl"));

        // /chesthl opens the menu (useful on mobile where keybinds are awkward)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("chesthl").executes(ctx -> {
                    pendingOpen = true;
                    return 1;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) pendingOpen = true;
            OreScanner.tick(client);
            AccountManager.tick(client);
            if (pendingOpen && client.player != null && client.currentScreen == null) {
                pendingOpen = false;
                client.setScreen(new ConfigScreen(null));
            }
        });

        WorldRenderEvents.LAST.register(ChestRenderer::render);

        // Button on the title screen so the menu (and account switch) is reachable outside a world
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Chest HL"),
                        b -> client.setScreen(new ConfigScreen(screen))).dimensions(4, 4, 70, 20).build());
            }
        });
    }
}
