package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public final class ChestRenderer {
    public static final String[] NAMES = {"Chest", "Trapped Chest", "Ender Chest", "Barrel", "Shulker Box"};
    private static final int[] COLORS = {0xFFFFA500, 0xFFFF3B30, 0xFFB44CFF, 0xFFC08040, 0xFFFF69B4};

    private record Target(Box box, int color) {}

    private static int typeOf(BlockEntity be) {
        if (be instanceof ChestBlockEntity) {
            return be.getCachedState().isOf(Blocks.TRAPPED_CHEST) ? 1 : 0;
        }
        if (be instanceof EnderChestBlockEntity) return 2;
        if (be instanceof BarrelBlockEntity) return 3;
        if (be instanceof ShulkerBoxBlockEntity) return 4;
        return -1;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.enabled || mc.world == null || mc.player == null || (!mc.isInSingleplayer() && !Config.allowMultiplayer)) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Vec3d pp = mc.player.getPos();
        double r2 = (double) Config.range * Config.range;
        int cr = (Config.range >> 4) + 1;
        ChunkPos pc = mc.player.getChunkPos();

        List<Target> targets = new ArrayList<>();
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(pc.x + dx, pc.z + dz);
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    int t = typeOf(be);
                    if (t < 0 || !Config.types[t]) continue;
                    BlockPos p = be.getPos();
                    double ox = p.getX() + 0.5 - pp.x;
                    double oy = p.getY() + 0.5 - pp.y;
                    double oz = p.getZ() + 0.5 - pp.z;
                    if (ox * ox + oy * oy + oz * oz > r2) continue;
                    VoxelShape shape = be.getCachedState().getOutlineShape(mc.world, p);
                    Box b = shape.isEmpty() ? new Box(p) : shape.getBoundingBox().offset(p);
                    b = b.expand(0.002).offset(-cam.x, -cam.y, -cam.z);
                    targets.add(new Target(b, COLORS[t]));
                }
            }
        }
        if (targets.isEmpty()) return;

        Matrix4f m = stack.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        if (Config.throughWalls) RenderSystem.disableDepthTest();
        else RenderSystem.enableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.fill) {
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Target t : targets) fill(b, m, t.box(), (70 << 24) | (t.color() & 0xFFFFFF));
            BufferRenderer.drawWithGlobalProgram(b.end());
        }

        BufferBuilder l = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Target t : targets) lines(l, m, t.box(), t.color());
        BufferRenderer.drawWithGlobalProgram(l.end());

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int c) {
        b.vertex(m, (float) x, (float) y, (float) z).color(c);
    }

    private static void fill(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        v(b, m, x0, y0, z0, c); v(b, m, x1, y0, z0, c); v(b, m, x1, y0, z1, c); v(b, m, x0, y0, z1, c);
        v(b, m, x0, y1, z0, c); v(b, m, x0, y1, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z0, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y1, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y0, z0, c);
        v(b, m, x0, y0, z1, c); v(b, m, x1, y0, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x0, y1, z1, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y0, z1, c); v(b, m, x0, y1, z1, c); v(b, m, x0, y1, z0, c);
        v(b, m, x1, y0, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y0, z1, c);
    }

    private static void edge(BufferBuilder b, Matrix4f m, double ax, double ay, double az,
                             double bx, double by, double bz, int c) {
        v(b, m, ax, ay, az, c);
        v(b, m, bx, by, bz, c);
    }

    private static void lines(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        edge(b, m, x0, y0, z0, x1, y0, z0, c);
        edge(b, m, x1, y0, z0, x1, y0, z1, c);
        edge(b, m, x1, y0, z1, x0, y0, z1, c);
        edge(b, m, x0, y0, z1, x0, y0, z0, c);
        edge(b, m, x0, y1, z0, x1, y1, z0, c);
        edge(b, m, x1, y1, z0, x1, y1, z1, c);
        edge(b, m, x1, y1, z1, x0, y1, z1, c);
        edge(b, m, x0, y1, z1, x0, y1, z0, c);
        edge(b, m, x0, y0, z0, x0, y1, z0, c);
        edge(b, m, x1, y0, z0, x1, y1, z0, c);
        edge(b, m, x1, y0, z1, x1, y1, z1, c);
        edge(b, m, x0, y0, z1, x0, y1, z1, c);
    }
}
