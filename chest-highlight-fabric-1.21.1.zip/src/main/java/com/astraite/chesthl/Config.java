package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    public static boolean enabled = true;
    public static boolean throughWalls = true;
    public static boolean fill = true;
    public static boolean allowMultiplayer = false;
    public static int range = 64;
    public static boolean oreEnabled = false;
    public static int accountMode = 0; // 0 official, 1 local
    public static String localName = "Player";
    public static int oreRange = 24;
    // 0 coal,1 iron,2 copper,3 gold,4 redstone,5 lapis,6 diamond,7 emerald,8 debris,9 quartz
    public static boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};
    // 0 chest, 1 trapped chest, 2 ender chest, 3 barrel, 4 shulker box
    public static boolean[] types = {true, true, true, true, true};

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl.json");

    private static class Data {
        boolean enabled = true;
        boolean throughWalls = true;
        boolean fill = true;
        boolean allowMultiplayer = false;
        int range = 64;
        boolean oreEnabled = false;
        int accountMode = 0;
        String localName = "Player";
        int oreRange = 24;
        boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};
        boolean[] types = {true, true, true, true, true};
    }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            enabled = d.enabled;
            throughWalls = d.throughWalls;
            fill = d.fill;
            allowMultiplayer = d.allowMultiplayer;
            range = Math.max(16, Math.min(128, d.range));
            if (d.types != null && d.types.length == 5) types = d.types;
            oreEnabled = d.oreEnabled;
            accountMode = d.accountMode == 1 ? 1 : 0;
            if (d.localName != null) localName = d.localName;
            oreRange = Math.max(8, Math.min(48, d.oreRange));
            if (d.oreTypes != null && d.oreTypes.length == 10) oreTypes = d.oreTypes;
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.throughWalls = throughWalls;
            d.fill = fill;
            d.allowMultiplayer = allowMultiplayer;
            d.range = range;
            d.types = types;
            d.oreEnabled = oreEnabled;
            d.accountMode = accountMode;
            d.localName = localName;
            d.oreRange = oreRange;
            d.oreTypes = oreTypes;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }
}
