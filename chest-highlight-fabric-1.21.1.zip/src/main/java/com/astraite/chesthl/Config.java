package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class Config {
    public static boolean enabled = true;
    public static boolean throughWalls = true;
    public static boolean fill = true;
    public static int range = 64;
    public static boolean[] baseTypes = defaultBase();
    public static boolean oreEnabled = false;
    public static int oreRange = 24;
    // 0 coal,1 iron,2 copper,3 gold,4 redstone,5 lapis,6 diamond,7 emerald,8 debris,9 quartz
    public static boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl.json");

    // Noisy / natural blocks start OFF: flower pot, cactus, glowstone, sugar cane, fence
    static boolean[] defaultBase() {
        boolean[] a = new boolean[BaseScanner.N];
        Arrays.fill(a, true);
        a[10] = false;
        a[24] = false;
        a[25] = false;
        a[26] = false;
        a[27] = false;
        a[36] = false; // passive mobs
        a[37] = false; // other mobs
        a[38] = false; // projectiles
        a[39] = false; // xp orbs
        a[41] = false; // boats / minecarts
        return a;
    }

    private static class Data {
        boolean enabled = true;
        boolean throughWalls = true;
        boolean fill = true;
        int range = 64;
        boolean[] baseTypes = defaultBase();
        boolean oreEnabled = false;
        int oreRange = 24;
        boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};
    }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            enabled = d.enabled;
            throughWalls = d.throughWalls;
            fill = d.fill;
            range = Math.max(16, Math.min(128, d.range));
            if (d.baseTypes != null && d.baseTypes.length == BaseScanner.N) baseTypes = d.baseTypes;
            oreEnabled = d.oreEnabled;
            oreRange = Math.max(8, Math.min(48, d.oreRange));
            if (d.oreTypes != null && d.oreTypes.length == 10) oreTypes = d.oreTypes;
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.throughWalls = throughWalls;
            d.fill = fill;
            d.range = range;
            d.baseTypes = baseTypes;
            d.oreEnabled = oreEnabled;
            d.oreRange = oreRange;
            d.oreTypes = oreTypes;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }
}
