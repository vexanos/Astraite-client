package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.function.BooleanSupplier;

public class ConfigScreen extends Screen {
    private static final int PER_PAGE = 3;
    private static final int BASE_PER_PAGE = 10;

    private final Screen parent;
    private int left, panelTop, cy;
    private int page = 0; // 0 = base, 1 = ores, 2 = account
    private int basePage = 0;
    private int accountPage = 0;
    private String nameValue = "";
    private int seenVersion = AccountManager.version;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Base Finder"));
        this.parent = parent;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private static Text colored(String name, boolean on) {
        return Text.literal(name).formatted(on ? Formatting.GREEN : Formatting.RED);
    }

    private ButtonWidget toggle(String name, boolean current, int x, int y, int w, Runnable flip, BooleanSupplier get) {
        return ButtonWidget.builder(label(name, current), b -> {
            flip.run();
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
    }

    @Override
    protected void init() {
        left = width / 2 - 156;
        panelTop = Math.max(2, height / 2 - 107);
        cy = panelTop + 46;
        int tabY = panelTop + 20;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Base").formatted(page == 0 ? Formatting.GOLD : Formatting.WHITE), b -> {
                    page = 0;
                    clearAndInit();
                }).dimensions(left, tabY, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Ores").formatted(page == 1 ? Formatting.GOLD : Formatting.WHITE), b -> {
                    page = 1;
                    clearAndInit();
                }).dimensions(left + 106, tabY, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Account").formatted(page == 2 ? Formatting.GOLD : Formatting.WHITE), b -> {
                    page = 2;
                    clearAndInit();
                }).dimensions(left + 212, tabY, 100, 20).build());

        if (page == 0) initBase();
        else if (page == 1) initOres();
        else initAccount();

        if (page == 1) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                    .dimensions(left + 81, cy + 114, 150, 20).build());
        }
    }

    // ---------------- Base tab ----------------
    private int basePages() {
        return (BaseScanner.N + BASE_PER_PAGE - 1) / BASE_PER_PAGE;
    }

    private Text baseName(int idx) {
        return colored(BaseScanner.NAMES[idx], Config.baseTypes[idx]);
    }

    private void initBase() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Enabled", Config.enabled, left, cy, lw,
                () -> {
                    Config.enabled = !Config.enabled;
                    BaseScanner.rescan();
                }, () -> Config.enabled));
        addDrawableChild(toggle("Walls", Config.throughWalls, left, cy + 22, lw,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 44, lw,
                () -> Config.fill = !Config.fill, () -> Config.fill));
        addDrawableChild(new RangeSlider(left, cy + 66, lw, 20));
        addDrawableChild(ButtonWidget.builder(colored("Multiplayer", Config.allowMultiplayer), b -> {
            Config.allowMultiplayer = !Config.allowMultiplayer;
            b.setMessage(colored("Multiplayer", Config.allowMultiplayer));
            BaseScanner.rescan();
            OreScanner.rescan();
        }).dimensions(left, cy + 88, lw, 20).build());

        for (int i = 0; i < BASE_PER_PAGE; i++) {
            final int idx = basePage * BASE_PER_PAGE + i;
            if (idx >= BaseScanner.N) break;
            int col = i / 5;
            int row = i % 5;
            addDrawableChild(ButtonWidget.builder(baseName(idx), b -> {
                Config.baseTypes[idx] = !Config.baseTypes[idx];
                b.setMessage(baseName(idx));
                BaseScanner.rescan();
            }).dimensions(left + 108 + col * 104, cy + row * 22, cw, 20).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (basePage > 0) basePage--;
            clearAndInit();
        }).dimensions(left, cy + 114, 40, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 106, cy + 114, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (basePage < basePages() - 1) basePage++;
            clearAndInit();
        }).dimensions(left + 272, cy + 114, 40, 20).build());
    }

    // ---------------- Ores tab ----------------
    private void initOres() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Ore ESP", Config.oreEnabled, left, cy, lw,
                () -> {
                    Config.oreEnabled = !Config.oreEnabled;
                    OreScanner.rescan();
                }, () -> Config.oreEnabled));
        addDrawableChild(new OreRangeSlider(left, cy + 22, lw, 20));
        addDrawableChild(toggle("Walls", Config.throughWalls, left, cy + 44, lw,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 66, lw,
                () -> Config.fill = !Config.fill, () -> Config.fill));

        for (int i = 0; i < 10; i++) {
            final int idx = i;
            int col = i < 5 ? 0 : 1;
            int row = i % 5;
            addDrawableChild(toggle(OreScanner.NAMES[i], Config.oreTypes[i], left + 108 + col * 104, cy + row * 22, cw,
                    () -> {
                        Config.oreTypes[idx] = !Config.oreTypes[idx];
                        OreScanner.rescan();
                    }, () -> Config.oreTypes[idx]));
        }
    }

    // ---------------- Account tab ----------------
    private int totalPages() {
        return Math.max(1, (AccountManager.accounts.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private void initAccount() {
        boolean launcherActive = AccountManager.active.isEmpty();
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Launcher account").formatted(launcherActive ? Formatting.GREEN : Formatting.WHITE)
                        .append(Text.literal(" [Official]").formatted(Formatting.GRAY)), b -> {
                    AccountManager.useOfficial(client);
                    clearAndInit();
                }).dimensions(left, cy + 14, 312, 18).build());

        if (accountPage >= totalPages()) accountPage = totalPages() - 1;
        List<AccountManager.Account> list = AccountManager.accounts;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = accountPage * PER_PAGE + i;
            if (idx >= list.size()) break;
            final AccountManager.Account a = list.get(idx);
            boolean isActive = a.key().equals(AccountManager.active);
            int y = cy + 34 + i * 20;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(a.name).formatted(isActive ? Formatting.GREEN : Formatting.WHITE)
                            .append(Text.literal(a.isPremium() ? " [Premium]" : " [Cracked]").formatted(Formatting.GRAY)), b -> {
                        AccountManager.switchTo(client, a);
                        clearAndInit();
                    }).dimensions(left, y, 240, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Remove").formatted(Formatting.RED), b -> {
                AccountManager.remove(client, a);
                clearAndInit();
            }).dimensions(left + 244, y, 68, 18).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (accountPage > 0) accountPage--;
            clearAndInit();
        }).dimensions(left, cy + 96, 40, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 106, cy + 96, 100, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (accountPage < totalPages() - 1) accountPage++;
            clearAndInit();
        }).dimensions(left + 272, cy + 96, 40, 18).build());

        TextFieldWidget field = new TextFieldWidget(textRenderer, left, cy + 118, 150, 18, Text.literal("Cracked username"));
        field.setMaxLength(16);
        field.setText(nameValue);
        field.setChangedListener(s -> nameValue = s);
        addDrawableChild(field);

        addDrawableChild(ButtonWidget.builder(Text.literal("Add cracked"), b -> {
            String n = nameValue.trim();
            if (!AccountManager.validName(n)) {
                AccountManager.status = "Naam 3 se 16 letters/numbers/_ ka hona chahiye";
                AccountManager.version++;
                return;
            }
            nameValue = "";
            AccountManager.addCracked(client, n);
            clearAndInit();
        }).dimensions(left + 154, cy + 118, 78, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Add premium"), b -> {
            AccountManager.beginPremiumLogin(client);
            clearAndInit();
        }).dimensions(left + 236, cy + 118, 76, 18).build());
    }

    @Override
    public void tick() {
        if (seenVersion != AccountManager.version) {
            seenVersion = AccountManager.version;
            if (page == 2) clearAndInit();
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        ctx.fill(left - 10, panelTop, left + 322, page == 2 ? cy + 166 : cy + 150, 0xF0101014);
        ctx.fill(left - 10, panelTop, left + 322, panelTop + 2, 0xFFFFA500);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, panelTop + 7, 0xFFFFFF);
        if (page == 2) {
            String cur = client.getSession().getUsername();
            ctx.drawTextWithShadow(textRenderer, Text.literal("Current: " + cur), left, cy + 3, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, Text.literal((accountPage + 1) + "/" + totalPages()),
                    left + 46, cy + 101, 0xAAAAAA);
            ctx.drawTextWithShadow(textRenderer, Text.literal(AccountManager.status), left, cy + 142, 0xFFFFFF);
            if (!AccountManager.deviceCode.isEmpty()) {
                String url = AccountManager.deviceUrl.replace("https://", "");
                ctx.drawTextWithShadow(textRenderer,
                        Text.literal("Link: " + url + "   Code: " + AccountManager.deviceCode),
                        left, cy + 154, 0xFFD700);
            }
        } else {
            if (page == 0) {
                ctx.drawTextWithShadow(textRenderer, Text.literal((basePage + 1) + "/" + basePages()),
                        left + 46, cy + 120, 0xAAAAAA);
            }
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Multiplayer: only on private servers"),
                    width / 2, cy + 138, 0x888888);
        }
    }

    @Override
    public void removed() {
        Config.save();
        OreScanner.rescan();
        BaseScanner.rescan();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.range - 16) / 80.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (16 + (int) Math.round(value * 80))));
        }

        @Override
        protected void applyValue() {
            Config.range = 16 + (int) Math.round(value * 80);
            BaseScanner.rescan();
        }
    }

    private static class OreRangeSlider extends SliderWidget {
        OreRangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.oreRange - 8) / 40.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (8 + (int) Math.round(value * 40))));
        }

        @Override
        protected void applyValue() {
            Config.oreRange = 8 + (int) Math.round(value * 40);
            OreScanner.rescan();
        }
    }
}
