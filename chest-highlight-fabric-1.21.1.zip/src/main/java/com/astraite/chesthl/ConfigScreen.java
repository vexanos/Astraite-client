package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private int left, panelTop, cy;
    private int page = 0; // 0 = chests, 1 = ores

    public ConfigScreen(Screen parent) {
        super(Text.literal("Chest Highlight"));
        this.parent = parent;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private ButtonWidget toggle(String name, boolean current, int x, int y, int w, Runnable flip, java.util.function.BooleanSupplier get) {
        return ButtonWidget.builder(label(name, current), b -> {
            flip.run();
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
    }

    @Override
    protected void init() {
        left = width / 2 - 156;
        panelTop = Math.max(2, height / 2 - 100);
        cy = panelTop + 46;
        int tabY = panelTop + 20;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Chests").formatted(page == 0 ? Formatting.GOLD : Formatting.WHITE), b -> {
                    page = 0;
                    clearAndInit();
                }).dimensions(left, tabY, 150, 20).build());
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Ores").formatted(page == 1 ? Formatting.GOLD : Formatting.WHITE), b -> {
                    page = 1;
                    clearAndInit();
                }).dimensions(left + 162, tabY, 150, 20).build());

        if (page == 0) initChests();
        else initOres();

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 81, cy + 114, 150, 20).build());
    }

    private void initChests() {
        int w = 150;
        addDrawableChild(toggle("Enabled", Config.enabled, left, cy, w,
                () -> Config.enabled = !Config.enabled, () -> Config.enabled));
        addDrawableChild(toggle("Through walls", Config.throughWalls, left, cy + 22, w,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 44, w,
                () -> Config.fill = !Config.fill, () -> Config.fill));
        addDrawableChild(new RangeSlider(left, cy + 66, w, 20));
        addDrawableChild(toggle("Allow multiplayer", Config.allowMultiplayer, left, cy + 88, w,
                () -> Config.allowMultiplayer = !Config.allowMultiplayer, () -> Config.allowMultiplayer));

        for (int i = 0; i < 5; i++) {
            final int idx = i;
            addDrawableChild(toggle(ChestRenderer.NAMES[i], Config.types[i], left + 162, cy + i * 22, w,
                    () -> Config.types[idx] = !Config.types[idx], () -> Config.types[idx]));
        }
    }

    private void initOres() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Ore ESP", Config.oreEnabled, left, cy, lw,
                () -> {
                    Config.oreEnabled = !Config.oreEnabled;
                    OreScanner.rescan();
                }, () -> Config.oreEnabled));
        addDrawableChild(new OreRangeSlider(left, cy + 22, lw, 20));
        addDrawableChild(toggle("Walls", Config.throughWalls, left, cy + 44, lw,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 66, lw,
                () -> Config.fill = !Config.fill, () -> Config.fill));

        for (int i = 0; i < 10; i++) {
            final int idx = i;
            int col = i < 5 ? 0 : 1;
            int row = i % 5;
            addDrawableChild(toggle(OreScanner.NAMES[i], Config.oreTypes[i], left + 108 + col * 104, cy + row * 22, cw,
                    () -> {
                        Config.oreTypes[idx] = !Config.oreTypes[idx];
                        OreScanner.rescan();
                    }, () -> Config.oreTypes[idx]));
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        ctx.fill(left - 10, panelTop, left + 322, cy + 150, 0xF0101014);
        ctx.fill(left - 10, panelTop, left + 322, panelTop + 2, 0xFFFFA500);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, panelTop + 7, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Multiplayer: only on private servers"),
                width / 2, cy + 138, 0x888888);
    }

    @Override
    public void removed() {
        Config.save();
        OreScanner.rescan();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.range - 16) / 112.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (16 + (int) Math.round(value * 112)) + " blocks"));
        }

        @Override
        protected void applyValue() {
            Config.range = 16 + (int) Math.round(value * 112);
        }
    }

    private static class OreRangeSlider extends SliderWidget {
        OreRangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.oreRange - 8) / 40.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (8 + (int) Math.round(value * 40))));
        }

        @Override
        protected void applyValue() {
            Config.oreRange = 8 + (int) Math.round(value * 40);
            OreScanner.rescan();
        }
    }
}
