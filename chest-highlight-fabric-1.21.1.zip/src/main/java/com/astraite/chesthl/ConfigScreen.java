package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private int left, top;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Chest Highlight"));
        this.parent = parent;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    @Override
    protected void init() {
        left = width / 2 - 156;
        top = height / 2 - 52;
        int w = 150, h = 20;

        addDrawableChild(ButtonWidget.builder(label("Enabled", Config.enabled), b -> {
            Config.enabled = !Config.enabled;
            b.setMessage(label("Enabled", Config.enabled));
        }).dimensions(left, top, w, h).build());

        addDrawableChild(ButtonWidget.builder(label("Through walls", Config.throughWalls), b -> {
            Config.throughWalls = !Config.throughWalls;
            b.setMessage(label("Through walls", Config.throughWalls));
        }).dimensions(left, top + 24, w, h).build());

        addDrawableChild(ButtonWidget.builder(label("Fill", Config.fill), b -> {
            Config.fill = !Config.fill;
            b.setMessage(label("Fill", Config.fill));
        }).dimensions(left, top + 48, w, h).build());

        addDrawableChild(new RangeSlider(left, top + 72, w, h));

        addDrawableChild(ButtonWidget.builder(label("Allow multiplayer", Config.allowMultiplayer), b -> {
            Config.allowMultiplayer = !Config.allowMultiplayer;
            b.setMessage(label("Allow multiplayer", Config.allowMultiplayer));
        }).dimensions(left, top + 96, w, h).build());

        for (int i = 0; i < 5; i++) {
            final int idx = i;
            addDrawableChild(ButtonWidget.builder(label(ChestRenderer.NAMES[i], Config.types[i]), b -> {
                Config.types[idx] = !Config.types[idx];
                b.setMessage(label(ChestRenderer.NAMES[idx], Config.types[idx]));
            }).dimensions(left + 162, top + i * 24, w, h).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 81, top + 124, 150, h).build());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        ctx.fill(left - 10, top - 30, left + 322, top + 158, 0xF0101014);
        ctx.fill(left - 10, top - 30, left + 322, top - 28, 0xFFFFA500);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, top - 20, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Multiplayer: only on private servers"), width / 2, top + 148, 0x888888);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.range - 16) / 112.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (16 + (int) Math.round(value * 112)) + " blocks"));
        }

        @Override
        protected void applyValue() {
            Config.range = 16 + (int) Math.round(value * 112);
        }
    }
}
