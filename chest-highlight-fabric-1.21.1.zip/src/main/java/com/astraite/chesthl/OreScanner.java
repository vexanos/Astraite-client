package com.astraite.chesthl;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class OreScanner {
    public static final String[] NAMES = {"Coal", "Iron", "Copper", "Gold", "Redstone", "Lapis", "Diamond", "Emerald", "Debris", "Quartz"};
    public static final int[] COLORS = {
            0xFF8A8A8A, 0xFFD8AF93, 0xFFE07B39, 0xFFFFD700, 0xFFFF2020,
            0xFF2D5BFF, 0xFF4AEDD9, 0xFF22DD55, 0xFF9B6B3A, 0xFFEFEFEF
    };

    public record Ore(BlockPos pos, int type) {}

    public static volatile List<Ore> cache = new ArrayList<>();

    private static final Map<Block, Integer> MAP = new HashMap<>();
    private static final int MAX_ORES = 4000;
    private static int ticks = 20;

    private static void reg(int type, Block... blocks) {
        for (Block b : blocks) MAP.put(b, type);
    }

    static {
        reg(0, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
        reg(1, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        reg(2, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        reg(3, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        reg(4, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        reg(5, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        reg(6, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        reg(7, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        reg(8, Blocks.ANCIENT_DEBRIS);
        reg(9, Blocks.NETHER_QUARTZ_ORE);
    }

    public static void rescan() {
        ticks = 20;
    }

    private static boolean isWantedOre(BlockState s) {
        Integer t = MAP.get(s.getBlock());
        return t != null && Config.oreTypes[t];
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.oreEnabled || mc.world == null || mc.player == null
                || (!mc.isInSingleplayer() && !Config.allowMultiplayer)) {
            if (!cache.isEmpty()) cache = new ArrayList<>();
            return;
        }
        if (++ticks < 20) return;
        ticks = 0;
        scan(mc);
    }

    private static void scan(MinecraftClient mc) {
        ClientWorld w = mc.world;
        int range = Config.oreRange;
        BlockPos pp = mc.player.getBlockPos();
        int minX = pp.getX() - range, maxX = pp.getX() + range;
        int minY = pp.getY() - range, maxY = pp.getY() + range;
        int minZ = pp.getZ() - range, maxZ = pp.getZ() + range;

        List<Ore> out = new ArrayList<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                WorldChunk chunk = w.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                ChunkSection[] sections = chunk.getSectionArray();
                for (int i = 0; i < sections.length; i++) {
                    ChunkSection s = sections[i];
                    if (s == null || s.isEmpty()) continue;
                    int baseY = (w.getBottomSectionCoord() + i) << 4;
                    if (baseY + 15 < minY || baseY > maxY) continue;
                    if (!s.hasAny(OreScanner::isWantedOre)) continue;
                    for (int x = 0; x < 16; x++) {
                        int wx = (cx << 4) + x;
                        if (wx < minX || wx > maxX) continue;
                        for (int z = 0; z < 16; z++) {
                            int wz = (cz << 4) + z;
                            if (wz < minZ || wz > maxZ) continue;
                            for (int y = 0; y < 16; y++) {
                                int wy = baseY + y;
                                if (wy < minY || wy > maxY) continue;
                                Integer t = MAP.get(s.getBlockState(x, y, z).getBlock());
                                if (t == null || !Config.oreTypes[t]) continue;
                                out.add(new Ore(new BlockPos(wx, wy, wz), t));
                                if (out.size() >= MAX_ORES) {
                                    cache = out;
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        }
        cache = out;
    }
}
