package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class Config {
    public static boolean enabled = true;
    public static boolean throughWalls = true;
    public static boolean fill = true;
    public static int range = 64;
    public static boolean[] baseTypes = defaultBase();
    public static boolean oreEnabled = false;
    public static int oreRange = 24;
    public static boolean autoTotem = false;
    public static int totemDelay = 1;
    public static boolean killAura = false;
    public static int auraRange = 3;
    public static boolean auraPlayers = true;
    public static boolean auraHostile = true;
    public static boolean auraPassive = false;
    public static boolean auraRotate = true;
    public static boolean auraWalls = false;
    // 0 coal,1 iron,2 copper,3 gold,4 redstone,5 lapis,6 diamond,7 emerald,8 debris,9 quartz
    public static boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl.json");

    // Noisy / natural blocks start OFF: flower pot, cactus, glowstone, sugar cane, fence
    static boolean[] defaultBase() {
        boolean[] a = new boolean[BaseScanner.N];
        Arrays.fill(a, true);
        a[10] = false;
        a[24] = false;
        a[25] = false;
        a[26] = false;
        a[27] = false;
        a[36] = false; // passive mobs
        a[37] = false; // other mobs
        a[38] = false; // projectiles
        a[39] = false; // xp orbs
        a[41] = false; // boats / minecarts
        return a;
    }

    private static class Data {
        boolean enabled = true;
        boolean throughWalls = true;
        boolean fill = true;
        int range = 64;
        boolean[] baseTypes = defaultBase();
        boolean oreEnabled = false;
        int oreRange = 24;
        boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};
        boolean autoTotem = false;
        int totemDelay = 1;
        boolean killAura = false;
        int auraRange = 3;
        boolean auraPlayers = true;
        boolean auraHostile = true;
        boolean auraPassive = false;
        boolean auraRotate = true;
        boolean auraWalls = false;
    }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            enabled = d.enabled;
            throughWalls = d.throughWalls;
            fill = d.fill;
            range = Math.max(16, Math.min(128, d.range));
            if (d.baseTypes != null && d.baseTypes.length == BaseScanner.N) baseTypes = d.baseTypes;
            oreEnabled = d.oreEnabled;
            oreRange = Math.max(8, Math.min(48, d.oreRange));
            if (d.oreTypes != null && d.oreTypes.length == 10) oreTypes = d.oreTypes;
            autoTotem = d.autoTotem;
            totemDelay = Math.max(0, Math.min(10, d.totemDelay));
            killAura = d.killAura;
            auraRange = Math.max(2, Math.min(6, d.auraRange));
            auraPlayers = d.auraPlayers;
            auraHostile = d.auraHostile;
            auraPassive = d.auraPassive;
            auraRotate = d.auraRotate;
            auraWalls = d.auraWalls;
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.throughWalls = throughWalls;
            d.fill = fill;
            d.range = range;
            d.baseTypes = baseTypes;
            d.oreEnabled = oreEnabled;
            d.oreRange = oreRange;
            d.oreTypes = oreTypes;
            d.autoTotem = autoTotem;
            d.totemDelay = totemDelay;
            d.killAura = killAura;
            d.auraRange = auraRange;
            d.auraPlayers = auraPlayers;
            d.auraHostile = auraHostile;
            d.auraPassive = auraPassive;
            d.auraRotate = auraRotate;
            d.auraWalls = auraWalls;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }
}
