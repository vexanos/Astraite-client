package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class KillAura {
    public static void tick(MinecraftClient mc) {
        if (!Config.killAura) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        double max = Config.auraRange;
        double maxSq = max * max;
        Vec3d eye = p.getEyePos();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p) continue;
            if (!le.isAlive() || le.isInvulnerable() || le.isSpectator()) continue;
            if (!validType(le)) continue;
            double d = distSq(eye, le.getBoundingBox());
            if (d > maxSq || d >= bestDist) continue;
            if (!Config.auraWalls && !p.canSee(le)) continue;
            best = le;
            bestDist = d;
        }
        if (best == null) return;

        if (Config.auraRotate) face(p, best);

        // only hit when the attack is fully charged (full damage, no spam)
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static boolean validType(LivingEntity e) {
        if (e instanceof PlayerEntity) return Config.auraPlayers;
        if (e instanceof HostileEntity) return Config.auraHostile;
        return Config.auraPassive;
    }

    private static double distSq(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.squaredDistanceTo(x, y, z);
    }

    private static void face(ClientPlayerEntity p, Entity t) {
        Vec3d eye = p.getEyePos();
        Vec3d to = t.getBoundingBox().getCenter();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }
}
