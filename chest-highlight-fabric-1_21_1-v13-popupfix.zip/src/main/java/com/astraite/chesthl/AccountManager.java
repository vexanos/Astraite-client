package com.astraite.chesthl;

import com.astraite.chesthl.mixin.MinecraftClientAccessor;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class AccountManager {
    public static class Account {
        public String type;          // "cracked" or "premium"
        public String name;
        public String uuid;          // premium only (no dashes)
        public String refreshToken;  // premium only

        public String key() {
            return type + ":" + name;
        }

        public boolean isPremium() {
            return "premium".equals(type);
        }
    }

    private static class Data {
        List<Account> accounts = new ArrayList<>();
        String active = "";
    }

    private record Resp(int status, JsonObject json) {}

    private record Login(String name, String uuid, String token) {}

    private static final String CLIENT_ID = "00000000402b5328";
    private static final String SCOPE = "XboxLive.signin offline_access";
    private static final String DEVICE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
    private static final String TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
    private static final String FORM = "application/x-www-form-urlencoded";
    private static final String JSON = "application/json";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl-accounts.json");

    public static final List<Account> accounts = new ArrayList<>();
    public static volatile String active = "";      // "" = launcher account
    public static volatile String status = "";
    public static volatile String deviceCode = "";
    public static volatile String deviceUrl = "";
    public static volatile int version = 0;

    private static volatile boolean busy = false;
    private static Session official; // launcher session, kept in memory only
    private static boolean applied = false;

    // ---------- storage ----------
    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            accounts.clear();
            if (d.accounts != null) accounts.addAll(d.accounts);
            active = d.active == null ? "" : d.active;
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.accounts = new ArrayList<>(accounts);
            d.active = active;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }

    private static void bump() {
        version++;
    }

    private static String msg(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    public static boolean validName(String n) {
        return n != null && n.matches("[A-Za-z0-9_]{3,16}");
    }

    private static Account find(String key) {
        for (Account a : accounts) if (a.key().equals(key)) return a;
        return null;
    }

    public static void tick(MinecraftClient mc) {
        if (official == null) official = mc.getSession();
        if (!applied) {
            applied = true;
            Account a = find(active);
            if (a != null) switchTo(mc, a);
            else active = "";
        }
    }

    // ---------- session helpers ----------
    private static void setSession(MinecraftClient mc, Session s) {
        ((MinecraftClientAccessor) mc).chesthl_setSession(s);
    }

    private static void applyCracked(MinecraftClient mc, String name) {
        UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        setSession(mc, new Session(name, id, "", Optional.empty(), Optional.empty(), Session.AccountType.MOJANG));
    }

    private static void applyPremium(MinecraftClient mc, Login l) {
        String dashed = l.uuid().replaceFirst(
                "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5");
        setSession(mc, new Session(l.name(), UUID.fromString(dashed), l.token(),
                Optional.empty(), Optional.empty(), Session.AccountType.MSA));
    }

    // ---------- public actions ----------
    public static boolean useOfficial(MinecraftClient mc) {
        if (official == null) {
            status = "Launcher account abhi mila nahi, thodi der baad try kar";
            bump();
            return false;
        }
        setSession(mc, official);
        active = "";
        save();
        status = "Launcher account ON: " + official.getUsername();
        bump();
        return true;
    }

    public static void addCracked(MinecraftClient mc, String name) {
        Account a = find("cracked:" + name);
        if (a == null) {
            a = new Account();
            a.type = "cracked";
            a.name = name;
            accounts.add(a);
            save();
        }
        switchTo(mc, a);
    }

    public static void remove(MinecraftClient mc, Account a) {
        boolean wasActive = a.key().equals(active);
        accounts.remove(a);
        if (wasActive) useOfficial(mc);
        else save();
        bump();
    }

    public static void switchTo(MinecraftClient mc, Account a) {
        if (!a.isPremium()) {
            applyCracked(mc, a.name);
            active = a.key();
            save();
            status = "Cracked account ON: " + a.name;
            bump();
            return;
        }
        if (busy) {
            status = "Ek login chal raha hai, thoda ruk ja";
            bump();
            return;
        }
        busy = true;
        status = "Login ho raha hai: " + a.name;
        bump();
        runAsync(() -> {
            try {
                Resp r = request("POST", TOKEN_URL, FORM, form(
                        "grant_type", "refresh_token", "client_id", CLIENT_ID,
                        "refresh_token", a.refreshToken, "scope", SCOPE), null);
                if (r.status() != 200) throw new Exception("Login expire ho gaya, premium account dobara add kar");
                String access = r.json().get("access_token").getAsString();
                String newRefresh = r.json().has("refresh_token")
                        ? r.json().get("refresh_token").getAsString() : a.refreshToken;
                Login l = xboxChain(access);
                mc.execute(() -> {
                    a.refreshToken = newRefresh;
                    a.name = l.name();
                    a.uuid = l.uuid();
                    applyPremium(mc, l);
                    active = a.key();
                    save();
                    status = "Premium account ON: " + l.name();
                    bump();
                });
            } catch (Exception e) {
                status = "Error: " + msg(e);
                bump();
            } finally {
                busy = false;
            }
        });
    }

    /** Microsoft device-code login: shows a code + link, user approves in a browser. */
    public static void beginPremiumLogin(MinecraftClient mc) {
        if (busy) {
            status = "Ek login chal raha hai, thoda ruk ja";
            bump();
            return;
        }
        busy = true;
        status = "Microsoft login shuru ho raha hai...";
        bump();
        runAsync(() -> {
            try {
                Resp dc = request("POST", DEVICE_URL, FORM, form("client_id", CLIENT_ID, "scope", SCOPE), null);
                if (dc.status() != 200) throw new Exception("Login start nahi hua (" + dc.status() + ")");
                String device = dc.json().get("device_code").getAsString();
                String userCode = dc.json().get("user_code").getAsString();
                String url = dc.json().get("verification_uri").getAsString();
                int interval = dc.json().has("interval") ? dc.json().get("interval").getAsInt() : 5;
                long expires = System.currentTimeMillis() + dc.json().get("expires_in").getAsLong() * 1000L;

                deviceCode = userCode;
                deviceUrl = url;
                status = "Browser me link kholo aur code daalo";
                bump();
                mc.execute(() -> mc.keyboard.setClipboard(userCode));

                while (System.currentTimeMillis() < expires) {
                    Thread.sleep(interval * 1000L);
                    Resp tk = request("POST", TOKEN_URL, FORM, form(
                            "grant_type", "urn:ietf:params:oauth:grant-type:device_code",
                            "client_id", CLIENT_ID, "device_code", device), null);
                    if (tk.status() == 200) {
                        String access = tk.json().get("access_token").getAsString();
                        String refresh = tk.json().get("refresh_token").getAsString();
                        deviceCode = "";
                        deviceUrl = "";
                        status = "Xbox/Minecraft login ho raha hai...";
                        bump();
                        Login l = xboxChain(access);
                        mc.execute(() -> {
                            Account a = null;
                            for (Account x : accounts) {
                                if (x.isPremium() && l.uuid().equals(x.uuid)) a = x;
                            }
                            if (a == null) {
                                a = new Account();
                                a.type = "premium";
                                accounts.add(a);
                            }
                            a.name = l.name();
                            a.uuid = l.uuid();
                            a.refreshToken = refresh;
                            applyPremium(mc, l);
                            active = a.key();
                            save();
                            status = "Premium account add + ON: " + l.name();
                            bump();
                        });
                        return;
                    }
                    String err = tk.json().has("error") ? tk.json().get("error").getAsString() : "";
                    if (err.equals("authorization_pending")) continue;
                    if (err.equals("slow_down")) {
                        interval += 5;
                        continue;
                    }
                    throw new Exception("Login cancel ya fail (" + err + ")");
                }
                throw new Exception("Code expire ho gaya, dobara try kar");
            } catch (Exception e) {
                status = "Error: " + msg(e);
                bump();
            } finally {
                deviceCode = "";
                deviceUrl = "";
                busy = false;
                bump();
            }
        });
    }

    // ---------- Microsoft / Xbox / Minecraft chain ----------
    private static Login xboxChain(String msAccessToken) throws Exception {
        JsonObject p1 = new JsonObject();
        p1.addProperty("AuthMethod", "RPS");
        p1.addProperty("SiteName", "user.auth.xboxlive.com");
        p1.addProperty("RpsTicket", "d=" + msAccessToken);
        JsonObject b1 = new JsonObject();
        b1.add("Properties", p1);
        b1.addProperty("RelyingParty", "http://auth.xboxlive.com");
        b1.addProperty("TokenType", "JWT");
        Resp xbl = request("POST", "https://user.auth.xboxlive.com/user/authenticate", JSON, b1.toString(), null);
        if (xbl.status() != 200) throw new Exception("Xbox login fail (" + xbl.status() + ")");
        String xblToken = xbl.json().get("Token").getAsString();

        JsonArray tokens = new JsonArray();
        tokens.add(xblToken);
        JsonObject p2 = new JsonObject();
        p2.addProperty("SandboxId", "RETAIL");
        p2.add("UserTokens", tokens);
        JsonObject b2 = new JsonObject();
        b2.add("Properties", p2);
        b2.addProperty("RelyingParty", "rp://api.minecraftservices.com/");
        b2.addProperty("TokenType", "JWT");
        Resp xsts = request("POST", "https://xsts.auth.xboxlive.com/xsts/authorize", JSON, b2.toString(), null);
        if (xsts.status() != 200) {
            throw new Exception("Xbox access nahi mila (" + xsts.status() + "), account me Xbox profile/age check kar");
        }
        String xstsToken = xsts.json().get("Token").getAsString();
        String uhs = xsts.json().getAsJsonObject("DisplayClaims").getAsJsonArray("xui")
                .get(0).getAsJsonObject().get("uhs").getAsString();

        JsonObject b3 = new JsonObject();
        b3.addProperty("identityToken", "XBL3.0 x=" + uhs + ";" + xstsToken);
        Resp mc = request("POST", "https://api.minecraftservices.com/authentication/login_with_xbox", JSON, b3.toString(), null);
        if (mc.status() != 200) throw new Exception("Minecraft login fail (" + mc.status() + ")");
        String mcToken = mc.json().get("access_token").getAsString();

        Resp prof = request("GET", "https://api.minecraftservices.com/minecraft/profile", null, null, mcToken);
        if (prof.status() != 200) throw new Exception("Is account pe Minecraft Java nahi mila");
        return new Login(prof.json().get("name").getAsString(), prof.json().get("id").getAsString(), mcToken);
    }

    // ---------- http ----------
    private static void runAsync(Runnable r) {
        Thread t = new Thread(r, "chesthl-auth");
        t.setDaemon(true);
        t.start();
    }

    private static String form(String... kv) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (i > 0) sb.append('&');
            sb.append(URLEncoder.encode(kv[i], StandardCharsets.UTF_8)).append('=')
                    .append(URLEncoder.encode(kv[i + 1], StandardCharsets.UTF_8));
        }
        return sb.toString();
    }

    private static Resp request(String method, String url, String contentType, String body, String bearer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(15000);
        c.setRequestProperty("Accept", JSON);
        if (contentType != null) c.setRequestProperty("Content-Type", contentType);
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer " + bearer);
        if (body != null) {
            c.setDoOutput(true);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
        JsonObject o;
        try {
            o = JsonParser.parseString(text).getAsJsonObject();
        } catch (Exception e) {
            o = new JsonObject();
        }
        return new Resp(code, o);
    }
}
