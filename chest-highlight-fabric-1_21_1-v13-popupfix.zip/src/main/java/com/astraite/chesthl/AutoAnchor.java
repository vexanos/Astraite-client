package com.astraite.chesthl;

import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Respawn-anchor bomb: place anchor -> charge with glowstone -> explode with a non-glowstone item.
 * Anchors only explode outside the Nether. Do not sneak (sneaking skips the block's right-click).
 */
public final class AutoAnchor {
    public static String status = "";
    private static int cd = 0;
    private static int prevSlot = -1;
    private static boolean anyAnchor = false;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.autoAnchor) {
            status = "";
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) {
            status = "Paused (eating)";
            return;
        }
        if (w.getDimension().respawnAnchorWorks()) {
            status = "Anchors do not explode in the Nether";
            return;
        }
        if (p.isSneaking()) {
            status = "Stop sneaking";
            return;
        }
        if (cd > 0) {
            cd--;
            return;
        }

        LivingEntity target = PlaceUtil.target(w, p, Config.anchorTargetRange, Config.anchorMobs);
        if (target == null) {
            status = "No target within " + Config.anchorTargetRange + " blocks";
            return;
        }
        status = "Target: " + target.getName().getString();

        Vec3d eye = p.getEyePos();
        double r = Config.anchorRange;
        BlockPos anchor = findAnchor(w, p, target, eye, r);
        boolean acted = false;
        int wait = Config.anchorDelay;
        if (anchor != null) {
            int charges = w.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
            if (charges == 0) {
                acted = charge(mc, p, anchor);
                wait = Math.max(wait, 3); // give the server time to update the charge
            } else {
                acted = explode(mc, p, anchor);
            }
        } else if (anyAnchor) {
            status = "Anchor in range is not safe/effective";
        } else if (Config.anchorPlace) {
            acted = placeAnchor(mc, w, p, target, eye, r);
        } else {
            status = "No anchor near target";
        }
        if (acted) cd = wait;

        if (Config.anchorSwitchBack && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    private static BlockPos findAnchor(ClientWorld w, ClientPlayerEntity p, LivingEntity target, Vec3d eye, double r) {
        anyAnchor = false;
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();
        BlockPos best = null;
        double bestScore = -1e9;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (!w.getBlockState(m).isOf(Blocks.RESPAWN_ANCHOR)) continue;
                    Vec3d c = new Vec3d(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (eye.squaredDistanceTo(c) > r * r) continue;
                    anyAnchor = true;
                    double tgt = PlaceUtil.damage(target, c, 5.0);
                    double self = PlaceUtil.damage(p, c, 5.0);
                    if (!PlaceUtil.safe(p, tgt, self, Config.anchorMinDmg, Config.anchorMaxSelf)) continue;
                    if (tgt - self > bestScore) {
                        bestScore = tgt - self;
                        best = m.toImmutable();
                    }
                }
            }
        }
        return best;
    }

    private static boolean placeAnchor(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target,
                                       Vec3d eye, double r) {
        int slot = PlaceUtil.slotIdx(Config.anchorSlot);
        if (!p.getInventory().getStack(slot).isOf(Items.RESPAWN_ANCHOR)) {
            status = "No respawn anchor in hotbar slot " + Config.anchorSlot;
            return false;
        }
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();
        BlockPos best = null;
        double bestScore = -1e9;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (!w.getBlockState(m).isAir()) continue;
                    Vec3d c = new Vec3d(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (eye.squaredDistanceTo(c) > r * r) continue;
                    double tgt = PlaceUtil.damage(target, c, 5.0);
                    double self = PlaceUtil.damage(p, c, 5.0);
                    if (!PlaceUtil.safe(p, tgt, self, Config.anchorMinDmg, Config.anchorMaxSelf)) continue;
                    if (!w.getOtherEntities(null, new Box(m)).isEmpty()) continue;
                    if (PlaceUtil.hitFor(w, m.toImmutable()) == null) continue;
                    if (tgt - self > bestScore) {
                        bestScore = tgt - self;
                        best = m.toImmutable();
                    }
                }
            }
        }
        if (best == null) {
            status = "No good spot for anchor (try lower Min dmg / higher Max self)";
            return false;
        }
        BlockHitResult hit = PlaceUtil.hitFor(w, best);
        select(p, slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        status = "Placed anchor";
        return true;
    }

    private static boolean charge(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        int slot = PlaceUtil.slotIdx(Config.glowSlot);
        if (!p.getInventory().getStack(slot).isOf(Items.GLOWSTONE)) {
            status = "No glowstone in hotbar slot " + Config.glowSlot;
            return false;
        }
        select(p, slot);
        click(mc, p, anchor);
        status = "Charging anchor";
        return true;
    }

    private static boolean explode(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        if (p.getOffHandStack().isOf(Items.GLOWSTONE)) {
            status = "Remove glowstone from offhand";
            return false;
        }
        // must NOT hold glowstone, otherwise it just charges again
        int slot = PlaceUtil.slotIdx(Config.anchorSlot);
        if (p.getInventory().getStack(slot).isOf(Items.GLOWSTONE)) {
            slot = -1;
            for (int i = 0; i < 9; i++) {
                if (!p.getInventory().getStack(i).isOf(Items.GLOWSTONE)) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) {
                status = "No safe slot to explode with";
                return false;
            }
        }
        select(p, slot);
        click(mc, p, anchor);
        status = "Exploding anchor";
        return true;
    }

    private static void click(MinecraftClient mc, ClientPlayerEntity p, BlockPos anchor) {
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(anchor.getX() + 0.5, anchor.getY() + 1.0, anchor.getZ() + 0.5), Direction.UP, anchor, false);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
    }

    private static void select(ClientPlayerEntity p, int slot) {
        if (p.getInventory().selectedSlot != slot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
        }
    }
}
