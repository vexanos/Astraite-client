package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public final class AutoEat {
    /** true while we are holding the use key to eat; other modules pause on this. */
    public static boolean eating = false;
    private static int prevSlot = -1;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || !Config.autoEat || mc.currentScreen != null || p.isDead()) {
            stop(mc);
            return;
        }
        boolean hungerLow = p.getHungerManager().getFoodLevel() <= Config.eatHunger;
        boolean healthLow = p.getHealth() <= Config.eatHealth;
        boolean need = switch (Config.eatMode) {
            case 0 -> hungerLow;
            case 1 -> healthLow;
            default -> hungerLow || healthLow;
        };
        if (!need) {
            stop(mc);
            return;
        }

        if (!eating) {
            int slot = bestFood(p, healthLow);
            if (slot < 0) return;
            prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
            eating = true;
        } else if (!usable(p.getInventory().getStack(p.getInventory().selectedSlot), p, healthLow)) {
            stop(mc);
            return;
        }
        mc.options.useKey.setPressed(true);
    }

    private static void stop(MinecraftClient mc) {
        if (!eating) return;
        eating = false;
        if (mc.options != null) mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot >= 0) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    private static boolean usable(ItemStack s, ClientPlayerEntity p, boolean healthLow) {
        if (s.isEmpty()) return false;
        FoodComponent f = s.get(DataComponentTypes.FOOD);
        if (f == null || bad(s)) return false;
        boolean golden = s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
        if (golden && !healthLow) return false; // save golden apples for low health
        return p.canConsume(f.canAlwaysEat());
    }

    private static boolean bad(ItemStack s) {
        return s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE) || s.isOf(Items.POISONOUS_POTATO)
                || s.isOf(Items.PUFFERFISH) || s.isOf(Items.CHORUS_FRUIT) || s.isOf(Items.SUSPICIOUS_STEW)
                || s.isOf(Items.POISONOUS_POTATO);
    }

    private static int bestFood(ClientPlayerEntity p, boolean healthLow) {
        int best = -1;
        double bestScore = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!usable(s, p, healthLow)) continue;
            FoodComponent f = s.get(DataComponentTypes.FOOD);
            double score = f.nutrition() + f.saturation();
            if (healthLow && (s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE))) score += 100;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }
}
