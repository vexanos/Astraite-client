package com.astraite.chesthl;

import java.lang.reflect.Method;

/** Pauses / resumes Baritone through reflection, so the mod works with or without it installed. */
public final class BaritoneUtil {
    private static boolean paused = false;

    private BaritoneUtil() {
    }

    public static void pause() {
        if (paused) return;
        if (run("pause")) paused = true;
    }

    public static void resume() {
        if (!paused) return;
        run("resume");
        paused = false;
    }

    private static boolean run(String cmd) {
        try {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object baritone = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
            Object cm = baritone.getClass().getMethod("getCommandManager").invoke(baritone);
            Method exec = cm.getClass().getMethod("execute", String.class);
            exec.invoke(cm, cmd);
            return true;
        } catch (Throwable t) {
            return false; // Baritone not installed
        }
    }
}
