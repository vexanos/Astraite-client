package com.astraite.chesthl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.GlowItemFrameEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public final class BaseRenderer {
    private record Target(Box box, int color) {}

    private static int entityType(Entity e) {
        if (e instanceof GlowItemFrameEntity) return 30;
        if (e instanceof ItemFrameEntity) return 29;
        if (e instanceof PaintingEntity) return 28;
        if (e instanceof ArmorStandEntity) return 31;
        if (e instanceof ChestMinecartEntity) return 32;
        if (e instanceof ItemEntity) return 33;
        if (e instanceof PlayerEntity) return 34;
        if (e instanceof TntEntity) return 40;
        if (e instanceof ExperienceOrbEntity) return 39;
        if (e instanceof ProjectileEntity) return 38;
        if (e instanceof AbstractMinecartEntity || e instanceof BoatEntity) return 41;
        if (e instanceof Monster) return 35;
        if (e instanceof PassiveEntity) return 36;
        if (e instanceof MobEntity) return 37;
        return -1;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        if (!Config.enabled && !Config.oreEnabled) return;
        MatrixStack stack = ctx.matrixStack();
        if (stack == null) return;

        Vec3d cam = ctx.camera().getPos();
        Vec3d pp = mc.player.getPos();
        List<Target> targets = new ArrayList<>();

        if (Config.enabled) {
            for (BaseScanner.Hit h : BaseScanner.cache) {
                Box b = h.box().expand(0.002).offset(-cam.x, -cam.y, -cam.z);
                targets.add(new Target(b, BaseScanner.COLORS[h.type()]));
            }
            double r2 = (double) Config.range * Config.range;
            float delta = mc.getRenderTickCounter().getTickDelta(false);
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player) continue;
                int t = entityType(e);
                if (t < 0 || !Config.baseTypes[t]) continue;
                if (e.squaredDistanceTo(pp) > r2) continue;
                Vec3d lp = e.getLerpedPos(delta);
                Box b = e.getBoundingBox()
                        .offset(lp.x - e.getX(), lp.y - e.getY(), lp.z - e.getZ())
                        .expand(0.05)
                        .offset(-cam.x, -cam.y, -cam.z);
                targets.add(new Target(b, BaseScanner.COLORS[t]));
            }
        }

        if (Config.oreEnabled) {
            for (OreScanner.Ore o : OreScanner.cache) {
                Box b = new Box(o.pos()).expand(0.002).offset(-cam.x, -cam.y, -cam.z);
                targets.add(new Target(b, OreScanner.COLORS[o.type()]));
            }
        }
        if (targets.isEmpty()) return;

        Matrix4f m = stack.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        if (Config.throughWalls) RenderSystem.disableDepthTest();
        else RenderSystem.enableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        if (Config.fill) {
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (Target t : targets) fill(b, m, t.box(), (70 << 24) | (t.color() & 0xFFFFFF));
            BufferRenderer.drawWithGlobalProgram(b.end());
        }

        BufferBuilder l = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (Target t : targets) lines(l, m, t.box(), t.color());
        BufferRenderer.drawWithGlobalProgram(l.end());

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void v(BufferBuilder b, Matrix4f m, double x, double y, double z, int c) {
        b.vertex(m, (float) x, (float) y, (float) z).color(c);
    }

    private static void fill(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        v(b, m, x0, y0, z0, c); v(b, m, x1, y0, z0, c); v(b, m, x1, y0, z1, c); v(b, m, x0, y0, z1, c);
        v(b, m, x0, y1, z0, c); v(b, m, x0, y1, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y1, z0, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y1, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y0, z0, c);
        v(b, m, x0, y0, z1, c); v(b, m, x1, y0, z1, c); v(b, m, x1, y1, z1, c); v(b, m, x0, y1, z1, c);
        v(b, m, x0, y0, z0, c); v(b, m, x0, y0, z1, c); v(b, m, x0, y1, z1, c); v(b, m, x0, y1, z0, c);
        v(b, m, x1, y0, z0, c); v(b, m, x1, y1, z0, c); v(b, m, x1, y1, z1, c); v(b, m, x1, y0, z1, c);
    }

    private static void edge(BufferBuilder b, Matrix4f m, double ax, double ay, double az,
                             double bx, double by, double bz, int c) {
        v(b, m, ax, ay, az, c);
        v(b, m, bx, by, bz, c);
    }

    private static void lines(BufferBuilder b, Matrix4f m, Box bx, int c) {
        double x0 = bx.minX, y0 = bx.minY, z0 = bx.minZ, x1 = bx.maxX, y1 = bx.maxY, z1 = bx.maxZ;
        edge(b, m, x0, y0, z0, x1, y0, z0, c);
        edge(b, m, x1, y0, z0, x1, y0, z1, c);
        edge(b, m, x1, y0, z1, x0, y0, z1, c);
        edge(b, m, x0, y0, z1, x0, y0, z0, c);
        edge(b, m, x0, y1, z0, x1, y1, z0, c);
        edge(b, m, x1, y1, z0, x1, y1, z1, c);
        edge(b, m, x1, y1, z1, x0, y1, z1, c);
        edge(b, m, x0, y1, z1, x0, y1, z0, c);
        edge(b, m, x0, y0, z0, x0, y1, z0, c);
        edge(b, m, x1, y0, z0, x1, y1, z0, c);
        edge(b, m, x1, y0, z1, x1, y1, z1, c);
        edge(b, m, x0, y0, z1, x0, y1, z1, c);
    }
}
