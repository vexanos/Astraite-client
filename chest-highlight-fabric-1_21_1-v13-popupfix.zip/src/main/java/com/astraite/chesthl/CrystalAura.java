package com.astraite.chesthl;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/**
 * Crystal Aura.
 *  - target in range : places crystals on the best obsidian/bedrock (places obsidian first if there is none)
 *                      and breaks crystals that hurt the target.
 *  - no target       : "Idle place" puts a crystal on top of every free obsidian/bedrock in range.
 */
public final class CrystalAura {
    /** Shown on the HUD / menu so you can see why it is (not) doing something. */
    public static String status = "";
    private static int placeCd = 0, breakCd = 0;
    private static int prevSlot = -1;
    private static final Map<BlockPos, Long> recent = new HashMap<>();

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.crystalAura) {
            status = "";
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) {
            status = "Paused (eating)";
            return;
        }

        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;
        long now = w.getTime();
        recent.values().removeIf(t -> now - t > 20);

        LivingEntity target = PlaceUtil.target(w, p, Config.crystalTargetRange, Config.crystalMobs);
        if (target != null) {
            status = "Target: " + target.getName().getString();
            if (Config.crystalBreak && breakCd == 0 && breakCrystal(mc, w, p, target)) breakCd = Config.crystalBreakDelay;
            if (Config.crystalPlace && placeCd == 0 && placeCrystal(mc, w, p, target, now)) placeCd = Config.crystalPlaceDelay;
        } else if (Config.crystalIdle && Config.crystalPlace) {
            status = "Idle (no target)";
            if (placeCd == 0 && placeIdle(mc, w, p, now)) placeCd = Config.crystalPlaceDelay;
        } else {
            status = "No target within " + Config.crystalTargetRange + " blocks";
        }

        // always go back to the item you were holding
        if (prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    // ---------------- break ----------------
    private static boolean breakCrystal(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target) {
        Vec3d eye = p.getEyePos();
        double r = Config.crystalBreakRange;
        EndCrystalEntity best = null;
        double bestScore = -1e9;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (PlaceUtil.closestSq(eye, c.getBoundingBox()) > r * r) continue;
            Vec3d pos = c.getPos();
            double tgt = PlaceUtil.damage(target, pos, 6.0);
            double self = PlaceUtil.damage(p, pos, 6.0);
            if (!PlaceUtil.safe(p, tgt, self, Config.crystalMinDmg, Config.crystalMaxSelf)) continue;
            if (tgt - self > bestScore) {
                bestScore = tgt - self;
                best = c;
            }
        }
        if (best == null) return false;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        status = "Broke crystal";
        return true;
    }

    // ---------------- place (target mode) ----------------
    private static boolean placeCrystal(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target, long now) {
        int cSlot = PlaceUtil.slotIdx(Config.crystalSlot);
        boolean crystalOff = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        if (!crystalOff && !p.getInventory().getStack(cSlot).isOf(Items.END_CRYSTAL)) {
            status = "No crystals in hotbar slot " + Config.crystalSlot;
            return false;
        }

        Vec3d eye = p.getEyePos();
        double r = Config.crystalPlaceRange;
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();

        BlockPos bestBase = null;
        double bestBaseScore = -1e9;
        BlockPos bestObs = null;
        double bestObsScore = -1e9;
        int dmgRejected = 0;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5) > r * r) continue;
                    BlockState st = w.getBlockState(m);
                    boolean solid = st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK);
                    boolean empty = st.isAir();
                    if (!solid && !(empty && Config.crystalObsidian)) continue;
                    if (!w.isAir(m.up()) || !w.isAir(m.up(2))) continue;

                    Vec3d cpos = new Vec3d(m.getX() + 0.5, m.getY() + 1.0, m.getZ() + 0.5);
                    double tgt = PlaceUtil.damage(target, cpos, 6.0);
                    double self = PlaceUtil.damage(p, cpos, 6.0);
                    if (!PlaceUtil.safe(p, tgt, self, Config.crystalMinDmg, Config.crystalMaxSelf)) {
                        dmgRejected++;
                        continue;
                    }
                    double sc = tgt - self;
                    if (solid ? sc <= bestBaseScore : sc <= bestObsScore) continue;

                    BlockPos pos = m.toImmutable();
                    if (solid && recent.containsKey(pos)) continue;
                    Box box = new Box(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
                    if (!w.getOtherEntities(null, box).isEmpty()) continue;
                    if (empty) {
                        if (!w.getOtherEntities(null, new Box(pos)).isEmpty()) continue;
                        if (PlaceUtil.hitFor(w, pos) == null) continue;
                        bestObsScore = sc;
                        bestObs = pos;
                    } else {
                        bestBaseScore = sc;
                        bestBase = pos;
                    }
                }
            }
        }

        if (bestBase != null) {
            putCrystal(mc, p, bestBase, crystalOff, cSlot, now);
            status = "Placed crystal";
            return true;
        }

        if (bestObs != null) {
            int oSlot = PlaceUtil.slotIdx(Config.obsidianSlot);
            boolean obsOff = p.getOffHandStack().isOf(Items.OBSIDIAN);
            if (!obsOff && !p.getInventory().getStack(oSlot).isOf(Items.OBSIDIAN)) {
                status = "No obsidian in hotbar slot " + Config.obsidianSlot;
                return false;
            }
            BlockHitResult hit = PlaceUtil.hitFor(w, bestObs);
            if (hit == null) return false;
            Hand hand = obsOff ? Hand.OFF_HAND : select(p, oSlot);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            status = "Placed obsidian";
            return true;
        }

        if (dmgRejected > 0) status = "Spots rejected by Min dmg / Max self (" + dmgRejected + ")";
        else status = Config.crystalObsidian ? "No free spot in range" : "No free obsidian in range";
        return false;
    }

    // ---------------- place (no target: crystal on every free obsidian) ----------------
    private static boolean placeIdle(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, long now) {
        int cSlot = PlaceUtil.slotIdx(Config.crystalSlot);
        boolean crystalOff = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        if (!crystalOff && !p.getInventory().getStack(cSlot).isOf(Items.END_CRYSTAL)) {
            status = "No crystals in hotbar slot " + Config.crystalSlot;
            return false;
        }
        Vec3d eye = p.getEyePos();
        double r = Config.crystalPlaceRange;
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    double d = eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5);
                    if (d > r * r || d >= bestD) continue;
                    BlockState st = w.getBlockState(m);
                    if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) continue;
                    if (!w.isAir(m.up()) || !w.isAir(m.up(2))) continue;
                    BlockPos pos = m.toImmutable();
                    if (recent.containsKey(pos)) continue;
                    Box box = new Box(pos.getX(), pos.getY() + 1, pos.getZ(), pos.getX() + 1, pos.getY() + 3, pos.getZ() + 1);
                    if (!w.getOtherEntities(null, box).isEmpty()) continue;
                    bestD = d;
                    best = pos;
                }
            }
        }
        if (best == null) {
            status = "Idle: no free obsidian in range";
            return false;
        }
        putCrystal(mc, p, best, crystalOff, cSlot, now);
        status = "Idle: placed crystal";
        return true;
    }

    // ---------------- helpers ----------------
    private static void putCrystal(MinecraftClient mc, ClientPlayerEntity p, BlockPos base, boolean off, int cSlot, long now) {
        Hand hand = off ? Hand.OFF_HAND : select(p, cSlot);
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5), Direction.UP, base, false);
        mc.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
        recent.put(base, now);
    }

    /** Selects a hotbar slot (remembering the old one) and returns the hand to use. */
    private static Hand select(ClientPlayerEntity p, int slot) {
        if (p.getInventory().selectedSlot != slot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
        }
        return Hand.MAIN_HAND;
    }
}
