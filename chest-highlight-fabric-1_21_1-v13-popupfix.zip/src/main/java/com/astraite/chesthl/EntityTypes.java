package com.astraite.chesthl;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** All living entity types of the game, for the Kill Aura entity selector. */
public final class EntityTypes {
    private static List<EntityType<?>> living = null;

    private EntityTypes() {
    }

    public static String id(EntityType<?> t) {
        return Registries.ENTITY_TYPE.getId(t).toString();
    }

    public static synchronized List<EntityType<?>> living(ClientWorld w) {
        if (living != null) return living;
        List<EntityType<?>> l = new ArrayList<>();
        for (EntityType<?> t : Registries.ENTITY_TYPE) {
            if (t == EntityType.PLAYER) {
                l.add(t);
                continue;
            }
            try {
                Entity e = t.create(w);
                if (e instanceof LivingEntity) l.add(t);
            } catch (Throwable ignored) {
            }
        }
        l.sort(Comparator.comparing(t -> t.getName().getString().toLowerCase()));
        living = l;
        return l;
    }

    /** First start: select players + every hostile (monster) type. */
    public static void ensureDefaults(ClientWorld w) {
        if (Config.auraEntitiesInit) return;
        Config.auraEntitiesInit = true;
        Config.auraEntityTypes.add(id(EntityType.PLAYER));
        for (EntityType<?> t : living(w)) {
            if (t.getSpawnGroup() == SpawnGroup.MONSTER) Config.auraEntityTypes.add(id(t));
        }
        Config.save();
    }
}
