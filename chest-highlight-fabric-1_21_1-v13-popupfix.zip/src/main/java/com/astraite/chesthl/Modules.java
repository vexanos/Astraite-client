package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/** Registry of every module shown in the click GUI, bound to the Config fields. */
final class Modules {
    private Modules() {
    }

    static List<Module> all() {
        List<Module> l = new ArrayList<>();
        Module.Category combat = Module.Category.COMBAT;
        Module.Category player = Module.Category.PLAYER;
        Module.Category render = Module.Category.RENDER;
        Module.Category misc = Module.Category.MISC;

        // ---------------- Combat ----------------
        l.add(Module.toggle("Kill Aura", combat, () -> Config.killAura, v -> Config.killAura = v, null)
                // General
                .choice("Weapon", new String[]{"Any", "Sword", "Axe", "Mace", "Trident", "All"}, () -> Config.auraWeapon, v -> Config.auraWeapon = v)
                .choice("Rotate", new String[]{"Always", "On Hit", "None"}, () -> Config.auraRotateMode, v -> Config.auraRotateMode = v)
                .bool("Auto Switch", () -> Config.auraAutoSwitch, v -> Config.auraAutoSwitch = v, null)
                .bool("Only On Click", () -> Config.auraOnlyClick, v -> Config.auraOnlyClick = v, null)
                .bool("Only On Look", () -> Config.auraOnlyLook, v -> Config.auraOnlyLook = v, null)
                .bool("Pause Baritone", () -> Config.auraPauseBaritone, v -> Config.auraPauseBaritone = v, null)
                .choice("Shield Mode", new String[]{"Ignore", "Break", "None"}, () -> Config.auraShield, v -> Config.auraShield = v)
                // Targeting
                .button("Entities", () -> "Select (" + Config.auraEntityTypes.size() + ")",
                        () -> MinecraftClient.getInstance().setScreen(new EntityListScreen(MinecraftClient.getInstance().currentScreen)))
                .choice("Priority", new String[]{"ClosestAngle", "LowestDistance", "HighestDistance", "LowestHealth", "HighestHealth"}, () -> Config.auraPriority, v -> Config.auraPriority = v)
                .num("Max Targets", 1, 5, () -> Config.auraMaxTargets, v -> Config.auraMaxTargets = v, null)
                .dec("Range", 10, 60, () -> Config.auraRange10, v -> Config.auraRange10 = v, null)
                .dec("Walls Range", 0, 60, () -> Config.auraWalls10, v -> Config.auraWalls10 = v, null)
                .choice("Mob Age Filter", new String[]{"Both", "Baby", "Adult"}, () -> Config.auraAge, v -> Config.auraAge = v)
                .bool("Ignore Named", () -> Config.auraIgnoreNamed, v -> Config.auraIgnoreNamed = v, null)
                .bool("Ignore Passive", () -> Config.auraIgnorePassive, v -> Config.auraIgnorePassive = v, null)
                .bool("Ignore Tamed", () -> Config.auraIgnoreTamed, v -> Config.auraIgnoreTamed = v, null)
                // Timing
                .bool("Pause On Lag", () -> Config.auraPauseLag, v -> Config.auraPauseLag = v, null)
                .bool("Pause On Use", () -> Config.auraPauseUse, v -> Config.auraPauseUse = v, null)
                .bool("Pause On CA", () -> Config.auraPauseCA, v -> Config.auraPauseCA = v, null)
                .bool("TPS Sync", () -> Config.auraTpsSync, v -> Config.auraTpsSync = v, null)
                .bool("Custom Delay", () -> Config.auraCustomDelay, v -> Config.auraCustomDelay = v, null)
                .num("Hit Delay", 0, 60, () -> Config.auraHitDelay, v -> Config.auraHitDelay = v, null)
                .num("Switch Delay", 0, 10, () -> Config.auraSwitchDelay, v -> Config.auraSwitchDelay = v, null));

        l.add(Module.toggle("Crystal Aura", combat, () -> Config.crystalAura, v -> Config.crystalAura = v, null)
                .bool("Place", () -> Config.crystalPlace, v -> Config.crystalPlace = v, null)
                .bool("Break", () -> Config.crystalBreak, v -> Config.crystalBreak = v, null)
                .bool("Idle place", () -> Config.crystalIdle, v -> Config.crystalIdle = v, null)
                .bool("Auto obsidian", () -> Config.crystalObsidian, v -> Config.crystalObsidian = v, null)
                .bool("Target mobs", () -> Config.crystalMobs, v -> Config.crystalMobs = v, null)
                .num("Crystal slot", 1, 9, () -> Config.crystalSlot, v -> Config.crystalSlot = v, null)
                .num("Obsidian slot", 1, 9, () -> Config.obsidianSlot, v -> Config.obsidianSlot = v, null)
                .num("Place range", 2, 6, () -> Config.crystalPlaceRange, v -> Config.crystalPlaceRange = v, null)
                .num("Break range", 2, 6, () -> Config.crystalBreakRange, v -> Config.crystalBreakRange = v, null)
                .num("Min dmg", 0, 36, () -> Config.crystalMinDmg, v -> Config.crystalMinDmg = v, null)
                .num("Max self", 1, 36, () -> Config.crystalMaxSelf, v -> Config.crystalMaxSelf = v, null)
                .num("Target range", 4, 12, () -> Config.crystalTargetRange, v -> Config.crystalTargetRange = v, null)
                .num("Place delay", 0, 10, () -> Config.crystalPlaceDelay, v -> Config.crystalPlaceDelay = v, null)
                .num("Break delay", 0, 10, () -> Config.crystalBreakDelay, v -> Config.crystalBreakDelay = v, null));

        l.add(Module.toggle("Auto Anchor", combat, () -> Config.autoAnchor, v -> Config.autoAnchor = v, null)
                .bool("Place anchor", () -> Config.anchorPlace, v -> Config.anchorPlace = v, null)
                .bool("Switch back", () -> Config.anchorSwitchBack, v -> Config.anchorSwitchBack = v, null)
                .bool("Target mobs", () -> Config.anchorMobs, v -> Config.anchorMobs = v, null)
                .num("Anchor slot", 1, 9, () -> Config.anchorSlot, v -> Config.anchorSlot = v, null)
                .num("Glowstone slot", 1, 9, () -> Config.glowSlot, v -> Config.glowSlot = v, null)
                .num("Range", 2, 6, () -> Config.anchorRange, v -> Config.anchorRange = v, null)
                .num("Min dmg", 1, 36, () -> Config.anchorMinDmg, v -> Config.anchorMinDmg = v, null)
                .num("Max self", 1, 36, () -> Config.anchorMaxSelf, v -> Config.anchorMaxSelf = v, null)
                .num("Target range", 4, 12, () -> Config.anchorTargetRange, v -> Config.anchorTargetRange = v, null)
                .num("Delay", 0, 10, () -> Config.anchorDelay, v -> Config.anchorDelay = v, null));

        l.add(Module.toggle("Auto Totem", combat, () -> Config.autoTotem, v -> Config.autoTotem = v, null)
                .num("Delay", 0, 10, () -> Config.totemDelay, v -> Config.totemDelay = v, null));

        l.add(Module.toggle("Auto Armor", combat, () -> Config.autoArmor, v -> Config.autoArmor = v, null)
                .num("Delay", 0, 10, () -> Config.armorDelay, v -> Config.armorDelay = v, null));

        // ---------------- Player ----------------
        l.add(Module.toggle("Auto Eat", player, () -> Config.autoEat, v -> Config.autoEat = v, null)
                .choice("Mode", new String[]{"Hunger", "Health", "Any"}, () -> Config.eatMode, v -> Config.eatMode = v)
                .num("Hunger <=", 1, 19, () -> Config.eatHunger, v -> Config.eatHunger = v, null)
                .num("Health <=", 1, 19, () -> Config.eatHealth, v -> Config.eatHealth = v, null)
                .bool("Pause auras", () -> Config.pauseAuras, v -> Config.pauseAuras = v, null));

        // ---------------- Render ----------------
        Module base = Module.toggle("Base ESP", render, () -> Config.enabled, v -> Config.enabled = v, BaseScanner::rescan)
                .bool("Walls", () -> Config.throughWalls, v -> Config.throughWalls = v, null)
                .bool("Fill", () -> Config.fill, v -> Config.fill = v, null)
                .num("Range", 16, 128, () -> Config.range, v -> Config.range = v, BaseScanner::rescan);
        for (int k = 0; k < BaseScanner.N; k++) {
            final int idx = BaseScanner.ORDER[k];
            base.bool(BaseScanner.NAMES[idx], () -> Config.baseTypes[idx], v -> Config.baseTypes[idx] = v, BaseScanner::rescan);
        }
        l.add(base);

        Module ore = Module.toggle("Ore ESP", render, () -> Config.oreEnabled, v -> Config.oreEnabled = v, OreScanner::rescan)
                .bool("Walls", () -> Config.throughWalls, v -> Config.throughWalls = v, null)
                .bool("Fill", () -> Config.fill, v -> Config.fill = v, null)
                .num("Range", 8, 48, () -> Config.oreRange, v -> Config.oreRange = v, OreScanner::rescan);
        for (int i = 0; i < OreScanner.NAMES.length; i++) {
            final int idx = i;
            ore.bool(OreScanner.NAMES[i], () -> Config.oreTypes[idx], v -> Config.oreTypes[idx] = v, OreScanner::rescan);
        }
        l.add(ore);

        // ---------------- Misc ----------------
        l.add(Module.action("Accounts", misc, () -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.setScreen(new AccountScreen(mc.currentScreen));
        }));
        l.add(Module.toggle("HUD Status", misc, () -> Config.hudStatus, v -> Config.hudStatus = v, null));

        return l;
    }
}
