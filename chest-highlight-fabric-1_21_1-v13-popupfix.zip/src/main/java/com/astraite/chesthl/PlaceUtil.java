package com.astraite.chesthl;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Shared helpers for AutoCrystal / AutoAnchor. */
final class PlaceUtil {
    private PlaceUtil() {
    }

    static int slotIdx(int cfg) {
        return MathHelper.clamp(cfg, 1, 9) - 1;
    }

    /** Nearest valid target: other players, and optionally hostile mobs. */
    static LivingEntity target(ClientWorld w, ClientPlayerEntity p, double range, boolean mobs) {
        LivingEntity best = null;
        double bestD = range;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;
            if (le instanceof PlayerEntity pe) {
                if (pe.isSpectator() || pe.isCreative()) continue;
            } else if (!(mobs && le instanceof HostileEntity)) {
                continue;
            }
            double d = p.distanceTo(le);
            if (d < bestD) {
                bestD = d;
                best = le;
            }
        }
        return best;
    }

    private static boolean interactive(Block b) {
        return b == Blocks.CRAFTING_TABLE || b == Blocks.NOTE_BLOCK || b == Blocks.RESPAWN_ANCHOR
                || b == Blocks.SMITHING_TABLE || b == Blocks.CARTOGRAPHY_TABLE || b == Blocks.LOOM
                || b == Blocks.GRINDSTONE || b == Blocks.STONECUTTER;
    }

    /** A click on a neighbouring solid block that places a block at 'a' (null if nothing to click on). */
    static BlockHitResult hitFor(ClientWorld w, BlockPos a) {
        for (Direction side : Direction.values()) { // DOWN first = place on top of the floor
            BlockPos n = a.offset(side);
            BlockState st = w.getBlockState(n);
            if (st.isAir() || !st.isFullCube(w, n) || st.hasBlockEntity() || interactive(st.getBlock())) continue;
            Direction face = side.getOpposite();
            Vec3d hp = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            return new BlockHitResult(hp, face, n, false);
        }
        return null;
    }

    /** Rough explosion damage (no raycast exposure, no enchant/effect reduction). power: crystal 6, anchor 5. */
    static double damage(LivingEntity t, Vec3d pos, double power) {
        double radius = power * 2.0;
        double d = t.getPos().distanceTo(pos) / radius;
        if (d > 1.0) return 0;
        double impact = 1.0 - d;
        double dmg = (impact * impact + impact) / 2.0 * 7.0 * radius + 1.0;
        double armor = t.getAttributeValue(EntityAttributes.GENERIC_ARMOR);
        double tough = t.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        double red = Math.min(20.0, Math.max(armor / 5.0, armor - dmg / (2.0 + tough / 4.0)));
        return dmg * (1.0 - red / 25.0);
    }

    static boolean safe(ClientPlayerEntity p, double tgt, double self, int min, int maxSelf) {
        if (tgt < min || self > maxSelf) return false;
        return self < p.getHealth() + p.getAbsorptionAmount() - 1.0;
    }

    static double closestSq(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.squaredDistanceTo(x, y, z);
    }
}
