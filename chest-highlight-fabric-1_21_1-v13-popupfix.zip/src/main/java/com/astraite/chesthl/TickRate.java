package com.astraite.chesthl;

/** Estimates server TPS from the world-time packets (one per 20 server ticks). */
public final class TickRate {
    private static final float[] samples = new float[5];
    private static int idx = 0, count = 0;
    private static long last = 0;
    private static float tps = 20f;

    private TickRate() {
    }

    public static void onTimeUpdate() {
        long now = System.nanoTime();
        if (last != 0) {
            float sec = (now - last) / 1_000_000_000f;
            if (sec > 0.05f) {
                samples[idx] = Math.max(0f, Math.min(20f, 20f / sec));
                idx = (idx + 1) % samples.length;
                count = Math.min(count + 1, samples.length);
                float sum = 0;
                for (int i = 0; i < count; i++) sum += samples[i];
                tps = sum / count;
            }
        }
        last = now;
    }

    public static void reset() {
        last = 0;
        count = 0;
        idx = 0;
        tps = 20f;
    }

    public static float tps() {
        return tps;
    }

    /** Seconds since the last time packet (0 while we have no data). */
    public static float sinceLast() {
        return last == 0 ? 0f : (System.nanoTime() - last) / 1_000_000_000f;
    }
}
