package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;

/** Look around with the camera while the player keeps facing (and moving) the same way. */
public final class Freelook {
    private static float yaw, pitch;
    private static boolean init;

    private Freelook() {
    }

    public static boolean active() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || Freecam.active()) return false;
        boolean key = ChestHighlightClient.freelookKey != null && ChestHighlightClient.freelookKey.isPressed();
        if (Config.freelookHold) return key;
        return Config.freelook || key;
    }

    public static void reset() {
        init = false;
    }

    private static void ensure() {
        if (init) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        yaw = mc.player.getYaw();
        pitch = mc.player.getPitch();
        init = true;
    }

    public static float yaw() {
        ensure();
        return yaw;
    }

    public static float pitch() {
        ensure();
        return pitch;
    }

    public static void rotate(double dx, double dy) {
        ensure();
        yaw += (float) dx * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
    }
}
