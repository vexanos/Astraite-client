package com.astraite.chesthl;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ChestHighlightClient implements ClientModInitializer {
    public static KeyBinding openKey;
    public static KeyBinding freelookKey;
    public static boolean pendingOpen = false;

    // one key per module, all unbound by default (set them in Controls > Base Finder)
    private static final java.util.List<Module> keyModules = new java.util.ArrayList<>();
    private static final java.util.List<KeyBinding> moduleKeys = new java.util.ArrayList<>();

    @Override
    public void onInitializeClient() {
        Config.load();
        AccountManager.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chesthl.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.chesthl"));

        freelookKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.chesthl.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.chesthl"));

        for (Module m : Modules.all()) {
            keyModules.add(m);
            moduleKeys.add(KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.chesthl.mod." + m.name.toLowerCase().replace(' ', '_'),
                    InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, "category.chesthl")));
        }

        // /chesthl opens the menu (useful on mobile where keybinds are awkward)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("chesthl").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
            dispatcher.register(ClientCommandManager.literal("basefinder").executes(ctx -> {
                pendingOpen = true;
                return 1;
            }));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) pendingOpen = true;
            for (int i = 0; i < moduleKeys.size(); i++) {
                Module m = keyModules.get(i);
                while (moduleKeys.get(i).wasPressed()) {
                    if (client.player == null || client.currentScreen != null) continue;
                    m.click();
                    if (m.isToggle()) {
                        Config.save();
                        client.inGameHud.setOverlayMessage(Text.literal(m.name + (m.isOn() ? " ON" : " OFF")), false);
                    }
                }
            }
            OreScanner.tick(client);
            BaseScanner.tick(client);
            AccountManager.tick(client);
            AutoTotem.tick(client);
            AutoArmor.tick(client);
            AutoEat.tick(client);
            KillAura.tick(client);
            CrystalAura.tick(client);
            AutoAnchor.tick(client);
            Fullbright.tick(client);
            Freelook.tick(client);
            if (pendingOpen && client.player != null && client.currentScreen == null) {
                pendingOpen = false;
                client.setScreen(new ClickGui(null));
            }
        });

        WorldRenderEvents.LAST.register(BaseRenderer::render);

        // small status lines (why crystal/anchor is or is not doing something)
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!Config.hudStatus || mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;
            int y = 4;
            if (Config.crystalAura && !CrystalAura.status.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "CrystalAura: " + CrystalAura.status, 4, y, 0xFFFFFF);
                y += 10;
            }
            if (Config.autoAnchor && !AutoAnchor.status.isEmpty()) {
                ctx.drawTextWithShadow(mc.textRenderer, "Anchor: " + AutoAnchor.status, 4, y, 0xFFFFFF);
            }
        });

        // Button on the title screen so the menu (and account switch) is reachable outside a world
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Base Finder"),
                        b -> client.setScreen(new ClickGui(screen))).dimensions(4, 4, 80, 20).build());
            }
        });
    }
}
