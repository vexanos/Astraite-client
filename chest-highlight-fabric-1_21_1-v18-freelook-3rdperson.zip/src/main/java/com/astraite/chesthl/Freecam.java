package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

/** Detached camera: the real player stands still while the view flies around. */
public final class Freecam {
    private static double x, y, z;
    private static float yaw, pitch;
    private static boolean init;
    private static long last;

    private Freecam() {
    }

    public static boolean active() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return Config.freecam && mc.player != null && mc.world != null;
    }

    public static void reset() {
        init = false;
    }

    public static double x() { return x; }
    public static double y() { return y; }
    public static double z() { return z; }
    public static float yaw() { return yaw; }
    public static float pitch() { return pitch; }

    /** Mouse movement goes to the camera instead of the player. */
    public static void rotate(double dx, double dy) {
        if (!init) return;
        yaw += (float) dx * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
    }

    /** Called once per rendered frame (from the camera mixin). */
    public static void frame(Vec3d camPos, float camYaw, float camPitch) {
        long now = System.nanoTime();
        if (!init) {
            x = camPos.x;
            y = camPos.y;
            z = camPos.z;
            yaw = camYaw;
            pitch = camPitch;
            init = true;
            last = now;
            return;
        }
        double dt = Math.min(0.1, (now - last) / 1e9);
        last = now;

        GameOptions o = MinecraftClient.getInstance().options;
        double fwd = 0, side = 0, up = 0;
        if (o.forwardKey.isPressed()) fwd += 1;
        if (o.backKey.isPressed()) fwd -= 1;
        if (o.rightKey.isPressed()) side += 1;
        if (o.leftKey.isPressed()) side -= 1;
        if (o.jumpKey.isPressed()) up += 1;
        if (o.sneakKey.isPressed()) up -= 1;
        if (fwd == 0 && side == 0 && up == 0) return;

        double yr = Math.toRadians(yaw), pr = Math.toRadians(pitch);
        double fx = -Math.sin(yr) * Math.cos(pr);
        double fy = -Math.sin(pr);
        double fz = Math.cos(yr) * Math.cos(pr);
        double rx = -Math.cos(yr);
        double rz = -Math.sin(yr);

        double dx = fx * fwd + rx * side;
        double dy = fy * fwd + up;
        double dz = fz * fwd + rz * side;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6) return;
        double step = Config.freecamSpeed * dt / len;
        x += dx * step;
        y += dy * step;
        z += dz * step;
    }
}
