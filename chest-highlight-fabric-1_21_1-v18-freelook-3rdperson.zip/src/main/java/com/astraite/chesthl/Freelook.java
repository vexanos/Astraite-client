package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;

/** Look around with the camera while the player keeps facing (and moving) the same way. */
public final class Freelook {
    private static float yaw, pitch;
    private static boolean init;
    private static boolean wasOn;
    private static boolean changedPerspective;
    private static Perspective prev;

    private Freelook() {
    }

    public static boolean active() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || Freecam.active()) return false;
        boolean key = ChestHighlightClient.freelookKey != null && ChestHighlightClient.freelookKey.isPressed();
        if (Config.freelookHold) return key;
        return Config.freelook || key;
    }

    /** Switches to third person while Free Look is on, and back afterwards. */
    public static void tick(MinecraftClient mc) {
        boolean on = active();
        if (on && !wasOn) {
            prev = mc.options.getPerspective();
            changedPerspective = prev.isFirstPerson();
            if (changedPerspective) mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!on && wasOn) {
            if (changedPerspective && prev != null) mc.options.setPerspective(prev);
            changedPerspective = false;
        }
        wasOn = on;
    }

    public static void reset() {
        init = false;
    }

    private static void ensure() {
        if (init) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        yaw = mc.player.getYaw();
        pitch = mc.player.getPitch();
        init = true;
    }

    public static float yaw() {
        ensure();
        return yaw;
    }

    public static float pitch() {
        ensure();
        return pitch;
    }

    public static void rotate(double dx, double dy) {
        ensure();
        yaw += (float) dx * 0.15f;
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) dy * 0.15f));
    }
}
