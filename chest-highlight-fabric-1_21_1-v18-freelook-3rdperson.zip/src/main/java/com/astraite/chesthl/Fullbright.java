package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision: full brightness everywhere, no flicker, no HUD icon. */
final class Fullbright {
    private static boolean applied;

    private Fullbright() {
    }

    static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            applied = false;
            return;
        }
        if (Config.fullbright) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 600) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
            }
            applied = true;
        } else if (applied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            applied = false;
        }
    }
}
