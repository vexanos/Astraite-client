package com.astraite.chesthl.mixin;

import com.astraite.chesthl.Freecam;
import com.astraite.chesthl.Freelook;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    private boolean thirdPerson;

    @Shadow
    protected abstract void setPos(double x, double y, double z);

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Shadow
    public abstract Vec3d getPos();

    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    /** Free Look: vanilla builds the (third person) camera from the player's rotation; swap in the free one. */
    @ModifyArgs(method = "update", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0))
    private void chesthl_freelook(Args args) {
        if (Freelook.active()) {
            args.set(0, Freelook.yaw());
            args.set(1, Freelook.pitch());
        }
    }

    @Inject(method = "update", at = @At("TAIL"))
    private void chesthl_freecam(BlockView area, Entity focused, boolean tp, boolean inverse, float tickDelta, CallbackInfo ci) {
        if (!Freecam.active()) {
            Freecam.reset();
            if (!Freelook.active()) Freelook.reset();
            return;
        }
        Freelook.reset();
        Freecam.frame(getPos(), getYaw(), getPitch());
        setPos(Freecam.x(), Freecam.y(), Freecam.z());
        setRotation(Freecam.yaw(), Freecam.pitch());
        this.thirdPerson = true; // so your own player model is drawn
    }
}
