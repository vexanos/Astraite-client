package com.astraite.chesthl.mixin;

import com.astraite.chesthl.Freecam;
import com.astraite.chesthl.Freelook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void chesthl_look(double dx, double dy, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        if (Freecam.active()) {
            Freecam.rotate(dx, dy);
            ci.cancel();
        } else if (Freelook.active()) {
            Freelook.rotate(dx, dy);
            ci.cancel();
        }
    }
}
