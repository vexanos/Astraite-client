package com.astraite.chesthl.mixin;

import com.astraite.chesthl.Freecam;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void chesthl_freeze(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        if (!Freecam.active()) return;
        Input in = (Input) (Object) this;
        in.pressingForward = false;
        in.pressingBack = false;
        in.pressingLeft = false;
        in.pressingRight = false;
        in.jumping = false;
        in.sneaking = false;
        in.movementForward = 0f;
        in.movementSideways = 0f;
    }
}
