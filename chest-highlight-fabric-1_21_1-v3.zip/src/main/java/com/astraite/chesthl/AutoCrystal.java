package com.astraite.chesthl;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AutoCrystal {
    private static int placeCd = 0, breakCd = 0;
    private static int prevSlot = -1;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.autoCrystal || p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) return;

        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;

        PlayerEntity target = findTarget(w, p);
        if (target == null) return;

        if (Config.crystalBreak && breakCd == 0 && doBreak(mc, w, p, target)) breakCd = Config.crystalBreakDelay;
        if (Config.crystalPlace && placeCd == 0 && doPlace(mc, w, p, target)) placeCd = Config.crystalPlaceDelay;

        if (Config.crystalSwitchBack && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    private static PlayerEntity findTarget(ClientWorld w, ClientPlayerEntity p) {
        PlayerEntity best = null;
        double bestD = Config.crystalTargetRange;
        for (PlayerEntity o : w.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator() || o.isCreative()) continue;
            double d = p.distanceTo(o);
            if (d < bestD) {
                bestD = d;
                best = o;
            }
        }
        return best;
    }

    // ---------------- break ----------------
    private static boolean doBreak(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, PlayerEntity target) {
        Vec3d eye = p.getEyePos();
        double r = Config.crystalBreakRange;
        EndCrystalEntity best = null;
        double bestScore = -1e9;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (closest(eye, c.getBoundingBox()) > r * r) continue;
            Vec3d pos = c.getPos();
            double tgt = damage(target, pos);
            double self = damage(p, pos);
            if (!ok(p, tgt, self)) continue;
            double sc = tgt - self;
            if (sc > bestScore) {
                bestScore = sc;
                best = c;
            }
        }
        if (best == null) return false;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    // ---------------- place ----------------
    private static boolean doPlace(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, PlayerEntity target) {
        boolean offhand = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        int slot = MathHelper.clamp(Config.crystalSlot, 1, 9) - 1;
        boolean inSlot = p.getInventory().getStack(slot).isOf(Items.END_CRYSTAL);
        if (!offhand && !inSlot) return false;

        Vec3d eye = p.getEyePos();
        double r = Config.crystalPlaceRange;
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();
        BlockPos bestPos = null;
        double bestScore = -1e9;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (!w.getBlockState(m).isOf(Blocks.OBSIDIAN) && !w.getBlockState(m).isOf(Blocks.BEDROCK)) continue;
                    if (!w.isAir(m.up()) || !w.isAir(m.up(2))) continue;
                    double ex = m.getX() + 0.5, ey = m.getY() + 1.0, ez = m.getZ() + 0.5;
                    if (eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5) > r * r) continue;
                    Vec3d cpos = new Vec3d(ex, ey, ez);
                    double tgt = damage(target, cpos);
                    if (tgt < Config.crystalMinDmg) continue;
                    double self = damage(p, cpos);
                    if (!ok(p, tgt, self)) continue;
                    Box box = new Box(m.getX(), m.getY() + 1, m.getZ(), m.getX() + 1, m.getY() + 3, m.getZ() + 1);
                    if (!w.getOtherEntities(null, box).isEmpty()) continue;
                    double sc = tgt - self;
                    if (sc > bestScore) {
                        bestScore = sc;
                        bestPos = m.toImmutable();
                    }
                }
            }
        }
        if (bestPos == null) return false;

        Hand hand = Hand.OFF_HAND;
        if (!offhand) {
            hand = Hand.MAIN_HAND;
            if (p.getInventory().selectedSlot != slot) {
                if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = slot;
            }
        }
        BlockHitResult hit = new BlockHitResult(
                new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5), Direction.UP, bestPos, false);
        mc.interactionManager.interactBlock(p, hand, hit);
        p.swingHand(hand);
        return true;
    }

    // ---------------- helpers ----------------
    private static boolean ok(ClientPlayerEntity p, double tgt, double self) {
        if (tgt < Config.crystalMinDmg) return false;
        if (self > Config.crystalMaxSelf) return false;
        return self < p.getHealth() + p.getAbsorptionAmount() - 1.0;
    }

    private static double closest(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.squaredDistanceTo(x, y, z);
    }

    /** Rough crystal explosion damage (no raycast exposure, no enchant/effect reduction). */
    private static double damage(LivingEntity t, Vec3d pos) {
        double d = t.getPos().distanceTo(pos) / 12.0;
        if (d > 1.0) return 0;
        double impact = 1.0 - d;
        double dmg = (impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0;
        double armor = t.getAttributeValue(EntityAttributes.GENERIC_ARMOR);
        double tough = t.getAttributeValue(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        double red = Math.min(20.0, Math.max(armor / 5.0, armor - dmg / (2.0 + tough / 4.0)));
        return dmg * (1.0 - red / 25.0);
    }
}
