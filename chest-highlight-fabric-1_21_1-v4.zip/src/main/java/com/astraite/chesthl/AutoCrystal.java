package com.astraite.chesthl;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class AutoCrystal {
    /** Shown on the HUD / menu so you can see why it is (not) doing something. */
    public static String status = "";
    private static int placeCd = 0, breakCd = 0;
    private static int prevSlot = -1;

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!Config.autoCrystal) {
            status = "";
            return;
        }
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) {
            status = "Paused (eating)";
            return;
        }

        if (placeCd > 0) placeCd--;
        if (breakCd > 0) breakCd--;

        LivingEntity target = PlaceUtil.target(w, p, Config.crystalTargetRange, Config.crystalMobs);
        if (target == null) {
            status = "No target within " + Config.crystalTargetRange + " blocks";
            return;
        }
        status = "Target: " + target.getName().getString();

        if (Config.crystalBreak && breakCd == 0 && doBreak(mc, w, p, target)) breakCd = Config.crystalBreakDelay;
        if (Config.crystalPlace && placeCd == 0 && doPlace(mc, w, p, target)) placeCd = Config.crystalPlaceDelay;

        if (Config.crystalSwitchBack && prevSlot >= 0) {
            p.getInventory().selectedSlot = prevSlot;
            prevSlot = -1;
        }
    }

    // ---------------- break ----------------
    private static boolean doBreak(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target) {
        Vec3d eye = p.getEyePos();
        double r = Config.crystalBreakRange;
        EndCrystalEntity best = null;
        double bestScore = -1e9;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || !c.isAlive()) continue;
            if (PlaceUtil.closestSq(eye, c.getBoundingBox()) > r * r) continue;
            Vec3d pos = c.getPos();
            double tgt = PlaceUtil.damage(target, pos, 6.0);
            double self = PlaceUtil.damage(p, pos, 6.0);
            if (!PlaceUtil.safe(p, tgt, self, Config.crystalMinDmg, Config.crystalMaxSelf)) continue;
            if (tgt - self > bestScore) {
                bestScore = tgt - self;
                best = c;
            }
        }
        if (best == null) return false;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        status = "Broke crystal";
        return true;
    }

    // ---------------- place (crystal, and obsidian if there is no base) ----------------
    private static boolean doPlace(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, LivingEntity target) {
        int cSlot = PlaceUtil.slotIdx(Config.crystalSlot);
        boolean crystalOff = p.getOffHandStack().isOf(Items.END_CRYSTAL);
        boolean crystalSlot = p.getInventory().getStack(cSlot).isOf(Items.END_CRYSTAL);
        if (!crystalOff && !crystalSlot) {
            status = "No crystals in hotbar slot " + Config.crystalSlot;
            return false;
        }

        Vec3d eye = p.getEyePos();
        double r = Config.crystalPlaceRange;
        int ri = (int) Math.ceil(r);
        BlockPos base = p.getBlockPos();

        BlockPos bestBase = null;
        double bestBaseScore = -1e9;
        BlockPos bestObs = null;
        double bestObsScore = -1e9;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -ri; dx <= ri; dx++) {
            for (int dy = -ri; dy <= ri; dy++) {
                for (int dz = -ri; dz <= ri; dz++) {
                    m.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                    if (eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5) > r * r) continue;
                    boolean solidBase = w.getBlockState(m).isOf(Blocks.OBSIDIAN) || w.getBlockState(m).isOf(Blocks.BEDROCK);
                    boolean empty = w.getBlockState(m).isAir();
                    if (!solidBase && !(empty && Config.crystalObsidian)) continue;
                    if (!w.isAir(m.up()) || !w.isAir(m.up(2))) continue;

                    Vec3d cpos = new Vec3d(m.getX() + 0.5, m.getY() + 1.0, m.getZ() + 0.5);
                    double tgt = PlaceUtil.damage(target, cpos, 6.0);
                    double self = PlaceUtil.damage(p, cpos, 6.0);
                    if (!PlaceUtil.safe(p, tgt, self, Config.crystalMinDmg, Config.crystalMaxSelf)) continue;

                    Box box = new Box(m.getX(), m.getY() + 1, m.getZ(), m.getX() + 1, m.getY() + 3, m.getZ() + 1);
                    if (!w.getOtherEntities(null, box).isEmpty()) continue;
                    if (empty) {
                        // an obsidian block here would also need to fit
                        if (!w.getOtherEntities(null, new Box(m)).isEmpty()) continue;
                        if (PlaceUtil.hitFor(w, m.toImmutable()) == null) continue;
                    }

                    double sc = tgt - self;
                    if (solidBase) {
                        if (sc > bestBaseScore) {
                            bestBaseScore = sc;
                            bestBase = m.toImmutable();
                        }
                    } else if (sc > bestObsScore) {
                        bestObsScore = sc;
                        bestObs = m.toImmutable();
                    }
                }
            }
        }

        if (bestBase != null) {
            Hand hand = crystalOff ? Hand.OFF_HAND : select(p, cSlot);
            BlockHitResult hit = new BlockHitResult(
                    new Vec3d(bestBase.getX() + 0.5, bestBase.getY() + 1.0, bestBase.getZ() + 0.5),
                    Direction.UP, bestBase, false);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            status = "Placed crystal";
            return true;
        }

        if (bestObs != null) {
            int oSlot = PlaceUtil.slotIdx(Config.obsidianSlot);
            boolean obsOff = p.getOffHandStack().isOf(Items.OBSIDIAN);
            boolean obsSlot = p.getInventory().getStack(oSlot).isOf(Items.OBSIDIAN);
            if (!obsOff && !obsSlot) {
                status = "No obsidian in hotbar slot " + Config.obsidianSlot;
                return false;
            }
            BlockHitResult hit = PlaceUtil.hitFor(w, bestObs);
            if (hit == null) return false;
            Hand hand = obsOff ? Hand.OFF_HAND : select(p, oSlot);
            mc.interactionManager.interactBlock(p, hand, hit);
            p.swingHand(hand);
            status = "Placed obsidian";
            return true;
        }

        status = "No good spot (try lower Min dmg / higher Max self)";
        return false;
    }

    /** Selects a hotbar slot (remembering the old one) and returns the hand to use. */
    private static Hand select(ClientPlayerEntity p, int slot) {
        if (p.getInventory().selectedSlot != slot) {
            if (prevSlot < 0) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;
        }
        return Hand.MAIN_HAND;
    }
}
