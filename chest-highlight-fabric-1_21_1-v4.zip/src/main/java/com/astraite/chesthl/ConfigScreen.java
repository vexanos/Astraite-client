package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

public class ConfigScreen extends Screen {
    private static final int PER_PAGE = 3;
    private static final int BASE_PER_PAGE = 10;

    private final Screen parent;
    private int left, panelTop, cy;
    private int page = 0; // 0 base, 1 ores, 2 account, 3 combat, 4 crystal, 5 anchor, 6 auto
    private int basePage = 0;
    private int accountPage = 0;
    private String nameValue = "";
    private int seenVersion = AccountManager.version;

    public ConfigScreen(Screen parent) {
        super(Text.literal("Base Finder"));
        this.parent = parent;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    private static Text colored(String name, boolean on) {
        return Text.literal(name).formatted(on ? Formatting.GREEN : Formatting.RED);
    }

    private ButtonWidget toggle(String name, boolean current, int x, int y, int w, Runnable flip, BooleanSupplier get) {
        return ButtonWidget.builder(label(name, current), b -> {
            flip.run();
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
    }

    @Override
    protected void init() {
        left = width / 2 - 156;
        panelTop = Math.max(2, height / 2 - 107);
        cy = panelTop + 46;
        int tabY = panelTop + 20;

        String[] tabs = {"ESP", "Ores", "Account", "Combat", "Crystal", "Anchor", "Auto"};
        for (int t = 0; t < tabs.length; t++) {
            final int tt = t;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(tabs[t]).formatted(page == t ? Formatting.GOLD : Formatting.WHITE), b -> {
                        page = tt;
                        clearAndInit();
                    }).dimensions(left - 11 + t * 48, tabY, 46, 20).build());
        }

        if (page == 0) initBase();
        else if (page == 1) initOres();
        else if (page == 2) initAccount();
        else if (page == 3) initCombat();
        else if (page == 4) initCrystal();
        else if (page == 5) initAnchor();
        else initAuto();

        if (page == 1 || page >= 3) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                    .dimensions(left + 81, cy + 114, 150, 20).build());
        }
    }

    // ---------------- Base tab ----------------
    private int basePages() {
        return (BaseScanner.N + BASE_PER_PAGE - 1) / BASE_PER_PAGE;
    }

    private Text baseName(int idx) {
        return colored(BaseScanner.NAMES[idx], Config.baseTypes[idx]);
    }

    private void initBase() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Enabled", Config.enabled, left, cy, lw,
                () -> {
                    Config.enabled = !Config.enabled;
                    BaseScanner.rescan();
                }, () -> Config.enabled));
        addDrawableChild(toggle("Walls", Config.throughWalls, left, cy + 22, lw,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 44, lw,
                () -> Config.fill = !Config.fill, () -> Config.fill));
        addDrawableChild(new RangeSlider(left, cy + 66, lw, 20));

        for (int i = 0; i < BASE_PER_PAGE; i++) {
            final int slot = basePage * BASE_PER_PAGE + i;
            if (slot >= BaseScanner.N) break;
            final int idx = BaseScanner.ORDER[slot];
            int col = i / 5;
            int row = i % 5;
            addDrawableChild(ButtonWidget.builder(baseName(idx), b -> {
                Config.baseTypes[idx] = !Config.baseTypes[idx];
                b.setMessage(baseName(idx));
                BaseScanner.rescan();
            }).dimensions(left + 108 + col * 104, cy + row * 22, cw, 20).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (basePage > 0) basePage--;
            clearAndInit();
        }).dimensions(left, cy + 114, 40, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 106, cy + 114, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (basePage < basePages() - 1) basePage++;
            clearAndInit();
        }).dimensions(left + 272, cy + 114, 40, 20).build());
    }

    // ---------------- Ores tab ----------------
    private void initOres() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Ore ESP", Config.oreEnabled, left, cy, lw,
                () -> {
                    Config.oreEnabled = !Config.oreEnabled;
                    OreScanner.rescan();
                }, () -> Config.oreEnabled));
        addDrawableChild(new OreRangeSlider(left, cy + 22, lw, 20));
        addDrawableChild(toggle("Walls", Config.throughWalls, left, cy + 44, lw,
                () -> Config.throughWalls = !Config.throughWalls, () -> Config.throughWalls));
        addDrawableChild(toggle("Fill", Config.fill, left, cy + 66, lw,
                () -> Config.fill = !Config.fill, () -> Config.fill));

        for (int i = 0; i < 10; i++) {
            final int idx = i;
            int col = i < 5 ? 0 : 1;
            int row = i % 5;
            addDrawableChild(toggle(OreScanner.NAMES[i], Config.oreTypes[i], left + 108 + col * 104, cy + row * 22, cw,
                    () -> {
                        Config.oreTypes[idx] = !Config.oreTypes[idx];
                        OreScanner.rescan();
                    }, () -> Config.oreTypes[idx]));
        }
    }

    // ---------------- Combat tab ----------------
    private void initCombat() {
        int lw = 104, cw = 100;
        addDrawableChild(toggle("Auto Totem", Config.autoTotem, left, cy, lw,
                () -> Config.autoTotem = !Config.autoTotem, () -> Config.autoTotem));
        addDrawableChild(toggle("Kill Aura", Config.killAura, left, cy + 22, lw,
                () -> Config.killAura = !Config.killAura, () -> Config.killAura));
        addDrawableChild(new AuraRangeSlider(left, cy + 44, lw, 20));
        addDrawableChild(toggle("Rotate", Config.auraRotate, left, cy + 66, lw,
                () -> Config.auraRotate = !Config.auraRotate, () -> Config.auraRotate));

        addDrawableChild(toggle("Players", Config.auraPlayers, left + 108, cy, cw,
                () -> Config.auraPlayers = !Config.auraPlayers, () -> Config.auraPlayers));
        addDrawableChild(toggle("Hostile", Config.auraHostile, left + 108, cy + 22, cw,
                () -> Config.auraHostile = !Config.auraHostile, () -> Config.auraHostile));
        addDrawableChild(toggle("Passive", Config.auraPassive, left + 108, cy + 44, cw,
                () -> Config.auraPassive = !Config.auraPassive, () -> Config.auraPassive));
        addDrawableChild(toggle("Via walls", Config.auraWalls, left + 108, cy + 66, cw,
                () -> Config.auraWalls = !Config.auraWalls, () -> Config.auraWalls));

        addDrawableChild(new TotemDelaySlider(left + 212, cy, 100, 20));
        addDrawableChild(toggle("HUD status", Config.hudStatus, left + 212, cy + 22, 100,
                () -> Config.hudStatus = !Config.hudStatus, () -> Config.hudStatus));
    }

    // ---------------- Crystal tab ----------------
    private void initCrystal() {
        int c1 = left, c2 = left + 106, c3 = left + 212, w = 100;
        addDrawableChild(toggle("Auto Crystal", Config.autoCrystal, c1, cy, w,
                () -> Config.autoCrystal = !Config.autoCrystal, () -> Config.autoCrystal));
        addDrawableChild(new IntSlider(c1, cy + 22, w, 20, "Crystal slot", 1, 9, Config.crystalSlot, v -> Config.crystalSlot = v));
        addDrawableChild(toggle("Place", Config.crystalPlace, c1, cy + 44, w,
                () -> Config.crystalPlace = !Config.crystalPlace, () -> Config.crystalPlace));
        addDrawableChild(toggle("Break", Config.crystalBreak, c1, cy + 66, w,
                () -> Config.crystalBreak = !Config.crystalBreak, () -> Config.crystalBreak));
        addDrawableChild(toggle("Switch back", Config.crystalSwitchBack, c1, cy + 88, w,
                () -> Config.crystalSwitchBack = !Config.crystalSwitchBack, () -> Config.crystalSwitchBack));

        addDrawableChild(new IntSlider(c2, cy, w, 20, "Place range", 2, 6, Config.crystalPlaceRange, v -> Config.crystalPlaceRange = v));
        addDrawableChild(new IntSlider(c2, cy + 22, w, 20, "Break range", 2, 6, Config.crystalBreakRange, v -> Config.crystalBreakRange = v));
        addDrawableChild(new IntSlider(c2, cy + 44, w, 20, "Min dmg", 1, 36, Config.crystalMinDmg, v -> Config.crystalMinDmg = v));
        addDrawableChild(new IntSlider(c2, cy + 66, w, 20, "Max self", 1, 36, Config.crystalMaxSelf, v -> Config.crystalMaxSelf = v));
        addDrawableChild(new IntSlider(c2, cy + 88, w, 20, "Target range", 4, 12, Config.crystalTargetRange, v -> Config.crystalTargetRange = v));

        addDrawableChild(new IntSlider(c3, cy, w, 20, "Place delay", 0, 10, Config.crystalPlaceDelay, v -> Config.crystalPlaceDelay = v));
        addDrawableChild(new IntSlider(c3, cy + 22, w, 20, "Break delay", 0, 10, Config.crystalBreakDelay, v -> Config.crystalBreakDelay = v));
        addDrawableChild(toggle("Auto obsidian", Config.crystalObsidian, c3, cy + 44, w,
                () -> Config.crystalObsidian = !Config.crystalObsidian, () -> Config.crystalObsidian));
        addDrawableChild(new IntSlider(c3, cy + 66, w, 20, "Obsidian slot", 1, 9, Config.obsidianSlot, v -> Config.obsidianSlot = v));
        addDrawableChild(toggle("Target mobs", Config.crystalMobs, c3, cy + 88, w,
                () -> Config.crystalMobs = !Config.crystalMobs, () -> Config.crystalMobs));
    }

    // ---------------- Anchor tab ----------------
    private void initAnchor() {
        int c1 = left, c2 = left + 106, c3 = left + 212, w = 100;
        addDrawableChild(toggle("Auto Anchor", Config.autoAnchor, c1, cy, w,
                () -> Config.autoAnchor = !Config.autoAnchor, () -> Config.autoAnchor));
        addDrawableChild(new IntSlider(c1, cy + 22, w, 20, "Anchor slot", 1, 9, Config.anchorSlot, v -> Config.anchorSlot = v));
        addDrawableChild(new IntSlider(c1, cy + 44, w, 20, "Glowstone slot", 1, 9, Config.glowSlot, v -> Config.glowSlot = v));
        addDrawableChild(toggle("Place anchor", Config.anchorPlace, c1, cy + 66, w,
                () -> Config.anchorPlace = !Config.anchorPlace, () -> Config.anchorPlace));
        addDrawableChild(toggle("Switch back", Config.anchorSwitchBack, c1, cy + 88, w,
                () -> Config.anchorSwitchBack = !Config.anchorSwitchBack, () -> Config.anchorSwitchBack));

        addDrawableChild(new IntSlider(c2, cy, w, 20, "Range", 2, 6, Config.anchorRange, v -> Config.anchorRange = v));
        addDrawableChild(new IntSlider(c2, cy + 22, w, 20, "Min dmg", 1, 36, Config.anchorMinDmg, v -> Config.anchorMinDmg = v));
        addDrawableChild(new IntSlider(c2, cy + 44, w, 20, "Max self", 1, 36, Config.anchorMaxSelf, v -> Config.anchorMaxSelf = v));
        addDrawableChild(new IntSlider(c2, cy + 66, w, 20, "Target range", 4, 12, Config.anchorTargetRange, v -> Config.anchorTargetRange = v));
        addDrawableChild(new IntSlider(c2, cy + 88, w, 20, "Delay", 0, 10, Config.anchorDelay, v -> Config.anchorDelay = v));

        addDrawableChild(toggle("Target mobs", Config.anchorMobs, c3, cy, w,
                () -> Config.anchorMobs = !Config.anchorMobs, () -> Config.anchorMobs));
    }

    // ---------------- Auto tab (eat + armor) ----------------
    private static final String[] EAT_MODES = {"Hunger", "Health", "Any"};

    private void initAuto() {
        int c1 = left, c2 = left + 106, w = 100;
        addDrawableChild(toggle("Auto Eat", Config.autoEat, c1, cy, w,
                () -> Config.autoEat = !Config.autoEat, () -> Config.autoEat));
        addDrawableChild(ButtonWidget.builder(Text.literal("Mode: " + EAT_MODES[Config.eatMode]), b -> {
            Config.eatMode = (Config.eatMode + 1) % 3;
            b.setMessage(Text.literal("Mode: " + EAT_MODES[Config.eatMode]));
        }).dimensions(c1, cy + 22, w, 20).build());
        addDrawableChild(new IntSlider(c1, cy + 44, w, 20, "Hunger <=", 1, 19, Config.eatHunger, v -> Config.eatHunger = v));
        addDrawableChild(new IntSlider(c1, cy + 66, w, 20, "Health <=", 1, 19, Config.eatHealth, v -> Config.eatHealth = v));
        addDrawableChild(toggle("Pause auras", Config.pauseAuras, c1, cy + 88, w,
                () -> Config.pauseAuras = !Config.pauseAuras, () -> Config.pauseAuras));

        addDrawableChild(toggle("Auto Armor", Config.autoArmor, c2, cy, w,
                () -> Config.autoArmor = !Config.autoArmor, () -> Config.autoArmor));
        addDrawableChild(new IntSlider(c2, cy + 22, w, 20, "Armor delay", 0, 10, Config.armorDelay, v -> Config.armorDelay = v));
    }

    // ---------------- Account tab ----------------
    private int totalPages() {
        return Math.max(1, (AccountManager.accounts.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private void initAccount() {
        boolean launcherActive = AccountManager.active.isEmpty();
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Launcher account").formatted(launcherActive ? Formatting.GREEN : Formatting.WHITE)
                        .append(Text.literal(" [Official]").formatted(Formatting.GRAY)), b -> {
                    AccountManager.useOfficial(client);
                    clearAndInit();
                }).dimensions(left, cy + 14, 312, 18).build());

        if (accountPage >= totalPages()) accountPage = totalPages() - 1;
        List<AccountManager.Account> list = AccountManager.accounts;
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = accountPage * PER_PAGE + i;
            if (idx >= list.size()) break;
            final AccountManager.Account a = list.get(idx);
            boolean isActive = a.key().equals(AccountManager.active);
            int y = cy + 34 + i * 20;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(a.name).formatted(isActive ? Formatting.GREEN : Formatting.WHITE)
                            .append(Text.literal(a.isPremium() ? " [Premium]" : " [Cracked]").formatted(Formatting.GRAY)), b -> {
                        AccountManager.switchTo(client, a);
                        clearAndInit();
                    }).dimensions(left, y, 240, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Remove").formatted(Formatting.RED), b -> {
                AccountManager.remove(client, a);
                clearAndInit();
            }).dimensions(left + 244, y, 68, 18).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            if (accountPage > 0) accountPage--;
            clearAndInit();
        }).dimensions(left, cy + 96, 40, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(left + 106, cy + 96, 100, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            if (accountPage < totalPages() - 1) accountPage++;
            clearAndInit();
        }).dimensions(left + 272, cy + 96, 40, 18).build());

        TextFieldWidget field = new TextFieldWidget(textRenderer, left, cy + 118, 150, 18, Text.literal("Cracked username"));
        field.setMaxLength(16);
        field.setText(nameValue);
        field.setChangedListener(s -> nameValue = s);
        addDrawableChild(field);

        addDrawableChild(ButtonWidget.builder(Text.literal("Add cracked"), b -> {
            String n = nameValue.trim();
            if (!AccountManager.validName(n)) {
                AccountManager.status = "Naam 3 se 16 letters/numbers/_ ka hona chahiye";
                AccountManager.version++;
                return;
            }
            nameValue = "";
            AccountManager.addCracked(client, n);
            clearAndInit();
        }).dimensions(left + 154, cy + 118, 78, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Add premium"), b -> {
            AccountManager.beginPremiumLogin(client);
            clearAndInit();
        }).dimensions(left + 236, cy + 118, 76, 18).build());
    }

    @Override
    public void tick() {
        if (seenVersion != AccountManager.version) {
            seenVersion = AccountManager.version;
            if (page == 2) clearAndInit();
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        ctx.fill(left - 16, panelTop, left + 328, page == 2 ? cy + 166 : cy + 150, 0xF0101014);
        ctx.fill(left - 16, panelTop, left + 328, panelTop + 2, 0xFFFFA500);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, panelTop + 7, 0xFFFFFF);
        if (page == 2) {
            String cur = client.getSession().getUsername();
            ctx.drawTextWithShadow(textRenderer, Text.literal("Current: " + cur), left, cy + 3, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, Text.literal((accountPage + 1) + "/" + totalPages()),
                    left + 46, cy + 101, 0xAAAAAA);
            ctx.drawTextWithShadow(textRenderer, Text.literal(AccountManager.status), left, cy + 142, 0xFFFFFF);
            if (!AccountManager.deviceCode.isEmpty()) {
                String url = AccountManager.deviceUrl.replace("https://", "");
                ctx.drawTextWithShadow(textRenderer,
                        Text.literal("Link: " + url + "   Code: " + AccountManager.deviceCode),
                        left, cy + 154, 0xFFD700);
            }
        } else {
            if (page == 0) {
                ctx.drawTextWithShadow(textRenderer, Text.literal((basePage + 1) + "/" + basePages()),
                        left + 46, cy + 120, 0xAAAAAA);
            }
            if (page == 4 || page == 5) {
                String st = page == 4 ? AutoCrystal.status : AutoAnchor.status;
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Status: " + (st.isEmpty() ? "idle (module off?)" : st)),
                        width / 2, cy + 138, 0xFFD700);
            } else {
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Works in singleplayer and multiplayer"),
                        width / 2, cy + 138, 0x888888);
            }
        }
    }

    @Override
    public void removed() {
        Config.save();
        OreScanner.rescan();
        BaseScanner.rescan();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    private static class RangeSlider extends SliderWidget {
        RangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.range - 16) / 112.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (16 + (int) Math.round(value * 112))));
        }

        @Override
        protected void applyValue() {
            Config.range = 16 + (int) Math.round(value * 112);
            BaseScanner.rescan();
        }
    }

    private static class OreRangeSlider extends SliderWidget {
        OreRangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.oreRange - 8) / 40.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Range: " + (8 + (int) Math.round(value * 40))));
        }

        @Override
        protected void applyValue() {
            Config.oreRange = 8 + (int) Math.round(value * 40);
            OreScanner.rescan();
        }
    }

    private static class AuraRangeSlider extends SliderWidget {
        AuraRangeSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (Config.auraRange - 2) / 4.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Reach: " + (2 + (int) Math.round(value * 4))));
        }

        @Override
        protected void applyValue() {
            Config.auraRange = 2 + (int) Math.round(value * 4);
        }
    }

    private static class TotemDelaySlider extends SliderWidget {
        TotemDelaySlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), Config.totemDelay / 10.0);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("Totem delay: " + (int) Math.round(value * 10)));
        }

        @Override
        protected void applyValue() {
            Config.totemDelay = (int) Math.round(value * 10);
        }
    }

    private static class IntSlider extends SliderWidget {
        private final String name;
        private final int min, max;
        private final IntConsumer set;

        IntSlider(int x, int y, int w, int h, String name, int min, int max, int cur, IntConsumer set) {
            super(x, y, w, h, Text.empty(), (cur - min) / (double) (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.set = set;
            updateMessage();
        }

        private int val() {
            return min + (int) Math.round(value * (max - min));
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(name + ": " + val()));
        }

        @Override
        protected void applyValue() {
            set.accept(val());
        }
    }
}
