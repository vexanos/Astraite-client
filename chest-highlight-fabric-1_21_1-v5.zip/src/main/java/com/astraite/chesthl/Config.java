package com.astraite.chesthl;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class Config {
    public static boolean enabled = true;
    public static boolean throughWalls = true;
    public static boolean fill = true;
    public static int range = 64;
    public static boolean[] baseTypes = defaultBase();
    public static boolean oreEnabled = false;
    public static int oreRange = 24;
    // 0 coal,1 iron,2 copper,3 gold,4 redstone,5 lapis,6 diamond,7 emerald,8 debris,9 quartz
    public static boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};

    // combat
    public static boolean autoTotem = false;
    public static int totemDelay = 1;
    public static boolean killAura = false;
    public static int auraRange = 3;
    public static boolean auraPlayers = true;
    public static boolean auraHostile = true;
    public static boolean auraPassive = false;
    public static boolean auraRotate = true;
    public static boolean auraWalls = false;

    // auto crystal
    public static boolean crystalAura = false;
    public static int crystalSlot = 1;          // hotbar slot 1-9
    public static boolean crystalPlace = true;
    public static boolean crystalBreak = true;
    public static int crystalPlaceRange = 4;
    public static int crystalBreakRange = 4;
    public static int crystalMinDmg = 2;
    public static int crystalMaxSelf = 20;
    public static int crystalTargetRange = 8;
    public static int crystalPlaceDelay = 2;
    public static int crystalBreakDelay = 1;
    public static boolean crystalSwitchBack = true;
    public static boolean crystalObsidian = true;   // place obsidian when there is no base block
    public static int obsidianSlot = 2;             // hotbar slot 1-9
    public static boolean crystalMobs = false;      // also target hostile mobs
    public static boolean crystalIdle = true;       // no target: put crystals on every free obsidian

    // auto anchor
    public static boolean autoAnchor = false;
    public static int anchorSlot = 3;               // respawn anchors, hotbar slot 1-9
    public static int glowSlot = 4;                 // glowstone, hotbar slot 1-9
    public static boolean anchorPlace = true;
    public static int anchorRange = 4;
    public static int anchorMinDmg = 4;
    public static int anchorMaxSelf = 10;
    public static int anchorTargetRange = 8;
    public static int anchorDelay = 2;
    public static boolean anchorSwitchBack = true;
    public static boolean anchorMobs = false;

    public static boolean hudStatus = true;

    // auto eat / armor
    public static boolean autoEat = false;
    public static int eatMode = 2;              // 0 hunger, 1 health, 2 any
    public static int eatHunger = 16;
    public static int eatHealth = 10;
    public static boolean pauseAuras = true;
    public static boolean autoArmor = false;
    public static int armorDelay = 2;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("chesthl.json");

    // Noisy / natural blocks start OFF: flower pot, cactus, glowstone, sugar cane, fence
    static boolean[] defaultBase() {
        boolean[] a = new boolean[BaseScanner.N];
        Arrays.fill(a, true);
        a[10] = false;
        a[24] = false;
        a[25] = false;
        a[26] = false;
        a[27] = false;
        a[36] = false; // passive mobs
        a[37] = false; // other mobs
        a[38] = false; // projectiles
        a[39] = false; // xp orbs
        a[41] = false; // boats / minecarts
        return a;
    }

    private static class Data {
        boolean enabled = true;
        boolean throughWalls = true;
        boolean fill = true;
        int range = 64;
        boolean[] baseTypes = defaultBase();
        boolean oreEnabled = false;
        int oreRange = 24;
        boolean[] oreTypes = {true, true, true, true, true, true, true, true, true, true};
        boolean autoTotem = false;
        int totemDelay = 1;
        boolean killAura = false;
        int auraRange = 3;
        boolean auraPlayers = true;
        boolean auraHostile = true;
        boolean auraPassive = false;
        boolean auraRotate = true;
        boolean auraWalls = false;
        boolean crystalAura = false;
        int crystalSlot = 1;
        boolean crystalPlace = true;
        boolean crystalBreak = true;
        int crystalPlaceRange = 4;
        int crystalBreakRange = 4;
        int crystalMinDmg = 2;
        int crystalMaxSelf = 20;
        int crystalTargetRange = 8;
        int crystalPlaceDelay = 2;
        int crystalBreakDelay = 1;
        boolean crystalSwitchBack = true;
        boolean crystalObsidian = true;
        int obsidianSlot = 2;
        boolean crystalMobs = false;
        boolean crystalIdle = true;
        boolean autoAnchor = false;
        int anchorSlot = 3;
        int glowSlot = 4;
        boolean anchorPlace = true;
        int anchorRange = 4;
        int anchorMinDmg = 4;
        int anchorMaxSelf = 10;
        int anchorTargetRange = 8;
        int anchorDelay = 2;
        boolean anchorSwitchBack = true;
        boolean anchorMobs = false;
        boolean hudStatus = true;
        int ver = 0;
        boolean autoEat = false;
        int eatMode = 2;
        int eatHunger = 16;
        int eatHealth = 10;
        boolean pauseAuras = true;
        boolean autoArmor = false;
        int armorDelay = 2;
    }

    private static int c(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static void load() {
        try {
            if (!Files.exists(PATH)) return;
            Data d = GSON.fromJson(Files.readString(PATH), Data.class);
            if (d == null) return;
            enabled = d.enabled;
            throughWalls = d.throughWalls;
            fill = d.fill;
            range = c(d.range, 16, 128);
            if (d.baseTypes != null && d.baseTypes.length == BaseScanner.N) baseTypes = d.baseTypes;
            oreEnabled = d.oreEnabled;
            oreRange = c(d.oreRange, 8, 48);
            if (d.oreTypes != null && d.oreTypes.length == 10) oreTypes = d.oreTypes;
            autoTotem = d.autoTotem;
            totemDelay = c(d.totemDelay, 0, 10);
            killAura = d.killAura;
            auraRange = c(d.auraRange, 2, 6);
            auraPlayers = d.auraPlayers;
            auraHostile = d.auraHostile;
            auraPassive = d.auraPassive;
            auraRotate = d.auraRotate;
            auraWalls = d.auraWalls;
            crystalAura = d.crystalAura;
            crystalSlot = c(d.crystalSlot, 1, 9);
            crystalPlace = d.crystalPlace;
            crystalBreak = d.crystalBreak;
            crystalPlaceRange = c(d.crystalPlaceRange, 2, 6);
            crystalBreakRange = c(d.crystalBreakRange, 2, 6);
            // older configs had too strict damage limits -> reset them once
            crystalMinDmg = d.ver < 3 ? 2 : c(d.crystalMinDmg, 0, 36);
            crystalMaxSelf = d.ver < 3 ? 20 : c(d.crystalMaxSelf, 1, 36);
            crystalTargetRange = c(d.crystalTargetRange, 4, 12);
            crystalPlaceDelay = c(d.crystalPlaceDelay, 0, 10);
            crystalBreakDelay = c(d.crystalBreakDelay, 0, 10);
            crystalSwitchBack = d.crystalSwitchBack;
            crystalObsidian = d.crystalObsidian;
            obsidianSlot = c(d.obsidianSlot, 1, 9);
            crystalMobs = d.crystalMobs;
            crystalIdle = d.ver < 3 || d.crystalIdle;
            autoAnchor = d.autoAnchor;
            anchorSlot = c(d.anchorSlot, 1, 9);
            glowSlot = c(d.glowSlot, 1, 9);
            anchorPlace = d.anchorPlace;
            anchorRange = c(d.anchorRange, 2, 6);
            anchorMinDmg = c(d.anchorMinDmg, 1, 36);
            anchorMaxSelf = c(d.anchorMaxSelf, 1, 36);
            anchorTargetRange = c(d.anchorTargetRange, 4, 12);
            anchorDelay = c(d.anchorDelay, 0, 10);
            anchorSwitchBack = d.anchorSwitchBack;
            anchorMobs = d.anchorMobs;
            hudStatus = d.hudStatus;
            autoEat = d.autoEat;
            eatMode = c(d.eatMode, 0, 2);
            eatHunger = c(d.eatHunger, 1, 19);
            eatHealth = c(d.eatHealth, 1, 19);
            pauseAuras = d.pauseAuras;
            autoArmor = d.autoArmor;
            armorDelay = c(d.armorDelay, 0, 10);
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.throughWalls = throughWalls;
            d.fill = fill;
            d.range = range;
            d.baseTypes = baseTypes;
            d.oreEnabled = oreEnabled;
            d.oreRange = oreRange;
            d.oreTypes = oreTypes;
            d.autoTotem = autoTotem;
            d.totemDelay = totemDelay;
            d.killAura = killAura;
            d.auraRange = auraRange;
            d.auraPlayers = auraPlayers;
            d.auraHostile = auraHostile;
            d.auraPassive = auraPassive;
            d.auraRotate = auraRotate;
            d.auraWalls = auraWalls;
            d.crystalAura = crystalAura;
            d.crystalSlot = crystalSlot;
            d.crystalPlace = crystalPlace;
            d.crystalBreak = crystalBreak;
            d.crystalPlaceRange = crystalPlaceRange;
            d.crystalBreakRange = crystalBreakRange;
            d.crystalMinDmg = crystalMinDmg;
            d.crystalMaxSelf = crystalMaxSelf;
            d.crystalTargetRange = crystalTargetRange;
            d.crystalPlaceDelay = crystalPlaceDelay;
            d.crystalBreakDelay = crystalBreakDelay;
            d.crystalSwitchBack = crystalSwitchBack;
            d.crystalObsidian = crystalObsidian;
            d.obsidianSlot = obsidianSlot;
            d.crystalMobs = crystalMobs;
            d.crystalIdle = crystalIdle;
            d.autoAnchor = autoAnchor;
            d.anchorSlot = anchorSlot;
            d.glowSlot = glowSlot;
            d.anchorPlace = anchorPlace;
            d.anchorRange = anchorRange;
            d.anchorMinDmg = anchorMinDmg;
            d.anchorMaxSelf = anchorMaxSelf;
            d.anchorTargetRange = anchorTargetRange;
            d.anchorDelay = anchorDelay;
            d.anchorSwitchBack = anchorSwitchBack;
            d.anchorMobs = anchorMobs;
            d.hudStatus = hudStatus;
            d.ver = 3;
            d.autoEat = autoEat;
            d.eatMode = eatMode;
            d.eatHunger = eatHunger;
            d.eatHealth = eatHealth;
            d.pauseAuras = pauseAuras;
            d.autoArmor = autoArmor;
            d.armorDelay = armorDelay;
            Files.writeString(PATH, GSON.toJson(d));
        } catch (Exception ignored) {
        }
    }
}
