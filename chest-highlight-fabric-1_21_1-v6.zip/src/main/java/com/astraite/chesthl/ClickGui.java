package com.astraite.chesthl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Meteor-style click GUI: one purple column per category, left click = toggle, right click = settings. */
public class ClickGui extends Screen {
    private static final int PURPLE = 0xFF913DE2;
    private static final int HEADER_H = 14, ROW_H = 12, GAP = 4, TOP = 20;
    private static final String[] TABS = {"Modules", "Accounts"};

    private final Screen parent;
    private final List<List<Module>> byCat = new ArrayList<>();
    private final boolean[] collapsed;

    private Module open = null;
    private List<Module.Setting> rows = new ArrayList<>();
    private Module.Int dragging = null;
    private int dragX, dragW;

    private int colW, startX;
    private int px, py, pw, ph, pcolW, rowsPerCol;

    public ClickGui(Screen parent) {
        super(Text.literal("Base Finder"));
        this.parent = parent;
        List<Module> all = Modules.all();
        for (Module.Category c : Module.Category.values()) {
            List<Module> l = new ArrayList<>();
            for (Module m : all) if (m.category == c) l.add(m);
            byCat.add(l);
        }
        collapsed = new boolean[byCat.size()];
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // keep the world visible, like Meteor
    }

    // ---------------- layout ----------------
    private void layout() {
        int n = byCat.size();
        colW = Math.max(58, Math.min(100, (width - 12 - (n - 1) * GAP) / n));
        int total = n * colW + (n - 1) * GAP;
        startX = (width - total) / 2;
    }

    private int colX(int c) {
        return startX + c * (colW + GAP);
    }

    private void buildRows(Module m) {
        rows = new ArrayList<>();
        if (m.active != null) rows.add(m.active);
        rows.addAll(m.settings);
    }

    private void popupLayout() {
        int n = rows.size();
        int maxRows = Math.max(6, (height - TOP - HEADER_H - 30) / ROW_H);
        int cols = Math.max(1, (n + maxRows - 1) / maxRows);
        rowsPerCol = Math.max(1, (n + cols - 1) / cols);
        pcolW = Math.max(70, Math.min(112, (width - 12) / cols));
        pw = cols * pcolW;
        ph = HEADER_H + rowsPerCol * ROW_H;
        px = (width - pw) / 2;
        py = Math.max(TOP, (height - ph) / 2);
    }

    private int rowX(int i) {
        return px + (i / rowsPerCol) * pcolW;
    }

    private int rowY(int i) {
        return py + HEADER_H + (i % rowsPerCol) * ROW_H;
    }

    private int tabAt(double mx, double my) {
        if (my < 0 || my >= 14) return -1;
        int total = 0;
        for (String t : TABS) total += textRenderer.getWidth(t) + 12;
        int x = (width - total) / 2;
        for (int i = 0; i < TABS.length; i++) {
            int w = textRenderer.getWidth(TABS[i]) + 12;
            if (mx >= x && mx < x + w) return i;
            x += w;
        }
        return -1;
    }

    // ---------------- drawing ----------------
    private static void arrow(DrawContext ctx, int x, int y, boolean down) {
        for (int i = 0; i < 4; i++) {
            int w = 7 - 2 * i;
            int yy = down ? y + i : y + 3 - i;
            ctx.fill(x + i, yy, x + i + w, yy + 1, 0xFFFFFFFF);
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        layout();
        drawTabs(ctx, mx, my);

        Module.Category[] cats = Module.Category.values();
        for (int c = 0; c < byCat.size(); c++) {
            int x = colX(c);
            ctx.fill(x, TOP, x + colW, TOP + HEADER_H, PURPLE);
            ctx.drawCenteredTextWithShadow(textRenderer, cats[c].title, x + colW / 2, TOP + 3, 0xFFFFFFFF);
            arrow(ctx, x + colW - 11, TOP + 5, !collapsed[c]);
            if (collapsed[c]) continue;

            List<Module> l = byCat.get(c);
            for (int i = 0; i < l.size(); i++) {
                Module m = l.get(i);
                int y = TOP + HEADER_H + i * ROW_H;
                boolean hover = open == null && mx >= x && mx < x + colW && my >= y && my < y + ROW_H;
                boolean on = m.isOn();
                int bg = on ? 0xC02A1646 : (hover ? 0xB02C2C38 : 0x99000000);
                ctx.fill(x, y, x + colW, y + ROW_H, bg);
                if (on) ctx.fill(x, y, x + 2, y + ROW_H, PURPLE);
                ctx.drawCenteredTextWithShadow(textRenderer, textRenderer.trimToWidth(m.name, colW - 6),
                        x + colW / 2, y + 2, on ? 0xFFFFFFFF : 0xFFC8C8C8);
            }
        }

        if (open != null) drawPopup(ctx, mx, my);

        ctx.drawTextWithShadow(textRenderer, "Left click - Toggle module", 4, height - 20, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "Right click - Open module settings", 4, height - 10, 0xFFFFFFFF);
    }

    private void drawTabs(DrawContext ctx, int mx, int my) {
        int total = 0;
        for (String t : TABS) total += textRenderer.getWidth(t) + 12;
        int x = (width - total) / 2;
        ctx.fill(x - 2, 0, x + total + 2, 14, 0xB0000000);
        int hover = tabAt(mx, my);
        for (int i = 0; i < TABS.length; i++) {
            int w = textRenderer.getWidth(TABS[i]) + 12;
            boolean sel = i == 0;
            int color = sel || hover == i ? 0xFFFFFFFF : 0xFFAAAAAA;
            ctx.drawCenteredTextWithShadow(textRenderer, TABS[i], x + w / 2, 3, color);
            if (sel) ctx.fill(x + 3, 12, x + w - 3, 13, PURPLE);
            x += w;
        }
    }

    private void drawPopup(DrawContext ctx, int mx, int my) {
        popupLayout();
        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF000000);
        ctx.fill(px, py, px + pw, py + HEADER_H, PURPLE);
        ctx.drawCenteredTextWithShadow(textRenderer, open.name, px + pw / 2, py + 3, 0xFFFFFFFF);
        ctx.fill(px, py + HEADER_H, px + pw, py + ph, 0xE0101018);

        for (int i = 0; i < rows.size(); i++) {
            Module.Setting s = rows.get(i);
            int x = rowX(i), y = rowY(i), w = pcolW;
            boolean hover = mx >= x && mx < x + w && my >= y && my < y + ROW_H;
            ctx.fill(x, y, x + w, y + ROW_H, hover ? 0xC02C2C38 : 0xC0141420);

            if (s instanceof Module.Bool b) {
                ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(b.name, w - 20), x + 4, y + 2, 0xFFE0E0E0);
                int bx = x + w - 11, by = y + 2;
                ctx.fill(bx, by, bx + 8, by + 8, 0xFF808090);
                ctx.fill(bx + 1, by + 1, bx + 7, by + 7, b.value() ? PURPLE : 0xFF141420);
            } else if (s instanceof Module.Int n) {
                int fw = (int) ((w - 2) * n.fraction());
                ctx.fill(x + 1, y + 1, x + 1 + fw, y + ROW_H - 1, 0xA0913DE2);
                ctx.drawCenteredTextWithShadow(textRenderer, textRenderer.trimToWidth(n.name + ": " + n.value(), w - 6),
                        x + w / 2, y + 2, 0xFFFFFFFF);
            } else if (s instanceof Module.Choice c) {
                ctx.drawCenteredTextWithShadow(textRenderer, textRenderer.trimToWidth(c.name + ": " + c.label(), w - 6),
                        x + w / 2, y + 2, 0xFFFFFFFF);
            }
        }
    }

    // ---------------- input ----------------
    private void applyDrag(double mx) {
        if (dragging != null) dragging.setFraction((mx - dragX - 1) / (double) (dragW - 2));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        if (open != null) {
            popupLayout();
            if (mx >= px && mx < px + pw && my >= py && my < py + ph) {
                if (my >= py + HEADER_H) {
                    int col = (int) ((mx - px) / pcolW);
                    int row = (int) ((my - py - HEADER_H) / ROW_H);
                    int i = col * rowsPerCol + row;
                    if (row < rowsPerCol && i < rows.size()) {
                        Module.Setting s = rows.get(i);
                        if (s instanceof Module.Bool b) b.toggle();
                        else if (s instanceof Module.Choice c) c.cycle();
                        else if (s instanceof Module.Int n) {
                            dragging = n;
                            dragX = rowX(i);
                            dragW = pcolW;
                            applyDrag(mx);
                        }
                    }
                }
            } else {
                open = null;
            }
            return true;
        }

        int tab = tabAt(mx, my);
        if (tab == 1) {
            client.setScreen(new AccountScreen(this));
            return true;
        }
        if (tab >= 0) return true;

        for (int c = 0; c < byCat.size(); c++) {
            int x = colX(c);
            if (mx < x || mx >= x + colW) continue;
            if (my >= TOP && my < TOP + HEADER_H) {
                collapsed[c] = !collapsed[c];
                return true;
            }
            if (collapsed[c] || my < TOP + HEADER_H) continue;
            int i = (int) ((my - TOP - HEADER_H) / ROW_H);
            List<Module> l = byCat.get(c);
            if (i >= 0 && i < l.size()) {
                Module m = l.get(i);
                if (button == 1 && m.isToggle()) {
                    open = m;
                    buildRows(m);
                } else {
                    m.click();
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            applyDrag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && open != null) {
            open = null;
            return true;
        }
        if (ChestHighlightClient.openKey != null && ChestHighlightClient.openKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        OreScanner.rescan();
        BaseScanner.rescan();
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
