package com.astraite.chesthl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** One entry in the click GUI: a toggle (with settings) or a plain action. */
public final class Module {
    public enum Category {
        COMBAT("Combat"), PLAYER("Player"), RENDER("Render"), MISC("Misc");

        public final String title;

        Category(String title) {
            this.title = title;
        }
    }

    public abstract static class Setting {
        public final String name;

        Setting(String name) {
            this.name = name;
        }
    }

    public static final class Bool extends Setting {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;
        private final Runnable after;

        Bool(String name, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
            super(name);
            this.get = get;
            this.set = set;
            this.after = after;
        }

        public boolean value() {
            return get.getAsBoolean();
        }

        public void toggle() {
            set.accept(!value());
            if (after != null) after.run();
        }
    }

    public static final class Int extends Setting {
        public final int min, max;
        private final IntSupplier get;
        private final IntConsumer set;
        private final Runnable after;

        Int(String name, int min, int max, IntSupplier get, IntConsumer set, Runnable after) {
            super(name);
            this.min = min;
            this.max = max;
            this.get = get;
            this.set = set;
            this.after = after;
        }

        public int value() {
            return get.getAsInt();
        }

        public double fraction() {
            return max == min ? 0 : (value() - min) / (double) (max - min);
        }

        public void setFraction(double f) {
            double c = Math.max(0, Math.min(1, f));
            set.accept(min + (int) Math.round(c * (max - min)));
            if (after != null) after.run();
        }
    }

    public static final class Choice extends Setting {
        private final String[] options;
        private final IntSupplier get;
        private final IntConsumer set;

        Choice(String name, String[] options, IntSupplier get, IntConsumer set) {
            super(name);
            this.options = options;
            this.get = get;
            this.set = set;
        }

        public String label() {
            return options[Math.max(0, Math.min(options.length - 1, get.getAsInt()))];
        }

        public void cycle() {
            set.accept((get.getAsInt() + 1) % options.length);
        }
    }

    public final String name;
    public final Category category;
    public final Bool active;        // null for plain actions
    private final Runnable action;   // null for toggles
    public final List<Setting> settings = new ArrayList<>();

    private Module(String name, Category category, Bool active, Runnable action) {
        this.name = name;
        this.category = category;
        this.active = active;
        this.action = action;
    }

    public static Module toggle(String name, Category cat, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
        return new Module(name, cat, new Bool("Active", get, set, after), null);
    }

    public static Module action(String name, Category cat, Runnable run) {
        return new Module(name, cat, null, run);
    }

    public boolean isToggle() {
        return active != null;
    }

    public boolean isOn() {
        return active != null && active.value();
    }

    public void click() {
        if (active != null) active.toggle();
        else if (action != null) action.run();
    }

    public Module bool(String name, BooleanSupplier get, Consumer<Boolean> set, Runnable after) {
        settings.add(new Bool(name, get, set, after));
        return this;
    }

    public Module num(String name, int min, int max, IntSupplier get, IntConsumer set, Runnable after) {
        settings.add(new Int(name, min, max, get, set, after));
        return this;
    }

    public Module choice(String name, String[] options, IntSupplier get, IntConsumer set) {
        settings.add(new Choice(name, options, get, set));
        return this;
    }
}
