package com.astraite.chesthl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Angerable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Kill Aura with Meteor-style options (weapon, priority, max targets, delays, shield, swing, ...). */
public final class KillAura {
    private static int delay = 0;       // ticks until next hit (custom delay mode)
    private static int switchWait = 0;  // ticks to wait after switching slot

    public static void tick(MinecraftClient mc) {
        if (!Config.killAura) {
            BaritoneUtil.resume();
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        EntityTypes.ensureDefaults(mc.world);
        if (mc.currentScreen != null || p.isDead() || p.isSpectator()) return;
        if (AutoEat.eating && Config.pauseAuras) return;
        if (Config.auraPauseLag && TickRate.sinceLast() > 2.0f) return;
        if (Config.auraPauseUse && p.isUsingItem()) return;
        if (Config.auraPauseCA && Config.crystalAura && CrystalAura.status.startsWith("Target")) return;

        if (delay > 0) delay--;
        if (switchWait > 0) {
            switchWait--;
            return;
        }
        if (Config.auraOnlyClick && !mc.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos();
        double range = Config.auraRange10 / 10.0, walls = Config.auraWalls10 / 10.0;
        double maxSq = range * range;
        double wallSq = walls * walls;

        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p) continue;
            if (!le.isAlive() || le.isInvulnerable() || le.isSpectator()) continue;
            if (!validType(le)) continue;
            if (Config.auraIgnoreNamed && le.hasCustomName()) continue;
            if (Config.auraIgnoreTamed && le instanceof TameableEntity t && t.isTamed()) continue;
            if (Config.auraShield == 2 && le.isBlocking()) continue;
            if (Config.auraAge != 0 && !(le instanceof PlayerEntity)) {
                if (le.isBaby() ? Config.auraAge == 2 : Config.auraAge == 1) continue;
            }
            double d = distSq(eye, le.getBoundingBox());
            if (d > maxSq) continue;
            if (d > wallSq && !p.canSee(le)) continue;
            list.add(le);
        }
        if (list.isEmpty()) {
            BaritoneUtil.resume();
            return;
        }

        list.sort(comparator(p, eye));

        if (Config.auraOnlyLook) {
            Entity look = mc.crosshairTarget instanceof EntityHitResult h ? h.getEntity() : null;
            list.removeIf(e -> e != look);
            if (list.isEmpty()) return;
        }

        LivingEntity first = list.get(0);
        if (Config.auraPauseBaritone) BaritoneUtil.pause();
        if (Config.auraRotateMode == 0) face(p, first);

        if (!prepareWeapon(p, first)) return;

        // timing: vanilla cooldown, or custom tick delay
        if (Config.auraCustomDelay) {
            if (delay > 0) return;
        } else if (p.getAttackCooldownProgress(Config.auraTpsSync ? TickRate.tps() - 20f : 0f) < 1.0f) {
            return;
        }

        if (Config.auraRotateMode == 1) face(p, first);

        boolean hit = false;
        int n = Math.min(Config.auraMaxTargets, list.size());
        for (int i = 0; i < n; i++) {
            mc.interactionManager.attackEntity(p, list.get(i));
            hit = true;
        }
        if (hit) p.swingHand(Hand.MAIN_HAND);
        float scale = Config.auraTpsSync ? 20f / Math.max(1f, TickRate.tps()) : 1f;
        delay = Math.round(Config.auraHitDelay * scale);
    }

    // ---------------- weapon ----------------
    private static boolean prepareWeapon(ClientPlayerEntity p, LivingEntity target) {
        int want = Config.auraWeapon;
        if (Config.auraShield == 1 && target.isBlocking()) want = 2; // axe breaks shields
        if (want == 0) return true;
        if (matches(p.getMainHandStack().getItem(), want)) return true;
        if (!Config.auraAutoSwitch) return false;
        for (int i = 0; i < 9; i++) {
            if (matches(p.getInventory().getStack(i).getItem(), want)) {
                p.getInventory().selectedSlot = i;
                switchWait = Config.auraSwitchDelay;
                return switchWait == 0;
            }
        }
        return false;
    }

    private static boolean matches(Item item, int w) {
        return switch (w) {
            case 1 -> item instanceof SwordItem;
            case 2 -> item instanceof AxeItem;
            case 3 -> item instanceof MaceItem;
            case 4 -> item instanceof TridentItem;
            case 5 -> item instanceof SwordItem || item instanceof AxeItem
                    || item instanceof MaceItem || item instanceof TridentItem;
            default -> true;
        };
    }

    // ---------------- helpers ----------------
    private static Comparator<LivingEntity> comparator(ClientPlayerEntity p, Vec3d eye) {
        return switch (Config.auraPriority) {
            case 1 -> Comparator.comparingDouble(e -> distSq(eye, e.getBoundingBox()));
            case 2 -> Comparator.<LivingEntity>comparingDouble(e -> distSq(eye, e.getBoundingBox())).reversed();
            case 3 -> Comparator.comparingDouble(e -> e.getHealth() + e.getAbsorptionAmount());
            case 4 -> Comparator.<LivingEntity>comparingDouble(e -> e.getHealth() + e.getAbsorptionAmount()).reversed();
            default -> Comparator.comparingDouble(e -> angle(p, e));
        };
    }

    private static double angle(ClientPlayerEntity p, Entity t) {
        Vec3d to = t.getBoundingBox().getCenter().subtract(p.getEyePos()).normalize();
        double dot = p.getRotationVec(1.0f).dotProduct(to);
        return Math.toDegrees(Math.acos(MathHelper.clamp(dot, -1.0, 1.0)));
    }

    private static boolean validType(LivingEntity e) {
        if (!Config.auraEntityTypes.contains(EntityTypes.id(e.getType()))) return false;
        // Ignore Passive: skip peaceful mobs unless they are currently angry at someone
        if (Config.auraIgnorePassive && !(e instanceof PlayerEntity) && !(e instanceof HostileEntity)) {
            return e instanceof Angerable a && a.hasAngerTime();
        }
        return true;
    }

    private static double distSq(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.squaredDistanceTo(x, y, z);
    }

    private static void face(ClientPlayerEntity p, Entity t) {
        Vec3d eye = p.getEyePos();
        Vec3d to = t.getBoundingBox().getCenter();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }
}
